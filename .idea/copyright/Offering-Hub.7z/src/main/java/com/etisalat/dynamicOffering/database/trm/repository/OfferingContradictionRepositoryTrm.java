package com.etisalat.dynamicOffering.database.trm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingContradictionTRM;

public interface OfferingContradictionRepositoryTrm extends JpaRepository<OfferingContradictionTRM, Integer> {


	@Query(value = "select  offering_id, offering_name , OFFERING_CATEGORY,name  from trm_meta_t.px_offering_details ,trm_meta_t.PX_Service_Category  where px_offering_details.OFFERING_CATEGORY = PX_Service_Category.category_ID order by name",nativeQuery=true)
	List<Object[]> listContradiction();
	
	

	@Query(value = "select  O , S  from  OfferingDetails  O , ServiceCategory S where O.offeringCategory = S.categoryId order by S.name")
	List<Object[]> listContradiction2();
}