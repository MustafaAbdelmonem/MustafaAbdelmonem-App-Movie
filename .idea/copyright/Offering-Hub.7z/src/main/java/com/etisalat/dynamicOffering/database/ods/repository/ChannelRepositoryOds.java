package com.etisalat.dynamicOffering.database.ods.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.ods.entity.Channel;



public interface ChannelRepositoryOds extends JpaRepository<Channel, Integer> {

}