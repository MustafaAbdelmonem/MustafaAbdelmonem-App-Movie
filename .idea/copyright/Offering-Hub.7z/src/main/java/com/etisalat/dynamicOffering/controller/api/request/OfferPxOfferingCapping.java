package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferPxOfferingCapping {
	
	private Integer offeringId;

	private Integer cappingDaily;
	
	private boolean cappingDailyNull = true;
	
	private Integer cappingWeekly;
	
	private boolean cappingWeeklyNull = true;
	
	private Integer cappingMonthly;
	
	private boolean cappingMonthlyNull = true;
	
	private Integer cappingTotal;
	
	private boolean cappingTotalNull = true;
	
	private String targetBundle;
	private String sourceBundle;
	private String action;
	
	private Integer targetRatePlan;
	
	private String unsettlementOffer;
	private Integer productValidity;
	private Integer transactionAmount;
	private Integer bundleType;

}
