package com.etisalat.dynamicOffering.controller.api.request;

import java.util.Date;

import lombok.Data;

@Data
public class OfferingDTO {
	
	//private Integer offeringId;
	private String offeringName;
	private String offeringDesc;
	private Date offeringStartDttm;
	private Date offeringEndDttm;
	private Integer offeringMask;
	private String offeringVal;
	private String offeringBits;
	private Date dwhEntryDate;
	private Integer sssId;
	private String sssName;
	private String campaignNotificationFlag;
	private String bulkActionFlag;
	private String engagementFlag;
	private Integer templateId;
}
