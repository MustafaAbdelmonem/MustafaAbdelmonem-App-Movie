package com.etisalat.subscriptionparameterizedoffer.dto;

import lombok.Data;

@Data
public class TsiProcessConfigDTO {
	
	private Integer configId;
	private String configGroup;
	private String configKey;
	private String configValue;
	private boolean batchDB;
	private String commandTxt;
}
