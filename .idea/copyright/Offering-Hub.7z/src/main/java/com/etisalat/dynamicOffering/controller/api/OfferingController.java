package com.etisalat.dynamicOffering.controller.api;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.common.utils.AuthUtils;
import com.etisalat.common.utils.Constant;
import com.etisalat.dynamicOffering.controller.AbstractBaseController;
import com.etisalat.dynamicOffering.controller.api.request.PxOfferDTO;
import com.etisalat.dynamicOffering.controller.api.request.RequestDTO;
import com.etisalat.dynamicOffering.controller.util.APIResponse;
import com.etisalat.dynamicOffering.database.trm.entity.Offering;
import com.etisalat.dynamicOffering.models.PxOfferDtoList;
import com.etisalat.dynamicOffering.models.old.Offer;
import com.etisalat.dynamicOffering.service.OfferingService;
import com.etisalat.dynamicOffering.service.SavingOfferService;
//import com.etisalat.dynamicOffering.service.SavingOfferServiceOld;
import com.etisalat.ivroffer.attribute.IvrOfferDtoList;
import com.etisalat.ivroffer.dto.IvrOfferDTO;
import com.etisalat.ivroffer.mappers.IvrMapper;
import com.etisalat.ivroffer.model.OfferingVDB;



@RestController
@RequestMapping(APIName.OFFERING)
@CrossOrigin(origins="*", maxAge=3600)
public class OfferingController extends AbstractBaseController {

	@Autowired
	OfferingService offeringService;
	@Autowired
	SavingOfferService savingOfferService;
	
//	@Autowired
//	SavingOfferServiceOld savingOfferServiceOld;

	@RequestMapping(value = APIName.OFFERING_LIST, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<PxOfferDtoList> findAllOfferingOds(@RequestParam("start") int start, @RequestParam("pageSize") int pageSize
			, HttpServletRequest request) {
	//	return responseUtil.successResponse(offeringService.findAllOfferingOds());
	
	
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			List<Offering> dtos = new ArrayList<>();
			dtos=offeringService.findAllOfferingOds();
			
			
			int totalCount = dtos.size();
			List<Offering> offers= new ArrayList<>();
			if(totalCount != 0) {
				for (int i = start; i < pageSize; i++) {
					offers.add(dtos.get(i));
				}
			}
			
			PxOfferDtoList pxOffersList = new PxOfferDtoList();
			pxOffersList.setRecordsTotal(dtos.size());
			pxOffersList.setTotalCount(totalCount);
			pxOffersList.setPxOffers(offers);
			return new ResponseEntity<>(pxOffersList, HttpStatus.OK);
		
		
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new PxOfferDtoList(), HttpStatus.BAD_REQUEST);
		}
	
	
	
	
	
	}
	
	@RequestMapping(value = APIName.OFFERING_ADD, method = RequestMethod.POST)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> addOffering(@Valid @RequestBody RequestDTO requestDTO, HttpServletRequest request) {
		LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
		return responseUtil.successResponse(savingOfferService.save(requestDTO,false));
	}
	
//	@SuppressWarnings("rawtypes")
	@RequestMapping(value = APIName.OFFERING_SAVE, method = RequestMethod.POST)
//	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> saveOffer(@Valid @RequestBody PxOfferDTO offer, HttpServletRequest request) throws Exception {
		LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
		return responseUtil.successResponse(savingOfferService.savePxOffer(offer,false));
	}
	
	@RequestMapping(value = APIName.OFFERING_UPDATE, method = RequestMethod.POST)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> updateOffering(@RequestBody Offer offer, HttpServletRequest request) {
		LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
		
//		savingOfferServiceOld.save(offer, false);
		
		return responseUtil.successResponse(Constant.SERVICE_UNDER_CONSTRUCTION);
		
	
	}

}
