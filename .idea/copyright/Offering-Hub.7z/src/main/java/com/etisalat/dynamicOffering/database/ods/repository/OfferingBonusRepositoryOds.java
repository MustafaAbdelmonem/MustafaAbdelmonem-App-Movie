package com.etisalat.dynamicOffering.database.ods.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingBonus;

/**
 *
 * @author O-Mostafa.Teba
 */
public interface OfferingBonusRepositoryOds extends JpaRepository<OfferingBonus, Integer> {

}