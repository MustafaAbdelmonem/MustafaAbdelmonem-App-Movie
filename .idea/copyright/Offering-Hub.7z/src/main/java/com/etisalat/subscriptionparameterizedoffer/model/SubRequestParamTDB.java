package com.etisalat.subscriptionparameterizedoffer.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "Sub_Request_Param", schema = "TRM_LEAD")
public class SubRequestParamTDB implements Serializable {

	private static final long serialVersionUID = -5275642525767047218L;
	
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "Request_Param_Id")
	private Integer requestParamId;
	
	@NotNull
	@Column(name="Request_Param_Name")
	private String requestParamName;
	
	@Column(name="Subscription_Template_Flag", length = 1)
	private Character subscriptionTemplateFlag;

}
