package com.etisalat.subscriptionparameterizedoffer.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.etisalat.subscriptionparameterizedoffer.mappers.OfferParamValueMapper;
import com.etisalat.subscriptionparameterizedoffer.model.OfferingSubRequestParam;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTDB;

import lombok.Data;

@Data
public class SubscriptionParameterizedOfferDTO {
	
	private Integer offeringId;
	private String offeringName;
	private String offeringDesc;
	private Date startDttm;
	private Date endDttm;
	private String offeringVal;
	private Date dwhEntryDate;
	private Long serviceId;
	private String accountGroupFlag;
	private String serviceName;
	private OfferingCatalogDTO catalog;
	private TsiProcessConfigDTO tsiProcessConfig; 
	private List<OfferParamValueDTO> offerParamValue;
	private List<SubRequestParamTrmDTO> subRequestParamTRM;
	private List<SubRequestParamTdbDTO> subRequestParamTDB;
	private List<OfferingSubRequestParamDTO> offeringSubRequestParam;
	private char deleteFlag;
//	private Map<String,String> paramValMap = new HashMap<>();
		
//	public List<SubscriptionParameterizedOfferDTO> prepareOfferParamValues(List<SubscriptionParameterizedOfferDTO> offers){
//		offers.stream().forEach(offer -> {
//			if(offer.getOfferParamValue() == null || offer.getOfferParamValue().isEmpty())
//				offer.setOfferParamValue(new ArrayList<>());
//			OfferParamValueDTO item = OfferParamValueMapper.instance.tdbToOfferingSubParamDTO(offer.getSubRequestParamTDB());
//			item.setOfferingId(offerParamVal.getOfferingId());
//			item.setRequestTxtParamVal(offerParamVal.getRequestTxtParamVal());
//			item.setRequestNumParamVal(offerParamVal.getRequestNumParamVal());
//			offer.getOfferParamValue().add(item);
//		});
//		return offers;
//	}
//
//	public void prepareOfferParamValues(List<SubRequestParamTDB> subRequestParamTDB2,
//			List<OfferingSubRequestParam> offeringSubRequestParam2) {
//		// TODO Auto-generated method stub
//		
//	}
}
