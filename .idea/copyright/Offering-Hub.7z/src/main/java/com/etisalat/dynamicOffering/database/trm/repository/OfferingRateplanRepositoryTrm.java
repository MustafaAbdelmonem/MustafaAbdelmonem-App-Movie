package com.etisalat.dynamicOffering.database.trm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingRateplanTRM;


public interface OfferingRateplanRepositoryTrm extends JpaRepository<OfferingRateplanTRM, Integer> {

}