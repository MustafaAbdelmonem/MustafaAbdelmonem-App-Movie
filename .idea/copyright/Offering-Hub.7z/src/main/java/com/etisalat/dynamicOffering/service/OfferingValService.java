package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingVal;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingValRepositoryTrm;

/**
 *
 * @author O-Mostafa.Teba
 */

@Service
public class OfferingValService extends AbstractBaseService {

	@Autowired
	OfferingValRepositoryTrm offeringValRepositoryTrm;
		
	@Transactional()
	public List<OfferingVal> findAll() {
		return offeringValRepositoryTrm.findAll();
	}
	
	@Transactional()
	public List<OfferingVal> findByServiceId(Integer serviceId) {
		return offeringValRepositoryTrm.findByServiceId(serviceId);
	}

}
