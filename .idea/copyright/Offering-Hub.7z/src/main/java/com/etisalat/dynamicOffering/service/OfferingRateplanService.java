package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingRateplan;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingRateplanRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingRateplanTRM;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingRateplanRepositoryTrm;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;


@Service
public class OfferingRateplanService extends AbstractBaseService {
	
	@Autowired
	OfferingRateplanRepositoryOds offeringRateplanRepositoryOds;
	
	@Autowired
	OfferingRateplanRepositoryTrm offeringRateplanRepositoryTrm;
	
	@Transactional()
	public List<OfferingRateplanTRM> findAllRatePlan() {
		return offeringRateplanRepositoryTrm.findAll();
	}

	public boolean insertOfferingRateplanTRM(OfferingRateplan offeringRateplan) {
		offeringRateplanRepositoryOds.save(offeringRateplan);
		

		offeringRateplanRepositoryTrm.save(DynamicOfferingMapper.instance.mapOfferingRateplanEntityTRM(offeringRateplan));
		
		
		return true;
	}
}
