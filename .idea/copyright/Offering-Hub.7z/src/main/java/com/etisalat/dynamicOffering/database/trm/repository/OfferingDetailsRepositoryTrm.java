package com.etisalat.dynamicOffering.database.trm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingDetails;

/**
 *
 * @author O-Mostafa.Teba
 */
public interface OfferingDetailsRepositoryTrm extends JpaRepository<OfferingDetails, Integer> {
	
	List<OfferingDetails> findByOfferingCategory(String offeringCategory);
	
	List<OfferingDetails>  findByOfferingName(String offeringName);

}