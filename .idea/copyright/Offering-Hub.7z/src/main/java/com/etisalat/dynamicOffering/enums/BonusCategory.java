package com.etisalat.dynamicOffering.enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public enum BonusCategory {
	
	ON_NET(1,"On_net"),
	CROSS_NET(2,"Cross_net");
	
	private Integer id;
	private String name;
	
	BonusCategory(Integer id, String name) {
		this.id = id;
		this.name = name;
	}
	 
	 public static  List<Properties> getData(){
		List<Properties> data = new ArrayList<Properties>();
		for(BonusCategory bt : BonusCategory.values()) {
			Properties prop = new Properties();
			prop.put("name", bt.name);
			prop.put("id", bt.id.toString());
			data.add(prop);
		}
		return data;
	}
}
