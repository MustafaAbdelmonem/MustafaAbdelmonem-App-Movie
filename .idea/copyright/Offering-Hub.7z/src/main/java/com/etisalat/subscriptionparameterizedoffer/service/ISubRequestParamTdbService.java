package com.etisalat.subscriptionparameterizedoffer.service;

import java.util.List;

import com.etisalat.subscriptionparameterizedoffer.dto.SubscriptionParameterizedOfferDTO;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTDB;

public interface ISubRequestParamTdbService {

	void updateSubRequestParam(List<SubRequestParamTDB> list, SubscriptionParameterizedOfferDTO dto);

	void saveSubRequestParam(List<SubRequestParamTDB> subRequestParamTDB, SubscriptionParameterizedOfferDTO dto);

}
