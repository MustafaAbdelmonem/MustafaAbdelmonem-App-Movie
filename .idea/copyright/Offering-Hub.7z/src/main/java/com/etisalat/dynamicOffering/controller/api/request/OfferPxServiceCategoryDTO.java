package com.etisalat.dynamicOffering.controller.api.request;

import java.util.Date;

import lombok.Data;

@Data
public class OfferPxServiceCategoryDTO {

	private String categoryId;

	private String parentID;

	private String name;

	private String arabicName;

	private String catHiddenFlag;

	private Integer categoryPriority;

	private Date dwhEntryDate;

}
