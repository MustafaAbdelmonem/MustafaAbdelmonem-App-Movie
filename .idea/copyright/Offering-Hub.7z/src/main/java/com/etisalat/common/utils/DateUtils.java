package com.etisalat.common.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import org.apache.log4j.Logger;

public class DateUtils {
	
	static Logger logger = Logger.getLogger(DateUtils.class);

	public static final DateTimeFormatter gregorianDateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
	
	public static String dateToString(Date date) {
		DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
		return date != null ? df.format(date) : null;
	}
	
}
