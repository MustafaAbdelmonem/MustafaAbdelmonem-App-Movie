package com.etisalat.dynamicOffering.database.trm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.etisalat.dynamicOffering.database.trm.entity.DynOfferingParameterId;
import com.etisalat.dynamicOffering.database.trm.entity.DynOfferingParameterTRM;


public interface DynOfferingParameterRepositoryTrm extends JpaRepository<DynOfferingParameterTRM, DynOfferingParameterId> {

}