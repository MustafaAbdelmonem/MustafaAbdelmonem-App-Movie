package com.etisalat.dynamicOffering.database.trm.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.etisalat.dynamicOffering.database.trm.entity.Offering;


/**
 *
 * @author O-Mostafa.Teba
 */
public interface OfferingRepositoryTrm extends JpaRepository<Offering, Integer> {

	@Query("SELECT max(offering_id)+1 from Offering")
	Integer getNextOfferId();
	
	@Query("select u from Offering u where u.deleteFlag=:N")
	public List<Offering> getofferlist();

	@Modifying
	@Query("update Offering u set u.deleteFlag=:Y  where u.offeringId=:offeringId")
	public void update( @Param("offeringId") Integer offeringId);
}