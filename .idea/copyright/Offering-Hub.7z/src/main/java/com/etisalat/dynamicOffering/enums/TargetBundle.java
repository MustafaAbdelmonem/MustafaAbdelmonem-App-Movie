package com.etisalat.dynamicOffering.enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public enum TargetBundle {

	NEW_MI_BUNDLE_1("Super connect 10 LE"),
	NEW_MI_BUNDLE_2("Super connect 20 LE"),
	NEW_MI_BUNDLE_3("Super connect 35 LE"),
	NEW_MI_BUNDLE_4("Super connect 65 LE"),
	NEW_MI_BUNDLE_5("Super connect 130 LE"),
	NEW_MI_BUNDLE_6("Super connect 200 LE"),
	NEW_MI_BUNDLE_7("Super connect 300 LE");
	

	private String name;

	TargetBundle(String name) {
		this.name = name;
	}
	
	public static  List<Properties> getAllData(){
		List<Properties> data = new ArrayList<Properties>();
		for(TargetBundle tc : TargetBundle.values()) {
			Properties prop = new Properties();
			prop.put("name", tc.name);
			data.add(prop);
		}
		return data;
	}
	
	public static  List<Properties> getData(List<TargetBundle> list){
		List<Properties> data = new ArrayList<Properties>();
		for(TargetBundle tc : list) {
			Properties prop = new Properties();
			prop.put("name", tc.name);
			data.add(prop);
		}
		return data;
	}
	
}
