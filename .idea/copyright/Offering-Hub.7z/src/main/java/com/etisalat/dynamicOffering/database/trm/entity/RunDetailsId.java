package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class RunDetailsId implements Serializable{

	private String communicationId;
	private Integer offeringId;
	
}
