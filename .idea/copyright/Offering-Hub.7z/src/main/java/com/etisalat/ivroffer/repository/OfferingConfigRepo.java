package com.etisalat.ivroffer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.ivroffer.model.OfferingConfig;

@Transactional
@Repository("offeringConfigRepo")
public interface OfferingConfigRepo extends JpaRepository<OfferingConfig, Long> {

	@Transactional
	@Modifying
	@Query("DELETE FROM OfferingConfig WHERE offering_id =:offeringId")
	void deleteOffer(@Param("offeringId") Integer offeringId);

	@Transactional
	@Modifying
	@Query("UPDATE OfferingConfig SET deleteFlag = 'Y' WHERE offering_id =:offeringId")
	void deleteOfferingConfig(@Param("offeringId") Integer offeringId);

}
