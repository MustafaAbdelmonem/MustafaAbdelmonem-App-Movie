package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.controller.AbstractBaseController;
import com.etisalat.dynamicOffering.database.ods.repository.RunDetailsRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.RunDetails;
import com.etisalat.dynamicOffering.database.trm.repository.RunDetailsRepositoryTrm;

/**
 *
 * @author O-Mostafa.Teba
 */

@Service
public class RunDetailsService extends AbstractBaseController {
	
	@Autowired
	RunDetailsRepositoryOds runDetailsRepositoryOds;
	
	@Autowired
	RunDetailsRepositoryTrm runDetailsRepositoryTrm;
	
	@Transactional()
	public List<RunDetails> findAllRunDetails() {
		return runDetailsRepositoryTrm.findAll();
	}
}
