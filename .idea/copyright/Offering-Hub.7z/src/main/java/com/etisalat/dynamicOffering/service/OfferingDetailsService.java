
package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsAtl;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsBtl;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingDetailsAtlRepositoryOds;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingDetailsBtlRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingDetails;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingDetailsRepositoryTrm;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.rtim.integration.RTIMintegration;
import com.google.gson.Gson;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import java.awt.print.Pageable;
import com.etisalat.dynamicOffering.database.ods.repository.DynOfferingConverterRepositoryOds;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingContradictionRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.Offering;
import com.google.common.base.Predicate;


@Service
public class OfferingDetailsService extends AbstractBaseService {

	
	
	Sort sort;

	@Autowired
	com.etisalat.dynamicOffering.database.trm.repository.OfferingRepositoryTrm OfferingRepositoryTrm;
	@Autowired
	com.etisalat.dynamicOffering.database.ods.repository.DynOfferingConverterRepositoryOds DynOfferingConverterRepositoryOds;
	@Autowired
	com.etisalat.dynamicOffering.database.ods.repository.DynOfferingParameterLkpRepositoryOds DynOfferingParameterLkpRepositoryOds;
	@Autowired
	com.etisalat.dynamicOffering.database.ods.repository.DynOfferingParameterRepositoryOds DynOfferingParameterRepositoryOds;
	@Autowired
	com.etisalat.dynamicOffering.database.ods.repository.OfferingBonusRepositoryOds OfferingBonusRepositoryTOds;
	@Autowired
	com.etisalat.dynamicOffering.database.ods.repository.OfferingCappingRepositoryOds OfferingCappingRepositoryOds;
	@Autowired
	com.etisalat.dynamicOffering.database.ods.repository.OfferingChannelRepositoryOds OfferingChannelRepositoryOds;
	@Autowired
	OfferingContradictionRepositoryOds  OfferingContradictionRepositoryOds;
	
	@Autowired
	OfferingDetailsAtlRepositoryOds atlRepositoryOds;

	@Autowired
	OfferingDetailsBtlRepositoryOds btlRepositoryOds;

	@Autowired
	OfferingDetailsRepositoryTrm offeringDetailsRepositoryTrm;
	@Autowired
	RTIMintegration rTIMintegration = new RTIMintegration();
	
	@Autowired
	Gson gson;

	@Transactional()
	public List<OfferingDetailsAtl> findAllATLs() {
		return atlRepositoryOds.findAll();
	}

	@Transactional()
	public List<OfferingDetailsBtl> findAllBTLs() {
		return btlRepositoryOds.findAll();
	}

	@Transactional()
	public List<OfferingDetails> findAllTRMOfferingDetails() {
		return offeringDetailsRepositoryTrm.findAll();
	}

	@Transactional()
	public List<OfferingDetails> findTRMOfferingDetailsByCategoryId(String categoryId) {
		return offeringDetailsRepositoryTrm.findByOfferingCategory(categoryId);
	}
	
	@Transactional()
	public List<OfferingDetails>  findTRMOfferingDetailsByOfferName(String offerName) {
		return offeringDetailsRepositoryTrm.findByOfferingName(offerName);
	}

	@Transactional()
	public OfferingDetailsAtl insertATL(OfferingDetailsAtl atlOffering) {
		return atlRepositoryOds.save(atlOffering);
	}
	
	
	@Transactional()
	public OfferingDetailsBtl insertBTL(OfferingDetailsBtl btlOffering) {
		return btlRepositoryOds.save(btlOffering);
	}
	
	
	@Transactional()
	public OfferingDetails insertOfferingDetailsTRM(OfferingDetails offeringDetails) {
		return offeringDetailsRepositoryTrm.save(offeringDetails);
	}
	
	@Transactional()
	public OfferingDetails insertOfferingDetails(OfferingDetails offeringDetails) throws Exception {
		if(offeringDetails.getOfferingLineType().equals("ATL")) {
			OfferingDetailsAtl offeringDetailsAtl = DynamicOfferingMapper.instance.mapOfferingDetailsToAtlEntity(offeringDetails);
			insertATL(offeringDetailsAtl);
		} else if (offeringDetails.getOfferingLineType().equals("BTL")) {
			OfferingDetailsBtl offeringDetailsBtl = DynamicOfferingMapper.instance.mapOfferingDetailsToBtlEntity(offeringDetails);
			insertBTL(offeringDetailsBtl);
		}
		OfferingDetails offerDetails = offeringDetailsRepositoryTrm.save(offeringDetails);
		rTIMintegration.insertRTIMDB(gson.toJson(offeringDetails), offeringDetails.getOfferingLineType().equalsIgnoreCase("ATL") ?  "px_offering_details_atl" :  "px_offering_details_btl");
		return offerDetails;
	}
	
	
	
	  /**  msamir **/

		public Page<OfferingDetails> getAlloffer(Predicate predicate, Pageable pageable, Integer page) {
			sort = new Sort(Sort.Direction.DESC, "id");
			pageable = (Pageable) new PageRequest(page, 10, sort);
			return offeringDetailsRepositoryTrm.findAll(predicate, pageable);
		}
		
		
		
		
		@Transactional()
		public void delete(Integer offeringId) {

			if (offeringId != null) {
				
				
				

				DynOfferingConverterRepositoryOds.delete(offeringId);
				LOGGER.debug("Delete offering id in offering converter table " + offeringId);

				DynOfferingParameterLkpRepositoryOds.delete(offeringId);
				LOGGER.debug("Delete offering id in offering parameter table " + offeringId);

				OfferingBonusRepositoryTOds.delete(offeringId);
				LOGGER.debug("Delete offering id in offering bonus table " + offeringId);

				OfferingCappingRepositoryOds.delete(offeringId);
				LOGGER.debug("Delete offering id in offering capping table " + offeringId);

				OfferingChannelRepositoryOds.delete(offeringId);
				LOGGER.debug("Delete offering id in offering channel table " + offeringId);

				OfferingContradictionRepositoryOds.delete(offeringId);
				LOGGER.debug("Delete offering id in offering contradicting table " + offeringId);

				atlRepositoryOds.delete(offeringId);
				LOGGER.debug("Delete offering id in offering parameter Ddb " + offeringId);

				btlRepositoryOds.delete(offeringId);
				LOGGER.debug("Delete offering id in offering parameter Ddb " + offeringId);

				OfferingRateplanTRepositoryOds.delete(offeringId);
				LOGGER.debug("Delete offering id in offering parameter Ddb " + offeringId);

				OfferingThresholdRepositoryOds.delete(offeringId);
				LOGGER.debug("Delete offering id in offering parameter Ddb " + offeringId);

				RunDetailsRepositoryTOds.delete(offeringId);			
				LOGGER.debug("Delete offering id in Rtm DB " + offeringId);

				atlRepositoryOds.delete(offeringId);
				LOGGER.debug("Delete offering id in ATLOds DB " + offeringId);

				btlRepositoryOds.delete(offeringId);

				LOGGER.debug("Delete offering id in BTLOds DB " + offeringId);
			
				
				OfferingRepositoryTrm.update(offeringId);
				LOGGER.debug("update offering id in rtm set delete flag =Y " + offeringId);

			}
		}

		public List<Offering> getofferslistrtm() {
			return OfferingRepositoryTrm.getofferlist();
		}

		
		public List<OfferingDetails> findTRMOfferingDetailsByOfferId(Integer offeringId) {
			return offeringDetailsRepositoryTrm.findByOfferingId(offeringId);
		}


		public Page<OfferingDetails> findTRMOfferingDetailsByOfferVal(Integer offeringVal, Pageable pageable) {

			List<OfferingDetails> offerdetalis = offeringDetailsRepositoryTrm.findByOfferingVal(offeringVal, pageable);

			int ListSize = 0;

			if (offerdetalis != null) {
				ListSize = counter(offeringVal);
			}

			return new PageImpl<OfferingDetails>(offerdetalis, pageable, ListSize);

		}

		public int counter(Integer offeringVal) {
			return offeringDetailsRepositoryTrm.countOfferingval(offeringVal);
		}
	
}
