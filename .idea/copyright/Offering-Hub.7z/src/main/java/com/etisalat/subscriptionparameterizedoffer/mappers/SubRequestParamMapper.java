package com.etisalat.subscriptionparameterizedoffer.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.etisalat.subscriptionparameterizedoffer.dto.SubRequestParamTdbDTO;
import com.etisalat.subscriptionparameterizedoffer.dto.SubRequestParamTrmDTO;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTDB;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTRM;

@Mapper
public interface SubRequestParamMapper {

	SubRequestParamMapper instance = Mappers.getMapper(SubRequestParamMapper.class);
	
	SubRequestParamTDB subTdbDtoToEntity(SubRequestParamTdbDTO dto);
	
	SubRequestParamTdbDTO subTdbEntityToDto(SubRequestParamTDB entity);
	
	SubRequestParamTRM subTrmDtoToEntity(SubRequestParamTrmDTO dto);
	
	SubRequestParamTrmDTO subTrmEntityToDto(SubRequestParamTRM entity);
	
	SubRequestParamTRM subTdbDtoToTrmEntity(SubRequestParamTdbDTO dto);
	
//	SubRequestParamTrmDTO subTdbEntityToTrmDto(SubRequestParamTDB entity);
	
	SubRequestParamTRM subTdbEntityToTrmEntity(SubRequestParamTDB entity);
	
}
