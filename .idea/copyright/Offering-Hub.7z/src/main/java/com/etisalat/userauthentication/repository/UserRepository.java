package com.etisalat.userauthentication.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.userauthentication.model.Users;

@Transactional
@Repository("userRepository")
public interface UserRepository extends JpaRepository<Users, Integer> {

	//check user for registration
	Users findByUserNameIgnoreCase(String userName);
	

	// validate login
	Users findByUserNameAndUserPassword(String userName, String userPassword);
//	@Transactional
//	@Modifying
//	@Query("SELECT u.userName "
//			+ "FROM Users u "
//			+ "WHERE u.userPassword = :userPassword")
//	Users findByUserPassword(@Param("userPassword") String userPassword);

	@Query("SELECT COALESCE(MAX(u.userId), 0) FROM Users u")
	Integer findMaxUserId();
	
	

}
