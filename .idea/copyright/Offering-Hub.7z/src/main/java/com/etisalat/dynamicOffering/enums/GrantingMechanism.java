package com.etisalat.dynamicOffering.enums;

public enum GrantingMechanism {

	PUSH("Push"),
	PULL("Pull");
	
	String lable;
	
	public String getLable() {
		return this.lable;
	}
	
	private GrantingMechanism(String lable) {
		this.lable = lable;
	}
}
