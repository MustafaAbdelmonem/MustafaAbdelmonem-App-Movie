package com.etisalat.subscriptionparameterizedoffer.service;

import java.util.List;

import javax.xml.bind.ValidationException;

import com.etisalat.subscriptionparameterizedoffer.dto.SubscriptionParameterizedOfferDTO;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOffer;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOfferVDB;

public interface ISubscriptionParameterizedService {

	SubscriptionParameterizedOfferVDB getOfferByOfferId(Integer offeringId);

	void updateOffer(SubscriptionParameterizedOffer offer, SubscriptionParameterizedOfferDTO dto) throws ValidationException;

	void delete(Integer offeringId);

	List<SubscriptionParameterizedOfferVDB> listSubscriptionOffers(int start, int pageSize);

	void saveOffer(SubscriptionParameterizedOffer offer, SubscriptionParameterizedOfferDTO dto)
			throws ValidationException;

	int getTotalCount();

	boolean isOfferingNameOrDescDuplicated(String offeringName);

}
