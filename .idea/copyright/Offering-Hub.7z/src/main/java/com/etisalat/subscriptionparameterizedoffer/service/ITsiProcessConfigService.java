package com.etisalat.subscriptionparameterizedoffer.service;

import javax.xml.bind.ValidationException;

public interface ITsiProcessConfigService {

	void saveOrUpdateTsiProcessConfig(boolean batchDB, String serviceName, String commandTxt) throws ValidationException;

}
