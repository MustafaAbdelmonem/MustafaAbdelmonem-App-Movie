package com.etisalat.dynamicOffering.database.ods.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author O-Mostafa.Teba
 */
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class OfferingChannelId implements Serializable {

	private static final long serialVersionUID = -4941383357862274448L;
	
	private Integer offeringId;
	private Long channelId;
	private String channelTypeId;
}
