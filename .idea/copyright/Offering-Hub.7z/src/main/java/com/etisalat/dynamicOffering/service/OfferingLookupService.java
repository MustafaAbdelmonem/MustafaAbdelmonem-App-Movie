package com.etisalat.dynamicOffering.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingHubLpkTRM;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingTemplates;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingVal;
import com.etisalat.dynamicOffering.database.trm.entity.ServiceCategory;
import com.etisalat.dynamicOffering.database.trm.entity.Shortcode;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingOfferingHubLPKRepositoryTrm;
import com.etisalat.dynamicOffering.database.trm.repository.ServiceCategoryRepositoryTrm;
import com.etisalat.dynamicOffering.enums.TrafficCase;
import com.etisalat.dynamicOffering.models.OfferingHubLPK;

@Service
public class OfferingLookupService {

	@Autowired
	private OfferingOfferingHubLPKRepositoryTrm offeringOfferingHubLPKRepositoryTrm;
	@Autowired
	private ServiceCategoryRepositoryTrm serviceCategoryRepositoryTrm;
	
	@Autowired
	private ServiceCategoryService serviceCategoryService;

	@Transactional()
	public Map<String, OfferingHubLPK>  findAll() {

			
		List<Object[]> x= offeringOfferingHubLPKRepositoryTrm.listOfferingHubLPK();
		
		Map<String, OfferingHubLPK> res = new HashMap<>();
	
		x.stream().forEach(item -> {
			 OfferingVal offeringVal =(OfferingVal)item[0] ;
			
			Shortcode listShortcode= (Shortcode)item[2];
			
			OfferingTemplates offeringTemplates=(OfferingTemplates)item[1] ;
			
			
			
			
			if (res.containsKey(offeringTemplates.getTemplateName())) {
				
				 res.get(offeringTemplates.getTemplateName() ).getPxOfferingOffval().add(offeringVal);
				 res.get(offeringTemplates.getTemplateName() ).getPxShortCode().add(listShortcode);
				 res.get(offeringTemplates.getTemplateName() ).setOfferingTemplates(offeringTemplates);
				
			}
			else {
				OfferingHubLPK offeringHubLPK= new OfferingHubLPK();

				offeringHubLPK.getPxOfferingOffval().add(offeringVal);
				offeringHubLPK.getPxShortCode().add(listShortcode);
				offeringHubLPK.setOfferingTemplates(offeringTemplates);
				
				 offeringHubLPK.setTraffiCades(getTrafficCases(offeringTemplates.getTemplateId()));
				
				 offeringHubLPK.setPxServiceCategory( getServiceCategory(offeringTemplates.getTemplateId()));
				
			
				res.put(offeringTemplates.getTemplateName(),offeringHubLPK);
				
			}
			
		});
		
		
		
//		Map<String, List<OfferingHubLPK>> res = new HashMap<>();
//		for (OfferingHubLpkTRM offeringHubLPKTRM : response ) {
//			OfferingHubLPK offeringHubLPK = preperOfferingHubLPK(offeringHubLPKTRM);
//			
//			if (res.containsKey(offeringHubLPKTRM.getTemplateName())) {
//				
//				OfferTypes  offerTypes = new OfferTypes();
//
//				offerTypes.setTemplateId(offeringHubLPKTRM.getTemplateId());
//				offerTypes.setOfferingVal(offeringHubLPKTRM.getOfferingVal());
//				offerTypes.setOfferType(offeringHubLPKTRM.getOfferType());
//				offerTypes.setParameterName(offeringHubLPKTRM.getParameterName());
//				offerTypes.setParameterValue(offeringHubLPKTRM.getParameterValue());
//				offerTypes.setServiceId(offeringHubLPKTRM.getServiceId());
//				offerTypes.setServiceName(offeringHubLPKTRM.getServiceName());
//				offerTypes.setShortCode(offeringHubLPKTRM.getShortCode());
//
//				res.get(offeringHubLPKTRM.getTemplateName()).get(index);
//			}
//			else {
//				
//				 Info info = new Info();
//				 info.setOperationId(offeringHubLPKTRM.getOperationId());
//				 info.setPlatformArDesc(offeringHubLPKTRM.getPlatformArDesc());
//				 info.setPlatformEnDesc(offeringHubLPKTRM.getPlatformEnDesc());
//				 info.setPlatformId(offeringHubLPKTRM.getPlatformId());
//				 info.setProductName(offeringHubLPKTRM.getProductName());
//				
//				offeringHubLPK.setInfo(info);
//				
//				List<OfferingHubLPK> list = new ArrayList<>() ;
//				list.add(offeringHubLPK);
//				res.put(offeringHubLPKTRM.getTemplateName(),list);
//				
//			}
//			
//		}
		
		
//		
//		Map<String, List<OfferingHubLpkTRM>> result = new HashMap<>();
//
//		for (OfferingHubLpkTRM offeringHubLPKTRM : response ) {
//
//			if (result.containsKey(offeringHubLPKTRM.getTemplateName())) {
//				result.get(offeringHubLPKTRM.getTemplateName()).add(offeringHubLPKTRM);
//			}
//			else {
//				List<OfferingHubLpkTRM> list = new ArrayList<>() ;
//				list.add(offeringHubLPK);
//				result.put(offeringHubLPKTRM.getTemplateName(),list);
//				
//			}
//		}

		return res;
	}

	
	
	public List<ServiceCategory> getServiceCategory(Integer templateId)
	{
		
		List<String> categoryIds = new ArrayList<String>();
		//TODO
		/****** Eman To Ask Mostafa About this ******/
		// BOR
		if (templateId == 1) {
			categoryIds.addAll(Arrays.asList(new String[] { "100", "200", "300", "400" }));
		}
		// PAY AND GET
		else if (templateId == 2) {
			categoryIds.addAll(Arrays.asList(new String[] { "500" }));
		}
		// BONUS ON RENEWAL
		else if (templateId == 3) {
			categoryIds.addAll(Arrays.asList(new String[] { "200" }));
		}
		// Renewable Addons
		else if (templateId == 4) {
			categoryIds.addAll(Arrays.asList(new String[] { "200" }));
		}
		// Special offer 'Digital Stoppers'
		else if (templateId == 5) {
			categoryIds.addAll(Arrays.asList(new String[] { "100" }));
		}
		// Zika
		else if (templateId == 6) {
			categoryIds.addAll(Arrays.asList(new String[] { "11" }));
		}
		// PAY_GET_REVAMP
		else if (templateId == 7) {
			categoryIds.addAll(Arrays.asList(new String[] { "100" }));
		}
		// Use & Get
		else if (templateId == 8) {
			categoryIds.addAll(Arrays.asList(new String[] { "100" }));
		}else if(templateId == 9 ) {
			categoryIds.addAll(Arrays.asList(new String[] { "100" }));
		}
		
		
		
		
		return serviceCategoryRepositoryTrm.findByCategoryIdIn(categoryIds);
	}	
	
	 public List<Properties> getTrafficCases(Integer templateId) {
		List<TrafficCase> trafficCases = new ArrayList<TrafficCase>();
		if (templateId == 1) { // BOR
			trafficCases.addAll(Arrays.asList(new TrafficCase[] 
			{ TrafficCase.UNIT, TrafficCase.MONTH_ON_OFF, TrafficCase.POOL, TrafficCase.MIXED }));
			
		} else if (templateId == 2) { // Pay and Get
			trafficCases.addAll(Arrays.asList(new TrafficCase[] 
			{ TrafficCase.UNIT, TrafficCase.MONTH_ON_OFF, TrafficCase.POOL, 
			  TrafficCase.MIXED, TrafficCase.VOUCHER, TrafficCase.VOUCHER_FAWRY, TrafficCase.VOUCHER_UBER }));
			
		} else if (templateId == 3) { // Bonus on Renewal
			trafficCases.addAll(Arrays.asList(new TrafficCase[] 
			{ TrafficCase.UNIT, TrafficCase.MONTH_ON_OFF, TrafficCase.DYNAMIC_DISCOUNT, 
			  TrafficCase.MULTIPLE_QUOTA, TrafficCase.HYBRID_FEATURES , 
			  TrafficCase.VOUCHER, TrafficCase.VOUCHER_FAWRY, TrafficCase.VOUCHER_UBER ,TrafficCase.MORE_PLUS }));
			
		} else if (templateId == 4) { // Renewable Addons
			trafficCases.addAll(Arrays.asList(new TrafficCase[] 
			{ TrafficCase.UNIT, TrafficCase.MONTH_ON_OFF, TrafficCase.POOL, 
		      TrafficCase.MIXED, TrafficCase.VOUCHER, TrafficCase.VOUCHER_FAWRY, TrafficCase.VOUCHER_UBER }));
		}else if (templateId == 5) { // Special offer
				trafficCases.addAll(Arrays.asList(new TrafficCase[] 
				{TrafficCase.UNIT, TrafficCase.MONTH_ON_OFF, TrafficCase.DYNAMIC_DISCOUNT, 
						  TrafficCase.MULTIPLE_QUOTA, TrafficCase.HYBRID_FEATURES , 
						  TrafficCase.VOUCHER, TrafficCase.VOUCHER_FAWRY, TrafficCase.VOUCHER_UBER ,TrafficCase.MORE_PLUS   }));
			}
		else if (templateId == 6) { // Zika
			trafficCases.addAll(Arrays.asList(new TrafficCase[] 
			{ TrafficCase.UNIT, TrafficCase.MONTH_ON_OFF, TrafficCase.DYNAMIC_DISCOUNT,
		      TrafficCase.MULTIPLE_QUOTA }));
		} else if (templateId == 7) { // PAY_GET_REVAMP
			trafficCases.addAll(Arrays.asList(new TrafficCase[] 
			{ TrafficCase.UNIT, TrafficCase.DYNAMIC_DISCOUNT, TrafficCase.VOUCHER, TrafficCase.VOUCHER_FAWRY, TrafficCase.VOUCHER_UBER }));
		} else if (templateId == 8) { // Use and Get
			trafficCases.addAll(Arrays.asList(new TrafficCase[] 
			{ TrafficCase.UNIT, TrafficCase.VOUCHER, TrafficCase.VOUCHER_FAWRY, TrafficCase.VOUCHER_UBER, TrafficCase.USAGE_PERCENTAGE }));
		}else if (templateId == 9) { // Use and Get
			trafficCases.addAll(Arrays.asList(new TrafficCase[] 
			{ TrafficCase.Partial_Renewal}));
		}
		
		
		
		
		
		return TrafficCase.getData(trafficCases);
	}
}
