package com.etisalat.dynamicOffering.models.old;

import java.io.Serializable;

import lombok.Data;

@Data
public class OfferingParameter implements Serializable {

	private long parameterTypeId;
	private long parameterTxt;

}
