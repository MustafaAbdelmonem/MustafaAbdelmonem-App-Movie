package com.etisalat.common.attribute;

import java.io.Serializable;

import lombok.Data;

@Data
public abstract class ReadableList implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 313341531332867431L;

	private int totalCount;
	private int recordsTotal;
	
}
