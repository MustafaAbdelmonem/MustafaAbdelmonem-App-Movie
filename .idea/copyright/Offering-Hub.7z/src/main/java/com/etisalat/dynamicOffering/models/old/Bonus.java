package com.etisalat.dynamicOffering.models.old;
import java.io.Serializable;
import lombok.Data;

@Data
public class Bonus implements Serializable {

	private String bonusType;
	private String bonusCategory;
	private Float bonusValue;
	private Integer consumptionValue;
	private boolean specialROR;
	private Integer specialRORValue;
	// TODO Consume from pool
	private boolean poolBonusFlag;
	private float bonusCapping;
	private String voucherID;
	private Float bonusDynamicDiscount;
	private Integer promoValidity;
	private Float multipleQuotaValue;
	private Integer multipleQuotaMaxRecurrence;
	private String fawryVoucherId;
	private String uberVoucherId;
	private String usagePercentage;
	
}

