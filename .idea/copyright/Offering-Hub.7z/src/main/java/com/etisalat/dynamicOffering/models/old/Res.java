package com.etisalat.dynamicOffering.models.old;

import lombok.Data;

@Data
public class Res{
	
	private Integer offeringId;
	private String offeringName;
	private String offerinCategory;
	private String categoryName;
	
}