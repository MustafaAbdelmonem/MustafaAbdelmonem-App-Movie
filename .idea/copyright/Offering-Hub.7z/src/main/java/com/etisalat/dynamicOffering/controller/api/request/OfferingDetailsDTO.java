package com.etisalat.dynamicOffering.controller.api.request;

import java.util.Date;

import lombok.Data;

/**
 *
 * @author O-Mostafa.Teba
 */
@Data
public class OfferingDetailsDTO {
	private Integer offeringId;
	private String offeringName;
	private Date offeringStartDt;
	private Date offeringEndDt;
	private Integer offeringDuration = 0;
	private Integer optInOfferingDuration = 0;
	private Integer sssId;
	private String sssName;
	private String shortCodeNum;
	private String offeringCategory;
	private Integer offerPriority;
	private String offeringBits;
	private Integer offeringVal;
	private Integer offeringMask;
	private Integer inOfferTypeId;
	private String offeringEngDesc;
	private String offeringArDesc;
	private String offeringLineType;
	private String offerHiddenFlag;
	private Integer isInformative;
	private String offeringShortDesc;
	private String offeringLongDesc;
	private Integer onlineFlag;
	private Float offerOptinFees;
	private Integer redemptionWindow;
	private Integer promotionPlanId;
	private Integer promotionPlanDuration;
	private Date promotionPlanStartDt;
	private Date promotionPlanEndDt;
	private Integer accumulationFlag;
	private Integer bonusValidity;
	private Integer subSendSmsFlag;
	private Date DWHEntryDate;
	private Integer grantingMechanism;
	private Integer multipleThresholdFlag;
	private String commercialServiceDescEN;
	private String commercialServiceDescAR;
	private String resourceType;
	private Integer accumlationDuration;
	private Integer bonusTypeFlag;
	private String optinScriptAr;
	private String optinScriptEn;
	private Integer ratePlanFlag;
	private String offeringFlag;
	
	/*
	 * 
	 * */
	private Integer validRenewalPeriod = 0;
	private String operationId;
	private String platformId;
	private String productName;
	private String platformArDesc;
	private String platformEnDesc;

}
