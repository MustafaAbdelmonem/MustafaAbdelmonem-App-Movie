package com.etisalat.subscriptionparameterizedoffer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.etisalat.subscriptionparameterizedoffer.mappers.SubRequestParamMapper;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTDB;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTRM;
import com.etisalat.subscriptionparameterizedoffer.repository.ISubRequestParamTrmRepository;
import com.etisalat.subscriptionparameterizedoffer.service.ISubRequestParamTrmService;

@Transactional
@Service("subRequestParamTrmService")
public class SubRequestParamTrmServiceImpl implements ISubRequestParamTrmService {
	
	@Autowired
	ISubRequestParamTrmRepository subRequestParamTrmRepository;
	
	@Override
	public void saveOrUpdateSubRequestParam(List<SubRequestParamTRM> entities) {
		subRequestParamTrmRepository.save(entities);
	}
	
	@Override
	public void saveOrUpdateSubRequestParamByMappingTdbToTrm(List<SubRequestParamTDB> entities) {
		List<SubRequestParamTRM> subTrms = new ArrayList<>();
		entities.stream().forEach(entity -> {
			entity.setSubscriptionTemplateFlag('Y');
			subTrms.add(SubRequestParamMapper.instance.subTdbEntityToTrmEntity(entity));
		});
		saveOrUpdateSubRequestParam(subTrms);
	}

	@Override
	public Integer getMaxRequestParamId() {
		return subRequestParamTrmRepository.getMaxRequestParamId();
	}
	
}
