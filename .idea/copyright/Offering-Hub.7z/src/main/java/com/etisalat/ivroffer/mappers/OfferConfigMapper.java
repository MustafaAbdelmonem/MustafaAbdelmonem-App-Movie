package com.etisalat.ivroffer.mappers;

public interface OfferConfigMapper {

}
