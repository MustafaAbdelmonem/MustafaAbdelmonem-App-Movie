package com.etisalat.ivroffer.dto;

import lombok.Data;

@Data
public class OfferingConfigDTO {

	private Integer offeringId;
	private String channelName;
	private String treeId;
	private String interactiveFlag;
	private String promptName;
	private char deleteFlag;
}
