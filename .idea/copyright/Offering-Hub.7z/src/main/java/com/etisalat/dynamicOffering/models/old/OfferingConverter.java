package com.etisalat.dynamicOffering.models.old;

import java.io.Serializable;

import lombok.Data;

@Data
public class OfferingConverter implements Serializable {

	protected long converterType;
	protected long validity;
	protected float rate;
	protected float fees;
	protected String paymentMethod;

}
