package com.etisalat.dynamicOffering.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.dynamicOffering.controller.AbstractBaseController;
import com.etisalat.dynamicOffering.controller.util.APIResponse;
import com.etisalat.dynamicOffering.service.OfferingValService;

/**
 * @author O-Mostafa.Teba
 *
 */
@RestController
@RequestMapping("api/v1/offering-val")
public class OfferingValController extends AbstractBaseController{
	
	@Autowired
	OfferingValService offeringValService;
	
	@RequestMapping(value = "/list", method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findAll() {
		return responseUtil.successResponse(offeringValService.findAll());
	}
	
	@RequestMapping(value = "/service/{service-id}", method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findServiceCategoryByTemplate(@PathVariable("service-id") Integer serviceId) {
		return responseUtil.successResponse(offeringValService.findByServiceId(serviceId));
	}
}





