package com.etisalat.dynamicOffering.enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public enum TrafficCase {

	UNIT("Unit"),
	POOL("Pool"),
	MIXED("Mixed"),
	VOUCHER("Voucher"),
	DYNAMIC_DISCOUNT("Dynamic Discount"),
	MULTIPLE_QUOTA("Multiple quota"),
	MONTH_ON_OFF("Month on month off"),
	VOUCHER_UBER("Voucher Uber"),
	VOUCHER_FAWRY("Voucher Fawry"),
	HYBRID_FEATURES("Hybrid Features"),
	USAGE_PERCENTAGE("Usage Percentage"),
	MORE_PLUS("More Plus"),
	Partial_Renewal("Partial_Renewal");
	
	
	
	private String name;

	TrafficCase(String name) {
		this.name = name;
	}
	
	public static  List<Properties> getAllData(){
		List<Properties> data = new ArrayList<Properties>();
		for(TrafficCase tc : TrafficCase.values()) {
			Properties prop = new Properties();
			prop.put("name", tc.name);
			data.add(prop);
		}
		return data;
	}
	
	public static  List<Properties> getData(List<TrafficCase> list){
		List<Properties> data = new ArrayList<Properties>();
		for(TrafficCase tc : list) {
			Properties prop = new Properties();
			prop.put(tc.toString(), tc.name);
			data.add(prop);
		}
		return data;
	}
	
}
