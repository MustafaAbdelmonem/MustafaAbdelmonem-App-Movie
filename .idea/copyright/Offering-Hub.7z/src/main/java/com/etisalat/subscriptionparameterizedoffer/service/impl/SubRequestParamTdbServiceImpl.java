package com.etisalat.subscriptionparameterizedoffer.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.etisalat.subscriptionparameterizedoffer.dto.SubscriptionParameterizedOfferDTO;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTDB;
import com.etisalat.subscriptionparameterizedoffer.repository.ISubRequestParamTdbRepository;
import com.etisalat.subscriptionparameterizedoffer.repository.ISubRequestParamVDBRepository;
import com.etisalat.subscriptionparameterizedoffer.service.ISubRequestParamTdbService;
import com.etisalat.subscriptionparameterizedoffer.service.ISubRequestParamTrmService;

@Transactional
@Service("subRequestParamTdbService")
public class SubRequestParamTdbServiceImpl implements ISubRequestParamTdbService {
	
	@Autowired
	ISubRequestParamTdbRepository subRequestParamTdbRepository;
	
	@Autowired
	ISubRequestParamVDBRepository subRequestParamVdbService;
	
	@Autowired
	ISubRequestParamTrmService subRequestParamTrmService;
	
	Integer startRequestParamId;
	
	@Override
	public void updateSubRequestParam(List<SubRequestParamTDB> entities, SubscriptionParameterizedOfferDTO dto) {
		List<SubRequestParamTDB> newParams = entities.stream().filter(newItem -> newItem.getRequestParamId() == null).collect(Collectors.toList());
		List<SubRequestParamTDB> oldParams = entities.stream().filter(newItem -> newItem.getRequestParamId() != null).collect(Collectors.toList());
		List<SubRequestParamTDB> allParams = new ArrayList<>();
		
		if(newParams != null && !newParams.isEmpty()) {
			Integer maxTdbRequestParamId = subRequestParamTdbRepository.getMaxRequestParamId();
			Integer maxTrmRequestParamId = subRequestParamTrmService.getMaxRequestParamId();
			Integer maxVdbRequestParamId = subRequestParamVdbService.getMaxRequestParamId();
			
			int compareTdbValueWithTrm = Integer.valueOf(maxTdbRequestParamId != null ? maxTdbRequestParamId : 0).compareTo(Integer.valueOf(maxTrmRequestParamId != null ? maxTrmRequestParamId : 0));
			Integer maxId = (compareTdbValueWithTrm == 0) ? maxTdbRequestParamId + 1 : (compareTdbValueWithTrm > 0) ? maxTdbRequestParamId + 1 : maxTrmRequestParamId + 1;
			
			int compareValue = Integer.valueOf(maxId != null ? maxId : 0).compareTo(Integer.valueOf(maxVdbRequestParamId != null ? maxVdbRequestParamId : 0));
			startRequestParamId = (compareValue == 0) ? maxId + 1 : (compareValue > 0) ? maxId + 1 : maxVdbRequestParamId + 1;

//			if(maxTdbRequestParamId == maxTrmRequestParamId)
//				startRequestParamId = maxTdbRequestParamId + 1;
//			else if (maxTdbRequestParamId > maxTrmRequestParamId)
//				startRequestParamId = maxTdbRequestParamId + 1;
//			else 
//				startRequestParamId = maxTrmRequestParamId + 1;
			newParams.stream().forEach(item -> {
				item.setRequestParamId(startRequestParamId);
				dto.getOfferParamValue().stream().filter(param -> param.getRequestParamName().equals(item.getRequestParamName())).findFirst().get().setRequestParamId(startRequestParamId);
				startRequestParamId++;
			});
			allParams.addAll(newParams);
		} 
		if(oldParams != null && !oldParams.isEmpty()) {
			allParams.addAll(oldParams);
		}
		subRequestParamTdbRepository.save(allParams);
		subRequestParamTrmService.saveOrUpdateSubRequestParamByMappingTdbToTrm(allParams);
		
		
	}

	@Override
	public void saveSubRequestParam(List<SubRequestParamTDB> subRequestParamTDB, SubscriptionParameterizedOfferDTO dto) {
		
		if(subRequestParamTDB != null && !subRequestParamTDB.isEmpty()) {
			List<String> paramNames = subRequestParamTDB.stream().map(SubRequestParamTDB::getRequestParamName).collect(Collectors.toList());
			List<SubRequestParamTDB> existParams = subRequestParamTdbRepository.findInRequestParamName(paramNames);
			if(existParams != null && !existParams.isEmpty()) {
				Map<String, Integer> map = new HashMap<>();
				existParams.stream().forEach(param -> {
					map.put(param.getRequestParamName(), param.getRequestParamId());
				});
				subRequestParamTDB.stream().forEach(item -> {
					item.setRequestParamId(map.get(item.getRequestParamName()));
					item.setSubscriptionTemplateFlag(item.getSubscriptionTemplateFlag());
					dto.getOfferParamValue().stream().filter(param -> param.getRequestParamName().equals(item.getRequestParamName())).findFirst().get().setRequestParamId(item.getRequestParamId());
				});
			} else {
				Integer maxTdbRequestParamId = subRequestParamTdbRepository.getMaxRequestParamId();
				Integer maxTrmRequestParamId = subRequestParamTrmService.getMaxRequestParamId();
				int compareValue = Integer.valueOf(maxTdbRequestParamId != null ? maxTdbRequestParamId : 0).compareTo(Integer.valueOf(maxTrmRequestParamId != null ? maxTrmRequestParamId : 0));
				startRequestParamId = (compareValue == 0) ? maxTdbRequestParamId + 1 : (compareValue > 0) ? maxTdbRequestParamId + 1 : maxTrmRequestParamId + 1;
//				if(maxTdbRequestParamId == maxTrmRequestParamId)
//					startRequestParamId = maxTdbRequestParamId + 1;
//				else if (maxTdbRequestParamId > maxTrmRequestParamId)
//					startRequestParamId = maxTdbRequestParamId + 1;
//				else 
//					startRequestParamId = maxTrmRequestParamId + 1;
				subRequestParamTDB.stream().forEach(item -> {
					item.setRequestParamId(startRequestParamId);
					item.setSubscriptionTemplateFlag(item.getSubscriptionTemplateFlag());
					dto.getOfferParamValue().stream().filter(param -> param.getRequestParamName().equals(item.getRequestParamName())).findFirst().get().setRequestParamId(startRequestParamId);
					startRequestParamId++;
				});
			}
			subRequestParamTdbRepository.save(subRequestParamTDB);
			subRequestParamTrmService.saveOrUpdateSubRequestParamByMappingTdbToTrm(subRequestParamTDB);
		} 
	}
}
