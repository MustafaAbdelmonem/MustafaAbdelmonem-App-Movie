package com.etisalat.subscriptionoffer.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.etisalat.subscriptionoffer.model.SubscriptionOfferingCatalog;
import com.etisalat.subscriptionoffer.repository.OfferingCatalogRepo;
import com.etisalat.subscriptionoffer.service.IOfferingCatalogService;


@Transactional
@Service("subCatalogService")
public class OfferingCatalogServiceImpl implements IOfferingCatalogService {

	@Autowired
	OfferingCatalogRepo offeringCatalogRepo;
	
	@Override
	public void delete(Integer offeringId) {
		offeringCatalogRepo.deleteByOfferingId(offeringId);
//		offeringCatalogRepo.deleteOffer(offeringId);
	}
	
	@Override
	public void saveOrUpdateOfferingCatalog(SubscriptionOfferingCatalog catalog) {
		offeringCatalogRepo.save(catalog);
	}
	
	@Override
	public void deleteOfferingCatalog(Integer offeringId) {
		offeringCatalogRepo.deleteOfferingCatalog(offeringId);
	}
}
