package com.etisalat.subscriptionparameterizedoffer.service;

import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOfferingCatalog;

public interface IOfferingCatalogService {

	void delete(Integer offeringId);

	void updateOfferingCatalog(SubscriptionParameterizedOfferingCatalog catalog);

	void deleteOfferingCatalog(Integer offeringId);

}
