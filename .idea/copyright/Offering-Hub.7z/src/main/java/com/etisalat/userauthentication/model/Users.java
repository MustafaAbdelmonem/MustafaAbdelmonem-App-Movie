package com.etisalat.userauthentication.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "OFFERING_HUB_USERS", schema = "TRM_META_T",uniqueConstraints= {
		@UniqueConstraint(columnNames= {"user_Name"})
})
public class Users implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -2532459881328310033L;
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "user_id")
	private Integer userId;
	
	@Column(name = "user_name")
	private String userName;
	
	@Column(name = "user_password")
	private String userPassword;

}
