package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class PxOfferDTO {

	private int id;
	private OfferDefinitionDTO definition;
	private OfferConfigurationDTO configuration;
	//TODO to be updated later
	private OfferContradictionDTO contradiction;
}
