package com.etisalat.dynamicOffering.database.trm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingVal;

/**
 *
 * @author O-Mostafa.Teba
 */
public interface OfferingValRepositoryTrm extends JpaRepository<OfferingVal, Integer> {

	List<OfferingVal> findByServiceId(Integer serviceId);
	
}