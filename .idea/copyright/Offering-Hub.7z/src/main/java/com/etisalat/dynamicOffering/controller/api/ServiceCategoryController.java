package com.etisalat.dynamicOffering.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.dynamicOffering.controller.AbstractBaseController;
import com.etisalat.dynamicOffering.controller.util.APIResponse;
import com.etisalat.dynamicOffering.service.ServiceCategoryService;

@RestController
@RequestMapping(APIName.SERVICE_CATEGORY)
public class ServiceCategoryController extends AbstractBaseController{
	
	@Autowired
	ServiceCategoryService serviceCategoryService;
	
	@RequestMapping(value = APIName.SERVICE_CATEGORY_LIST, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findServiceCategory() {
		return responseUtil.successResponse(serviceCategoryService.findServiceCategory());
	}
	
	@RequestMapping(value = APIName.SERVICE_CATEGORY_BY_TEMPATE_ID, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findServiceCategoryByTemplate(@PathVariable("template_id") Integer templateId) {
		return responseUtil.successResponse(serviceCategoryService.findServiceCategoryByTemplateId(templateId));
	}
}





