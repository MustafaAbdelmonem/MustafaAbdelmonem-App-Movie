package com.etisalat.ivroffer.model;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.etisalat.common.model.CustomOfferEntity;

import lombok.Data;

@Entity
@Data
@Table(name = "Offering", schema = "VDB")
public class OfferingVDB extends CustomOfferEntity {

	private static final long serialVersionUID = -7278290828250885934L;
	
	@Transient
	private OfferingCatalogVDB catalog;
	
	@Transient
	private OfferingConfigVDB config;
}
