package com.etisalat.common.model;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import lombok.Data;

@MappedSuperclass
@Data
public class CustomOfferEntity extends OfferEntity {

	private static final long serialVersionUID = 7569290683796873430L;
	
	
	@Column(name = "Delete_Flag", columnDefinition = "char(1) default N")
	private char deleteFlag = 'N';

}
