package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingChannel;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingChannelRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingChannelTRM;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingChannelRepositoryTrm;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.rtim.integration.RTIMintegration;
import com.google.gson.Gson;


@Service
public class OfferingChannelsService extends AbstractBaseService {

	@Autowired
	OfferingChannelRepositoryTrm offeringChannelRepositoryTrm;

	@Autowired
	OfferingChannelRepositoryOds offeringChannelRepositoryOds;
	
	RTIMintegration rTIMintegration = new RTIMintegration();
	
	@Autowired
	Gson gson;

	
	@Transactional()
	public List<OfferingChannelTRM> findAll() {
		return offeringChannelRepositoryTrm.findAll();
	}
	
	@Transactional()
	public void insertOfferingChannels(OfferingChannel offeringChannel) {
		
		offeringChannelRepositoryOds.save(offeringChannel);
		
		offeringChannelRepositoryTrm.save(DynamicOfferingMapper.instance.mapOfferingChannelToTRM(offeringChannel));
		
		//return true;
	}
	
	@Transactional()
	public void insertOfferingChannelsList(List<OfferingChannel> offeringChannels, List<OfferingChannelTRM> OfferingChannelsTRM) {
		offeringChannelRepositoryTrm.save(OfferingChannelsTRM);
		offeringChannelRepositoryOds.save(offeringChannels);
		offeringChannels.stream().forEach(channel -> {
			try {
				rTIMintegration.insertRTIMDB(gson.toJson(channel),"px_Offering_Channel");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	}

}
