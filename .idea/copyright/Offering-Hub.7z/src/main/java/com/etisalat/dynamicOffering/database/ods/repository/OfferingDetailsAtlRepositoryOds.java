package com.etisalat.dynamicOffering.database.ods.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsAtl;
/**
*
* @author O-Mostafa.Teba
*/
public interface OfferingDetailsAtlRepositoryOds extends JpaRepository<OfferingDetailsAtl, Integer> {

}