package com.etisalat.dynamicOffering.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.factory.Mappers;

import com.etisalat.dynamicOffering.controller.api.request.DynOfferingParameterDTO;
import com.etisalat.dynamicOffering.controller.api.request.OfferPxDynOfferingConverter;
import com.etisalat.dynamicOffering.controller.api.request.OfferPxDynOfferingParametersDTO;
import com.etisalat.dynamicOffering.controller.api.request.OfferPxOfferingCapping;
import com.etisalat.dynamicOffering.controller.api.request.OfferingDTO;
import com.etisalat.dynamicOffering.controller.api.request.OfferingDetailsDTO;
import com.etisalat.dynamicOffering.database.ods.entity.DynOfferingConverter;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingBonus;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingCapping;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingChannel;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingContradiction;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsAtl;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsBtl;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingRateplan;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingThreshold;
import com.etisalat.dynamicOffering.database.ods.entity.PxDynOfferingParameters;
import com.etisalat.dynamicOffering.database.trm.entity.DynOfferingConverterTRM;
import com.etisalat.dynamicOffering.database.trm.entity.DynOfferingParameterTRM;
import com.etisalat.dynamicOffering.database.trm.entity.Offering;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingBonusTRM;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingCappingTRM;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingChannelTRM;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingContradictionTRM;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingDetails;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingRateplanTRM;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingThresholdTRM;

@Mapper()
public interface DynamicOfferingMapper {

	
	
	DynamicOfferingMapper instance = Mappers.getMapper(DynamicOfferingMapper.class);
	
	
	/*
	 * 
	 * */
	@Mappings({ @Mapping(target = "offeringDesc", source = "dto.offeringName")})
	Offering mapOfferingEntity(OfferingDTO dto);

	OfferingDTO mapOfferingDTO(Offering entity);

	/*
	 * mapping OfferingDetails Response and Request
	 * 
	 */

	OfferingDetails mapOfferingTrmEntity(OfferingDetailsDTO dto);

	OfferingDetailsDTO mapOfferingTrmDTO(OfferingDetails entity);

	
	OfferingDetailsAtl mapOfferingAtlEntity(OfferingDetailsDTO dto);
	
	OfferingDetailsDTO mapOfferingAtlDTO(OfferingDetailsAtl entity);
	
	
	OfferingDetailsBtl mapOfferingBtlEntity(OfferingDetailsDTO dto);

	OfferingDetailsDTO mapOfferingBtlDTO(OfferingDetailsBtl entity);

	/*
	 * mapping threshold Response and Request
	 * 
	 */

	
	OfferingThreshold mapOfferingThresholdTRMlEntity(OfferingThresholdTRM entity);

	OfferingThresholdTRM mapOfferingThresholdEntity(OfferingThreshold entity);
	
//	List<OfferingThreshold> mapOfferingThresholdDTO(List<OfferingThreshold> entity);
//
//	List<OfferingThreshold> mapOfferingThresholdEntity(List<OfferingThresholdDTO> dto);

	/*
	 * 
	 */
//
//	List<OfferingBonusDTO> mapOfferingBonusDTO(List<OfferingBonus> entity);
//
//	List<OfferingBonus> mapOfferingBonusEntity(List<OfferingBonusDTO> dto);
	
	

	OfferingBonus mapOfferingBonusEntityOds(OfferingBonusTRM entity);

	OfferingBonusTRM mapOfferingBonusEntityTRM(OfferingBonus entity);
	
	/*
	 * mapping Offering Parameter Response and Request
	 * 
	 */
	
	
	DynOfferingParameterTRM mapDynOfferingParameterEntityTRM(PxDynOfferingParameters entity);

	PxDynOfferingParameters mapDynOfferingParameterEntity( DynOfferingParameterTRM entity);
	
	PxDynOfferingParameters mapDtoToDynOfferingParameter( OfferPxDynOfferingParametersDTO dto);
	

	List<DynOfferingParameterDTO> mapDynOfferingParameterDTO(List<PxDynOfferingParameters> entity);

	List<PxDynOfferingParameters> mapDynOfferingParameterEntity(List<DynOfferingParameterDTO> dto);

	/*
	 * mapping Channels Response and Request
	 * 
	 */
	
	

	OfferingChannel mapOfferingChannelToOds(OfferingChannelTRM entity);

	OfferingChannelTRM mapOfferingChannelToTRM(OfferingChannel entity);
	

//	List<OfferingChannelDTO> mapOfferingChannelsDTO(List<OfferingChannel> entity);
//
//	List<OfferingChannel> mapOfferingChannelsEntity(List<OfferingChannelDTO> dto);

	
	/*
	 * mapping Offering Contradiction Response and Request
	 * 
	 */

//	List<OfferingContradictionDTO> mapOfferingContradictionsDTO(List<OfferingContradiction> entity);
//
//	List<OfferingContradiction> mapOfferingContradictionsEntity(List<OfferingContradictionDTO> dto);
	OfferingContradiction mapOfferingContradictionEntityOds( OfferingContradictionTRM entity);

	OfferingContradictionTRM mapOfferingContradictionEntityTRM(OfferingContradiction entity);	
	
	/*
	 * mapping Offering Contradiction Response and Request
	 * 
	 */

	OfferingCapping mapDtoToDynOfferingCappingEntityODS(OfferPxOfferingCapping dto);
	
	OfferingCappingTRM mapDynOfferingCappingEntityTRM(OfferingCapping entity);

	OfferingCapping mapDynOfferingCappingEntityODS(OfferingCappingTRM entity);
	
	
	/*
	 * mapping Offering Rateplan Response and Request
	 * 
	 */

//	List<OfferingRateplanDTO> mapOfferingRateplansDTO(List<OfferingRateplan> entity);
//
//	List<OfferingRateplan> mapOfferingRateplansEntity(List<OfferingRateplanDTO> dto);

	
	OfferingRateplan mapOfferingRateplanEntityOds(OfferingRateplanTRM entity);

	OfferingRateplanTRM mapOfferingRateplanEntityTRM(OfferingRateplan entity);
	

	/*
	 * mapping Dyn Offering Converter Response and Request
	 * 
	 */

	DynOfferingConverterTRM mapDynOfferingConverterTRM(DynOfferingConverter entity);

	DynOfferingConverter mapDynOfferingConverterOds(DynOfferingConverterTRM entity);
	
	DynOfferingConverter mapDtoToDynOfferingConverterOds(OfferPxDynOfferingConverter dto);
	
	
	OfferingDetailsAtl mapOfferingDetailsToAtlEntity(OfferingDetails dto);
	
	OfferingDetails mapOfferingAtlOfferingDetails(OfferingDetailsAtl entity);
	
	
	OfferingDetailsBtl mapOfferingDetailsToBtlEntity(OfferingDetails dto);

	OfferingDetails mapOfferingBtlOfferingDetails(OfferingDetailsBtl entity);
	
}
