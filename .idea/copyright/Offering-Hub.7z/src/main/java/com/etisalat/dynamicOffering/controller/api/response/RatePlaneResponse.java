package com.etisalat.dynamicOffering.controller.api.response;

import java.util.List;

import lombok.Data;

@Data
public class RatePlaneResponse {
	private Integer id;
	private String text;
	private List<RatePlaneResponse> children;
}
