package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferPxOfferingTemplates {

	private Integer templateId;
	private boolean templateIdNull = true;
	private String templateName;
}
