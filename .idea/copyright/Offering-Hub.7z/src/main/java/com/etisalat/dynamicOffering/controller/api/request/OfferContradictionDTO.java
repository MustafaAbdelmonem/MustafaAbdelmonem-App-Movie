package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferContradictionDTO {

	private OfferPxServiceCategoryDTO pxServiceCategory;
	
	
}
