package com.etisalat.subscriptionparameterizedoffer.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.transaction.Transactional;
import javax.xml.bind.ValidationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.etisalat.common.constant.EtisalatConstant;
import com.etisalat.subscriptionparameterizedoffer.dto.OfferParamValueDTO;
import com.etisalat.subscriptionparameterizedoffer.dto.SubscriptionParameterizedOfferDTO;
import com.etisalat.subscriptionparameterizedoffer.mappers.OfferParamValueMapper;
import com.etisalat.subscriptionparameterizedoffer.model.OfferingSubRequestParam;
import com.etisalat.subscriptionparameterizedoffer.model.OfferingSubRequestParamVDB;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTDB;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTRM;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamVDB;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOffer;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOfferVDB;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOfferingCatalogVDB;
import com.etisalat.subscriptionparameterizedoffer.model.TsiProcessConfig;
import com.etisalat.subscriptionparameterizedoffer.repository.ISubscriptionParameterizedRepository;
import com.etisalat.subscriptionparameterizedoffer.repository.VDBISubscriptionParameterizedRepository;
import com.etisalat.subscriptionparameterizedoffer.service.IOfferingCatalogService;
import com.etisalat.subscriptionparameterizedoffer.service.IOfferingSubRequestParamService;
import com.etisalat.subscriptionparameterizedoffer.service.ISubRequestParamTdbService;
import com.etisalat.subscriptionparameterizedoffer.service.ISubRequestParamTrmService;
import com.etisalat.subscriptionparameterizedoffer.service.ISubscriptionParameterizedService;
import com.etisalat.subscriptionparameterizedoffer.service.ITsiProcessConfigService;

@Transactional
@Service("subscriptionParameterizedService")
public class SubscriptionParameterizedServiceImpl implements ISubscriptionParameterizedService {
	
	private static final Log LOGGER = LogFactory.getLog(SubscriptionParameterizedServiceImpl.class);

	@Autowired
	ISubscriptionParameterizedRepository subscriptionRepository;
	
	@Autowired
	VDBISubscriptionParameterizedRepository vdbSubParamRepository;
	
	@Autowired
	IOfferingCatalogService catalogService;
	
	@Autowired
	ITsiProcessConfigService tsiProcessConfigService;
	
	@Autowired
	IOfferingSubRequestParamService offeringSubRequestParamService;
	
	@Autowired
	ISubRequestParamTdbService subRequestParamTdbService;
	
	@Autowired
	ISubRequestParamTrmService subRequestParamTrmService;
	
	SubscriptionParameterizedOfferVDB offer;
	
	@Override
	public SubscriptionParameterizedOfferVDB getOfferByOfferId(Integer offeringId) {
//		SubscriptionParameterizedOffer offer = new SubscriptionParameterizedOffer();
		Object[] object = vdbSubParamRepository.findByOfferingId(offeringId, EtisalatConstant.PERSONALIZED_SUBSCRIPTION_GROUP);
		if(object != null & object.length > 0) {
			offer = (SubscriptionParameterizedOfferVDB)(((Object[]) object[0])[EtisalatConstant.OFFERING_INDEX]);
			offer.setCatalog((SubscriptionParameterizedOfferingCatalogVDB)(((Object[]) object[0])[EtisalatConstant.OFFERING_CATALOG_INDEX]));
			offer.setTsiProcessConfig((TsiProcessConfig)(((Object[]) object[0])[EtisalatConstant.TSI_PROCESS_CONFIG]));
			if(offer.getTsiProcessConfig() != null) {
				if(offer.getTsiProcessConfig().getConfigKey().equals(EtisalatConstant.PERSONALIZEDSUBSCRIPTION_ONLINEDB_SERVICES)) {
					offer.getTsiProcessConfig().setBatchDB(false);
					offer.getTsiProcessConfig().setCommandTxt(null);
				} else if(offer.getTsiProcessConfig().getConfigKey().equals(EtisalatConstant.PERSONALIZEDSUBSCRIPTION_SERVICES_COMMANDS)) {
					offer.getTsiProcessConfig().setBatchDB(true);
					String tsiParam = Arrays.asList(offer.getTsiProcessConfig().getConfigValue().split(";")).stream().filter(tsi -> tsi.split("=")[0].trim().equals(offer.getServiceName())).findFirst().get();
					offer.getTsiProcessConfig().setCommandTxt(tsiParam.split("=")[1]);
				}
			}
			for (Object obj : object) {
				offer.getSubRequestParamTRM().add(((SubRequestParamTRM)(((Object[]) obj)[EtisalatConstant.SUB_REQUEST_PARAM_TRM])));
				offer.getSubRequestParamTDB().add((SubRequestParamVDB)(((Object[]) obj)[EtisalatConstant.SUB_REQUEST_PARAM_TDB]));
				offer.getOfferingSubRequestParam().add(((OfferingSubRequestParamVDB)(((Object[]) obj)[EtisalatConstant.OFFERING_SUB_REQUEST_PARAM])));
				offer.getOfferParamValue().add(handleOfferParamValue((SubRequestParamVDB)(((Object[]) obj)[EtisalatConstant.SUB_REQUEST_PARAM_TDB]),
						((OfferingSubRequestParamVDB)(((Object[]) obj)[EtisalatConstant.OFFERING_SUB_REQUEST_PARAM]))));
			}
		}
		return offer;
	}

	@Override
	public void saveOffer(SubscriptionParameterizedOffer offer, SubscriptionParameterizedOfferDTO dto) throws ValidationException {
		Integer maxOfferingId = vdbSubParamRepository.findMaxOfferingId();
		offer.setOfferingId(maxOfferingId+1);
		offer.setStartDttm(new Date());
		offer.setDwhEntryDate(new Date());
		offer.setAccountGroupFlag("D");
		offer.setOfferingDesc(offer.getOfferingName());
		offer.setDeleteFlag('N');
		subscriptionRepository.save(offer);
		if(offer.getOfferingId() != null) {
			LOGGER.debug("subscription parameterized Offer Saved Successfully with Id: " + offer.getOfferingId());
			dto.setOfferingId(offer.getOfferingId());
			
			/** save offering catalog **/
			offer.getCatalog().setOfferingId(offer.getOfferingId());
			offer.getCatalog().setDeleteFlag('N');
			catalogService.updateOfferingCatalog(offer.getCatalog());
			LOGGER.debug("Offering_Catalog saved successfully for subscription parameterized Offer Id: " + offer.getOfferingId());
			
			/** save tsi process config **/
			tsiProcessConfigService.saveOrUpdateTsiProcessConfig(offer.getTsiProcessConfig().isBatchDB(), offer.getServiceName(), offer.getTsiProcessConfig().getCommandTxt());
			LOGGER.debug("tsi_process_config saved successfully for subscription parameterized Offer Id: " + offer.getOfferingId());
			
			/** save Sub Request Param **/
			subRequestParamTdbService.saveSubRequestParam(offer.getSubRequestParamTDB(), dto);
			LOGGER.debug("sub_request_Param saved successfully for subscription parameterized Offer Id: " + offer.getOfferingId());
			
			/** save Offering Sub Request Param **/
			offeringSubRequestParamService.saveOfferingSubRequestParam(offer.getOfferingSubRequestParam(), dto);
			LOGGER.debug("offering_sub_request_param saved successfully for subscription parameterized Offer Id: " + offer.getOfferingId());
		} else {
			LOGGER.error("Saving subscription parameterized Offer Error:  Offering Id must not be null!");
			throw new ValidationException("Offering Id must not be null !");
		}
	}

	@Override
	public void updateOffer(SubscriptionParameterizedOffer offer, SubscriptionParameterizedOfferDTO dto) throws ValidationException {
		
		offer.setAccountGroupFlag("D");
		offer.setOfferingDesc(offer.getOfferingName());
		offer.setDeleteFlag('N');
		subscriptionRepository.save(offer);
		LOGGER.debug("Offering is updated successfully for subscription parameterized Offer Id: " + offer.getOfferingId());
		
		dto.setOfferingId(offer.getOfferingId());
		
		/** update offering config **/
		offer.getCatalog().setDeleteFlag('N');
		catalogService.updateOfferingCatalog(offer.getCatalog());
		LOGGER.debug("Offering_Catalog is updated successfully for subscription parameterized Offer Id: " + offer.getOfferingId());
		
		/** update tsi process config **/
		tsiProcessConfigService.saveOrUpdateTsiProcessConfig(offer.getTsiProcessConfig().isBatchDB(), offer.getServiceName(), offer.getTsiProcessConfig().getCommandTxt());
		LOGGER.debug("TSI_PROCESS_CONFIG is updated successfully for subscription parameterized Offer Service Name: " + offer.getServiceName());
		
		/** update Sub Request Param **/
		subRequestParamTdbService.updateSubRequestParam(offer.getSubRequestParamTDB(), dto);
		LOGGER.debug("Sub_Request_param is updated successfully for subscription parameterized Offer");
		
		/** update Offering Sub Request Param **/
		offeringSubRequestParamService.updateOfferingSubRequestParam(offer, dto);
		LOGGER.debug("Offering_Sub_Request_param is updated successfully for subscription parameterized Offer Id: " + offer.getOfferingId());
	}

	@Override
	public void delete(Integer offeringId) {
		catalogService.deleteOfferingCatalog(offeringId);
		LOGGER.debug("update TRM_LEAD.offering_catalog delete_flag with 'Y' for subscription parameterized offer Id: " + offeringId);
		
		offeringSubRequestParamService.deleteParameters(offeringId);
		LOGGER.debug("update TRM_LEAD.offering_sub_request_param delete_flag with 'Y' for subscription parameterized offer Id: " + offeringId);
		
		subscriptionRepository.deleteSubParamOffer(offeringId);
		LOGGER.debug("update TRM_LEAD.offering delete_flag with 'Y' for subscription parameterized offer Id: " + offeringId);
	}

	@Override
	public List<SubscriptionParameterizedOfferVDB> listSubscriptionOffers(int start, int pageSize) {
		List<SubscriptionParameterizedOfferVDB> subscriptionOfferings = new ArrayList<>();
		List<Object[]> paginatedList = vdbSubParamRepository.listSubscriptionOffersVDB(new PageRequest(start, pageSize),EtisalatConstant.PERSONALIZED_SUBSCRIPTION_GROUP);
		Map<Integer, SubscriptionParameterizedOfferVDB> map = new HashMap<>();
		paginatedList.stream().forEach(item -> {
			offer = (SubscriptionParameterizedOfferVDB)item[EtisalatConstant.OFFERING_INDEX];
			if(map.containsKey(offer.getOfferingId())) {
				map.get(offer.getOfferingId()).getSubRequestParamTRM().add((SubRequestParamTRM) item[EtisalatConstant.SUB_REQUEST_PARAM_TRM]);
				map.get(offer.getOfferingId()).getSubRequestParamTDB().add((SubRequestParamVDB) item[EtisalatConstant.SUB_REQUEST_PARAM_TDB]);
				map.get(offer.getOfferingId()).getOfferingSubRequestParam().add((OfferingSubRequestParamVDB) item[EtisalatConstant.OFFERING_SUB_REQUEST_PARAM]);
				//TODO not important for now
//				map.get(offer.getOfferingId()).getOfferParamValue().add(handleOfferParamValue((SubRequestParamTDB) item[EtisalatConstant.SUB_REQUEST_PARAM_TDB],
//						(OfferingSubRequestParam) item[EtisalatConstant.OFFERING_SUB_REQUEST_PARAM]));
			} else {
				offer.setCatalog((SubscriptionParameterizedOfferingCatalogVDB)item[EtisalatConstant.OFFERING_CATALOG_INDEX]);
				offer.setTsiProcessConfig((TsiProcessConfig) item[EtisalatConstant.TSI_PROCESS_CONFIG]);
				offer.getSubRequestParamTRM().add((SubRequestParamTRM) item[EtisalatConstant.SUB_REQUEST_PARAM_TRM]);
				offer.getSubRequestParamTDB().add((SubRequestParamVDB) item[EtisalatConstant.SUB_REQUEST_PARAM_TDB]);
				offer.getOfferingSubRequestParam().add((OfferingSubRequestParamVDB) item[EtisalatConstant.OFFERING_SUB_REQUEST_PARAM]);
//				offer.getOfferParamValue().add(handleOfferParamValue((SubRequestParamTDB) item[EtisalatConstant.SUB_REQUEST_PARAM_TDB],
//						(OfferingSubRequestParam) item[EtisalatConstant.OFFERING_SUB_REQUEST_PARAM]));
				map.put(offer.getOfferingId(), offer);
			}
		});
		subscriptionOfferings = map.values().stream().sorted(Comparator.comparingLong(SubscriptionParameterizedOfferVDB::getOfferingId).reversed()).collect(Collectors.toList());
		return subscriptionOfferings;
	}

	@Override
	public int getTotalCount() {
		return vdbSubParamRepository.getTotalCount(EtisalatConstant.PERSONALIZED_SUBSCRIPTION_GROUP);
	}
	
	private OfferParamValueDTO handleOfferParamValue(SubRequestParamVDB subRequestParam, OfferingSubRequestParamVDB offeringSubRequestParam) {
		OfferParamValueDTO paramValues = OfferParamValueMapper.instance.valuesToOfferParamValueDTOUsingVDB(offeringSubRequestParam);
		paramValues.setRequestParamName(subRequestParam.getRequestParamName());
		paramValues.setSubscriptionTemplateFlag(subRequestParam.getSubscriptionTemplateFlag());
		return paramValues;
	}

	@Override
	public boolean isOfferingNameOrDescDuplicated(String offeringName) {
//		return subscriptionRepository.isOfferingNameOrDescDuplicated(offeringName);
		return vdbSubParamRepository.findByOfferingNameOrOfferingDesc(offeringName, offeringName).isEmpty() ? false : true;
	}

}
