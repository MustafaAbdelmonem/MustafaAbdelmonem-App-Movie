package com.etisalat.common.configs;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
*
* @author O-Mostafa.Teba
*/

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "trmEntityManagerFactory",
        transactionManagerRef = "trmTransactionManager",
        basePackages = {"com.etisalat.dynamicOffering.database.trm.repository","com.etisalat.userauthentication.repository"})
public class TRM_DS_Config {

	@Autowired
	private Environment env;
	
    @Primary
    @Bean(name = "dataSource")
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Primary
    @Bean(name = "trmEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,   @Qualifier("dataSource") DataSource dataSource) {
        return builder.dataSource(dataSource)
                .packages("com.etisalat.dynamicOffering.database.trm.entity","com.etisalat.userauthentication.model")
                .properties(jpaProperties())
                .persistenceUnit("trm")
                .build();
    }

    @Primary
    @Bean(name = "trmTransactionManager")
    public PlatformTransactionManager transactionManager(@Qualifier("trmEntityManagerFactory") EntityManagerFactory  entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }


    private Map<String,Object> jpaProperties() {
        Map<String, Object> props = new HashMap<>();
        props.put("hibernate.physical_naming_strategy", env.getProperty("spring.jpa.hibernate.naming.physical-strategy"));
        props.put("hibernate.implicit_naming_strategy", env.getProperty("spring.jpa.hibernate.naming.implicit-strategy"));
        props.put("hibernate.hbm2ddl.auto", env.getProperty("spring.jpa.hibernate.ddl-auto"));
        props.put("hibernate.show-sql", env.getProperty("spring.jpa.show-sql"));
        
        return props;
    }
}
