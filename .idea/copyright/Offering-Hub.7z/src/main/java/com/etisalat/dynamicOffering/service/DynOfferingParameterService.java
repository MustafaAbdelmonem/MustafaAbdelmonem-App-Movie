package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.entity.PxDynOfferingParameters;
import com.etisalat.dynamicOffering.database.ods.repository.DynOfferingParameterRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.DynOfferingParameterTRM;
import com.etisalat.dynamicOffering.database.trm.repository.DynOfferingParameterRepositoryTrm;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.rtim.integration.RTIMintegration;
import com.google.gson.Gson;



@Service
public class DynOfferingParameterService extends AbstractBaseService {

	@Autowired
	DynOfferingParameterRepositoryOds dynOfferingParameterRepositoryOds;

	@Autowired
	DynOfferingParameterRepositoryTrm dynOfferingParameterRepositoryTrm;
	
	RTIMintegration rTIMintegration = new RTIMintegration();
	
	@Autowired
	Gson gson;

	@Transactional()
	public List<DynOfferingParameterTRM> findAll() {
		return dynOfferingParameterRepositoryTrm.findAll();
	}

	@Transactional()
	public void insertOfferingParameter(PxDynOfferingParameters dynOfferingParameter) throws Exception {
		dynOfferingParameterRepositoryOds.save(dynOfferingParameter);
		dynOfferingParameterRepositoryTrm.save(DynamicOfferingMapper.instance.mapDynOfferingParameterEntityTRM(dynOfferingParameter));
		rTIMintegration.insertRTIMDB(gson.toJson(dynOfferingParameter),"PX_DYN_OFFERING_PARAMETERS");
	}

	@Transactional()
	public void insertOfferingParameters(List<PxDynOfferingParameters> dynOfferingParameters, List<DynOfferingParameterTRM> dynOfferingParametersTrm) {
		dynOfferingParameterRepositoryOds.save(dynOfferingParameters);
		dynOfferingParameterRepositoryTrm.save(dynOfferingParametersTrm);
		dynOfferingParameters.stream().forEach(param -> {			
			try {
				rTIMintegration.insertRTIMDB(gson.toJson(param),"PX_DYN_OFFERING_PARAMETERS");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	}
	
}
