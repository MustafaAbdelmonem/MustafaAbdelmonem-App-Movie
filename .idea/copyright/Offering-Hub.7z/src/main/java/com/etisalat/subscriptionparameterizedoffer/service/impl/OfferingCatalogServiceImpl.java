package com.etisalat.subscriptionparameterizedoffer.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOfferingCatalog;
import com.etisalat.subscriptionparameterizedoffer.repository.OfferingCatalogRepo;
import com.etisalat.subscriptionparameterizedoffer.service.IOfferingCatalogService;


@Transactional
@Service("subParamCatalogService")
public class OfferingCatalogServiceImpl implements IOfferingCatalogService {

	@Autowired
	OfferingCatalogRepo offeringCatalogRepo;
	
	@Override
	public void delete(Integer offeringId) {
		offeringCatalogRepo.deleteByOfferingId(offeringId);
//		offeringCatalogRepo.deleteOffer(offeringId);
	}
	
	@Override
	public void updateOfferingCatalog(SubscriptionParameterizedOfferingCatalog catalog) {
		offeringCatalogRepo.save(catalog);
	}

	@Override
	public void deleteOfferingCatalog(Integer offeringId) {
		offeringCatalogRepo.deleteOfferingCatalog(offeringId);
	}
}
