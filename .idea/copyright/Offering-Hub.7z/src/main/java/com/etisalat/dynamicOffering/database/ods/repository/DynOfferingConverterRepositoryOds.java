package com.etisalat.dynamicOffering.database.ods.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.ods.entity.DynOfferingConverter;



public interface DynOfferingConverterRepositoryOds extends JpaRepository<DynOfferingConverter, Integer> {

}