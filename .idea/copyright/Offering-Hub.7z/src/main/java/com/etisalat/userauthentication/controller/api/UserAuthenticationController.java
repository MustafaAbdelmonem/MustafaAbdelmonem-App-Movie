package com.etisalat.userauthentication.controller.api;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.userauthentication.dto.UsersDTO;
import com.etisalat.userauthentication.mappers.UserMapper;
import com.etisalat.userauthentication.model.Users;
import com.etisalat.userauthentication.service.UserAuthenticationService;

import io.swagger.annotations.Api;

@RestController
@RequestMapping(APIName.USER_CONTROLLER)
@CrossOrigin(origins="*", maxAge=3600)
@Api("user controller api")	
public class UserAuthenticationController {
	

	
	private static final Log LOGGER = LogFactory.getLog(UserAuthenticationController.class);
	
	@Autowired
	UserAuthenticationService userService;
	
	@GetMapping
	public ResponseEntity<UsersDTO> getUserByName(@RequestParam("userName") String userName){
		try {
			UserMapper mapper = UserMapper.instance;
			Users user = userService.findUserByName(userName);
			return new ResponseEntity<>(mapper.userToDTO(user), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping
	public ResponseEntity<UsersDTO> LoginUser(@RequestBody UsersDTO dto){		
		try {
			Users loggedUser = userService.findUserByNameAndPassword(dto.getUserName(), dto.getUserPassword());
			return new ResponseEntity<>(UserMapper.instance.userToDTO(loggedUser), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}
		
	@PostMapping(path=APIName.USER_REGISTRATION)
	public ResponseEntity<UsersDTO> saveUser(@RequestBody UsersDTO dto){		
		try {
			Users user = UserMapper.instance.dtoToUser(dto);
			userService.saveUser(user);
			dto.setUserId(user.getUserId());
			return new ResponseEntity<>(dto, HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
		}
	}
	

}
