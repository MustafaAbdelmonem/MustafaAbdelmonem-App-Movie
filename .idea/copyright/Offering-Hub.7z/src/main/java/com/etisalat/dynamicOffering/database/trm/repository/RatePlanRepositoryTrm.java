package com.etisalat.dynamicOffering.database.trm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.etisalat.dynamicOffering.database.trm.entity.RatePlan;
/**
*
* @author O-Mostafa.Teba
*/
public interface RatePlanRepositoryTrm extends JpaRepository<RatePlan, Integer> {

	@Query("SELECT DISTINCT rp.ratePlanGroup FROM RatePlan rp")
	List<RatePlan> findDistinctRatePlanGroup();
	
	List<RatePlan> findByRatePlanGroup(String ratePlanGroup);
	
	List<RatePlan> findByRatePlanGroupIsNull();
} 