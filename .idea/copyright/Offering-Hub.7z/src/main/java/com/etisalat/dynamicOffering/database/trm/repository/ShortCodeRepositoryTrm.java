package com.etisalat.dynamicOffering.database.trm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.etisalat.dynamicOffering.database.trm.entity.Shortcode;
/**
*
* @author O-Mostafa.Teba
*/
public interface ShortCodeRepositoryTrm extends JpaRepository<Shortcode, Integer> {

	List<Shortcode> findByTemplateId(Integer templateId);
	
	@Query(value = "SELECT sc FROM Shortcode sc where sc.shortCode not in ( select od.shortCodeNum from OfferingDetails od where od.promotionPlanEndDt >= current_date ) and sc.templateId = ?1")
	List<Shortcode> findAvailableAtlShortcodes(Integer templateId);
	
	@Query(value = "SELECT sc FROM Shortcode sc where sc.shortCode not in ( select od.shortCodeNum from OfferingDetails od where od.promotionPlanEndDt >= current_date ) and sc.templateId = ?1")
	List<Shortcode> findAvailableBtlShortcodes(Integer templateId);
}