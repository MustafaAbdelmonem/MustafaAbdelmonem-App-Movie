package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "PX_OFFERING_THRESHOLD" , schema = "TRM_META")
@IdClass(OfferingThresholdId.class)
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class OfferingThresholdTRM implements Serializable
{
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_ID")
	private Integer offeringId;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "THRESHOLD_ID")
	private Integer thresholdId;

	@Column(name = "THRESHOLD_VALUE")
	private Float thresholdValue;
	
	@Column(name = "POOL_VALUE")
	private Float poolValue;
}