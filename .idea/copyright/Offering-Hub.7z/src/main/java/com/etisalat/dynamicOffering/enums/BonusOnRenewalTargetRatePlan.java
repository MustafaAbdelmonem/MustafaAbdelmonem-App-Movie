package com.etisalat.dynamicOffering.enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public enum BonusOnRenewalTargetRatePlan {
	
	VULCAN_1("Vulcan 1",2068),
	VULCAN_2("Vulcan 2",2069),
	VULCAN_3("Vulcan 3",2070),
	VULCAN_4("Vulcan 4",2071),
	TYPHOON_11("Typhoon 11",2072),
	TYPHOON_12("Typhoon 12",2073),
	TYPHOON_13("Typhoon 13",2074),
	TYPHOON_14("Typhoon 14",2075),
	TYPHOON_16("Typhoon 16",2076),
	TYPHOON_17("Typhoon 17",2077),
	TYPHOON_18("Typhoon 18",2078 );

	private String name;
	private Integer code;
	
	BonusOnRenewalTargetRatePlan(String name, Integer code) {
		this.name = name;
		this.code = code;
	}
	
	public static List<Properties> getData(){
		List<Properties> data = new ArrayList<Properties>();
		for(BonusOnRenewalTargetRatePlan rp : BonusOnRenewalTargetRatePlan.values()) {
			Properties prop = new Properties();
			prop.put("name", rp.name);
			prop.put("code", rp.code.toString());
			data.add(prop);
		}
		return data;
	}
	
}


