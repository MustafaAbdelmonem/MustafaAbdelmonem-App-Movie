package com.etisalat.dynamicOffering.service;

public class OfferService {

	
		
	
}
