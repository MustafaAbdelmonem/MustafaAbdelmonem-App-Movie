package com.etisalat.common.constant;

public class EtisalatConstant {
	
	public static final String COMMON_ERROR = "common error";
	
	public static final String COMMON_SAVED_SUCCESS = "saved successfully";
	public static final String COMMON_UPDATED_SUCCESS = "updated successfully";
	public static final String COMMON_DELETED_SUCCESS = "deleted successfully";
	
	public static final String COMMON_SAVED_ERROR = "error in saving";
	public static final String COMMON_UPDATED_ERROR = "error in updating";
	public static final String COMMON_DELETED_ERROR = "error in deleting";
		
	public static final int OFFERING_INDEX = 0;
	public static final int OFFERING_CATALOG_INDEX = 1;
	public static final int OFFERING_CONFIG_INDEX = 2;
	
	public static final String PERSONALIZEDSUBSCRIPTION_SERVICES_COMMANDS = "PersonalizedSubscription_Services_Commands";
	public static final String PERSONALIZEDSUBSCRIPTION_ONLINEDB_SERVICES = "PersonalizedSubscription_OnlineDB_Services";
	public static final String PERSONALIZED_SUBSCRIPTION_GROUP = "PersonalizedSubscription";
	
	public static final int OFFERING_SUB_REQUEST_PARAM = 2;
	public static final int SUB_REQUEST_PARAM_TDB = 3;
	public static final int SUB_REQUEST_PARAM_TRM = 4;
	public static final int TSI_PROCESS_CONFIG = 5;
	
	
	EtisalatConstant() {}

}
