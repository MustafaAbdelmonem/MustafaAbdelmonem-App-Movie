package com.etisalat.ivroffer.service;

import com.etisalat.ivroffer.model.OfferingConfig;

public interface IOfferingConfigService {

	void delete(Integer offeringId);

	void saveOrUpdateOfferingConfig(OfferingConfig config);

	void deleteOfferingConfig(Integer offeringId);

}
