package com.etisalat.dynamicOffering.enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public enum EligibleRatePlanBTL {
	
	AHLAN_HYBRIDS(0,"AHLAN & HYBRIDS"),
	AHLAN(1,"AHLAN"),
	HYBRIDS(2,"HYBRIDS");
	
	private Integer id;
	private String name;
	
	 EligibleRatePlanBTL(Integer id, String name) {
		this.id = id;
		this.name = name;
	}
	 
	 public static  List<Properties> getData(){
		List<Properties> data = new ArrayList<Properties>();
		for(EligibleRatePlanBTL bt : EligibleRatePlanBTL.values()) {
			Properties prop = new Properties();
			prop.put("name", bt.name);
			prop.put("id", bt.id.toString());
			data.add(prop);
		}
		return data;
	}
}
