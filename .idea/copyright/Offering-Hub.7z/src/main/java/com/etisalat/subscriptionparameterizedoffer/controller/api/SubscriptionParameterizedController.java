package com.etisalat.subscriptionparameterizedoffer.controller.api;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.common.message.response.ResponseMessage;
import com.etisalat.common.utils.AuthUtils;
import com.etisalat.common.utils.Constant;
import com.etisalat.subscriptionparameterizedoffer.attribute.SubscriptionParameterizedOfferDtoList;
import com.etisalat.subscriptionparameterizedoffer.dto.SubscriptionParameterizedOfferDTO;
import com.etisalat.subscriptionparameterizedoffer.mappers.SubscriptionParameterizedMapper;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOffer;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOfferVDB;
import com.etisalat.subscriptionparameterizedoffer.service.ISubscriptionParameterizedService;

import io.swagger.annotations.Api;

@RestController
@RequestMapping(APIName.SUBSCRIPTION_PARAMETERIZED_CONTROLLER)
@CrossOrigin(origins="*", maxAge=3600)
@Api("subscription controller api")
public class SubscriptionParameterizedController {
	

	
	private static final Log LOGGER = LogFactory.getLog(SubscriptionParameterizedController.class);
	
	@Autowired
	ISubscriptionParameterizedService subscriptionService;
	
	@GetMapping
	public ResponseEntity<SubscriptionParameterizedOfferDtoList> listSubscriptionOffers(@RequestParam("start") int start, @RequestParam("pageSize") int pageSize
			, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			SubscriptionParameterizedMapper mapper = SubscriptionParameterizedMapper.instance;
			List<SubscriptionParameterizedOfferDTO> dtos = new ArrayList<>();
			int totalCount = subscriptionService.getTotalCount();
			if(totalCount != 0) {
				List<SubscriptionParameterizedOfferVDB> subscriptions = subscriptionService.listSubscriptionOffers(start,pageSize);
				subscriptions.stream().forEach(subscription -> dtos.add(mapper.subscriptionOfferToDtoUsingVDB(subscription)));
			}
			SubscriptionParameterizedOfferDtoList subscriptionOffersList = new SubscriptionParameterizedOfferDtoList();
			subscriptionOffersList.setRecordsTotal(dtos.size());
			subscriptionOffersList.setTotalCount(totalCount);
			subscriptionOffersList.setSubscriptionOffers(dtos);
			return new ResponseEntity<>(subscriptionOffersList, HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new SubscriptionParameterizedOfferDtoList(), HttpStatus.BAD_REQUEST);
		}
	}
	
	@DeleteMapping(path="/{offeringId}")
	public ResponseEntity<ResponseMessage> deleteOffer(@PathVariable("offeringId") Integer offeringId, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			subscriptionService.delete(offeringId);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_DELETED_SUCCESS), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while deleting subscription parameterzed Offer with Id: " + offeringId);
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_DELETED_ERROR), HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping
	public ResponseEntity<ResponseMessage> editOffer(@RequestBody SubscriptionParameterizedOfferDTO dto, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			SubscriptionParameterizedOffer offer = SubscriptionParameterizedMapper.instance.dtoToSubscriptionOffer(dto);
			subscriptionService.updateOffer(offer, dto);
			LOGGER.debug("subscription parameterized Offer updated successfully, Offer Id is: " + dto.getOfferingId());
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_UPDATED_SUCCESS), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while updating subscription parameterized Offer with Id: " + dto.getOfferingId());
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_UPDATED_ERROR), HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping
	public ResponseEntity<ResponseMessage> saveOffer(@RequestBody SubscriptionParameterizedOfferDTO dto, HttpServletRequest request){		
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			SubscriptionParameterizedOffer offer = SubscriptionParameterizedMapper.instance.dtoToSubscriptionOffer(dto);
			subscriptionService.saveOffer(offer, dto);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_SAVED_SUCCESS), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while saving subscription parameterized Offer with name: " + dto.getOfferingName());
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_SAVED_ERROR), HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(path="/{offeringId}")
	public ResponseEntity<SubscriptionParameterizedOfferDTO> getOfferByOfferId(@PathVariable("offeringId") Integer offeringId, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			SubscriptionParameterizedOfferVDB offer = subscriptionService.getOfferByOfferId(offeringId);
			SubscriptionParameterizedOfferDTO offerDTO = SubscriptionParameterizedMapper.instance.subscriptionOfferToDtoUsingVDB(offer);
//			offerDTO.prepareOfferParamValues(offer.getSubRequestParamTDB(), offer.getOfferingSubRequestParam());
			return new ResponseEntity<>(offerDTO, HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while getting subscription parameterized Offer with Id: " + offeringId);
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new SubscriptionParameterizedOfferDTO(), HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(path="/checkOfferingNameAndDesc")
	public ResponseEntity<Boolean> editOffer(@RequestBody String offeringName, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			return new ResponseEntity<>(subscriptionService.isOfferingNameOrDescDuplicated(offeringName), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while checking offer duplication with name: " + offeringName);
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);
		}
	}

}
