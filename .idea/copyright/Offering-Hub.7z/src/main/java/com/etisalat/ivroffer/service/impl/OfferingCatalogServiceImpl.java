package com.etisalat.ivroffer.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.ivroffer.model.OfferingCatalog;
import com.etisalat.ivroffer.repository.OfferingCatalogRepo;
import com.etisalat.ivroffer.service.IOfferingCatalogService;

@Transactional
@Service("ivrCatalogService")
public class OfferingCatalogServiceImpl implements IOfferingCatalogService {

	@Autowired
	OfferingCatalogRepo offeringCatalogRepo;
	
	@Override
	public void delete(Integer offeringId) {
		offeringCatalogRepo.deleteByOfferingId(offeringId);
//		offeringCatalogRepo.deleteOffer(offeringId);
	}
	
	@Override
	public void saveOrUpdateOfferingCatalog(OfferingCatalog catalog) {
		offeringCatalogRepo.save(catalog);
	}

	@Override
	public void deleteOfferingCatalog(Integer offeringId) {
		offeringCatalogRepo.deleteOfferingCatalog(offeringId);
	}
}
