package com.etisalat.dynamicOffering.enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public enum AccumlationDuration {
	
	DAYS_3(3,"3 Days"),
	DAYS_7(7,"7 Days"),
	DAYS_14(14,"14 Days");
	
	private Integer id;
	private String name;
	
	 AccumlationDuration(Integer id, String name) {
		this.id = id;
		this.name = name;
	}
	 
	 public static  List<Properties> getData(){
		List<Properties> data = new ArrayList<Properties>();
		for(AccumlationDuration bt : AccumlationDuration.values()) {
			Properties prop = new Properties();
			prop.put("name", bt.name);
			prop.put("id", bt.id.toString());
			data.add(prop);
		}
		return data;
	}
}
