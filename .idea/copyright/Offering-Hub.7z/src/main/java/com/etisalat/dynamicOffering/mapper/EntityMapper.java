package com.etisalat.dynamicOffering.mapper;

public interface EntityMapper< E , T > {
	
	public E toEntity (DynamicOfferingMapper mapper , T dto);
	public T toDTO (DynamicOfferingMapper mapper ,E entity);
	
}
