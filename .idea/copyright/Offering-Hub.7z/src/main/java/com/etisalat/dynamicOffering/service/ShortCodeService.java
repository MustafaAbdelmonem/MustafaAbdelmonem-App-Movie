package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.trm.entity.Shortcode;
import com.etisalat.dynamicOffering.database.trm.repository.ShortCodeRepositoryTrm;

/**
 * @author O-Mostafa.Teba
 *
 */
@Service
public class ShortCodeService {
	
	@Autowired
	private ShortCodeRepositoryTrm shortCodeRepositoryTrm;

	@Transactional()
	public List<Shortcode> findAllShortCodes() {
		return shortCodeRepositoryTrm.findAll();
	}
	
	@Transactional()
	public List<Shortcode> findByTemplateId(Integer templateId) {
		return shortCodeRepositoryTrm.findByTemplateId(templateId);
	}
	
	@Transactional()
	public List<Shortcode> findAvailableAtlShortcodes(Integer templateId) {
		return shortCodeRepositoryTrm.findAvailableAtlShortcodes(templateId);
	}
	
	@Transactional()
	public List<Shortcode> findAvailableBtlShortcodes(Integer templateId) {
		return shortCodeRepositoryTrm.findAvailableBtlShortcodes(templateId);
	}
}
