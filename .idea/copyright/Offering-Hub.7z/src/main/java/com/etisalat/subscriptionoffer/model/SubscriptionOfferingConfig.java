package com.etisalat.subscriptionoffer.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;


import lombok.Data;

@Entity
@Table(name = "Offering_Config", schema = "TRM_LEAD")
@Data
public class SubscriptionOfferingConfig implements Serializable {
	
	private static final long serialVersionUID = -4104089043483322584L;

	@Id
	@Basic(optional = false)
	@NotNull 
	@Column(name ="offering_id")
	private Integer offeringId;
	
	@Column(name ="Channel_Name")
	private String channelName;
	
	@Column(name ="Tree_Id")
	private String treeId;
	
	@Column(name ="Interactive_Flag")
	private String interactiveFlag;
	
	@Column(name ="Prompt_Name")
	private String promptName;
	
	@Transient
	private SubscriptionOffer offering;
	
	@Column(name = "Delete_Flag", columnDefinition = "char(1) default N")
	private char deleteFlag = 'N';
	
	public SubscriptionOfferingConfig() {}

}
