package com.etisalat.subscriptionparameterizedoffer.attribute;

import java.util.ArrayList;
import java.util.List;

import com.etisalat.common.attribute.ReadableList;
import com.etisalat.subscriptionparameterizedoffer.dto.SubscriptionParameterizedOfferDTO;

import lombok.Data;

@Data
public class SubscriptionParameterizedOfferDtoList extends ReadableList {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6907746932097802636L;
	
	private List<SubscriptionParameterizedOfferDTO> subscriptionOffers = new ArrayList<>();

}
