package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 *
 * @author O-Mostafa.Teba
 */
@Entity
@Table(name = "PX_SHORTCODE", schema = "TRM_META")
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class Shortcode implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "SHORT_CODE")
	Integer shortCode;

	@Column(name = "SERVICE_NAME")
	String serviceName;

	@Column(name = "TEMPLATE_ID")
	Integer templateId;

	@Column(name = "SERVICE_ID")
	Integer serviceId;

}
