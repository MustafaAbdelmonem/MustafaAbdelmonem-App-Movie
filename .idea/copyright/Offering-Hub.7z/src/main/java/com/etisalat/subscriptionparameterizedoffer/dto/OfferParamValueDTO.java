package com.etisalat.subscriptionparameterizedoffer.dto;

import lombok.Data;

@Data
public class OfferParamValueDTO {
	
	private Integer offeringId;
	private Integer requestParamId;
	private String requestParamName;
	private Character subscriptionTemplateFlag;
	private Integer requestNumParamVal;
	private String requestTxtParamVal;
	private boolean deleted;
	private char deleteFlag;
		
}
