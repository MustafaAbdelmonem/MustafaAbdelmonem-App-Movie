package com.etisalat.subscriptionparameterizedoffer.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTRM;

@Transactional
@Repository("subRequestParamTrmRepository")
public interface ISubRequestParamTrmRepository extends JpaRepository<SubRequestParamTRM, Integer> {

	@Query("SELECT coalesce(max(subRequestParam.requestParamId), 0) FROM SubRequestParamTRM subRequestParam")
	Integer getMaxRequestParamId();

}
