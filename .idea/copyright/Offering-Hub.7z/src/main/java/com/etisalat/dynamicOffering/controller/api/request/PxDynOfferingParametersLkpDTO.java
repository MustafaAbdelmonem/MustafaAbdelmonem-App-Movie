package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class PxDynOfferingParametersLkpDTO {

	private Integer parameterTypeId;
	
	private String parameterTypeName;
}
