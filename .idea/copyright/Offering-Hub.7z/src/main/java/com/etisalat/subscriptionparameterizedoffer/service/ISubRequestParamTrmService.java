package com.etisalat.subscriptionparameterizedoffer.service;

import java.util.List;

import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTDB;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTRM;

public interface ISubRequestParamTrmService {

	void saveOrUpdateSubRequestParam(List<SubRequestParamTRM> list);

	void saveOrUpdateSubRequestParamByMappingTdbToTrm(List<SubRequestParamTDB> entities);

	Integer getMaxRequestParamId();

}
