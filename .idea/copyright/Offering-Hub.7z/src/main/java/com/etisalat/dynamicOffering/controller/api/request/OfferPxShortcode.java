package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferPxShortcode {

	private Integer shortCode;

	private boolean shortCodeNull = true;

	private String serviceName;

	private Integer templateId;

	private boolean templateIdNull = true;

	private Integer serviceId;

	private boolean serviceIdNull = true;
}
