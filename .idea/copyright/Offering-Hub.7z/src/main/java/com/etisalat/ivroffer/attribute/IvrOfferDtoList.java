package com.etisalat.ivroffer.attribute;

import java.util.ArrayList;
import java.util.List;

import com.etisalat.common.attribute.ReadableList;
import com.etisalat.ivroffer.dto.IvrOfferDTO;

import lombok.Data;

@Data
public class IvrOfferDtoList extends ReadableList {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6907746932097802636L;
	
	private List<IvrOfferDTO> ivrOffers = new ArrayList<>();

}
