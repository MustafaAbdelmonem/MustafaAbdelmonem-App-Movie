package com.etisalat.dynamicOffering.models.old;

import lombok.Data;

@Data
public class OfferCapping {
	
	private Integer cappingDaily;
	private Integer cappingWeekly;
	private Integer cappingMonthly;
	
	private Integer total;
}
