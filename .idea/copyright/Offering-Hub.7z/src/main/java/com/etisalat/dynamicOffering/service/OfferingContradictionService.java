package com.etisalat.dynamicOffering.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingContradiction;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingContradictionRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingDetails;
import com.etisalat.dynamicOffering.database.trm.entity.ServiceCategory;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingContradictionRepositoryTrm;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.dynamicOffering.models.old.Contradiction;
import com.etisalat.dynamicOffering.models.old.Res;



@Service
public class OfferingContradictionService extends AbstractBaseService {

	@Autowired
	OfferingContradictionRepositoryOds offeringContradictionRepositoryOds;
	
	@Autowired
	OfferingContradictionRepositoryTrm offeringContradictionRepositoryTrm;
	@Autowired
	ServiceCategoryService serviceCategoryService;
	
	@Autowired
	OfferingDetailsService offeringDetailsService;
	
	
	@Transactional()
	public Map<String,List<Res> > findAll() {
		
		
		Contradiction contradiction = new Contradiction();
		//contradiction.setContradictionOffers(offeringContradictionRepositoryTrm.listContradiction());
		
		
		
		List<Object[]> response= offeringContradictionRepositoryTrm.listContradiction();
		
		Map<String,List<Res> > result =new HashMap<>();	
		
		for (Object[] obj : response ) {
				
			Res res = new Res();
			res.setOfferingId((Integer) obj[0]);
			res.setOfferingName((String) obj[1]);
			res.setOfferinCategory((String) obj[2]);
			res.setCategoryName((String) obj[3]);	
			
			if(result.containsKey(res.getCategoryName()) )
			{
				result.get(res.getCategoryName()).add(res);
			}
			else {
				List<Res> list = new ArrayList<>() ;
				list.add(res);
				result.put(res.getCategoryName(),list);
				
			}
			
		}
		
		
		
		
//		List<Object[]> x= offeringContradictionRepositoryTrm.listContradiction2();
		
		
//		Map<String,List<Res> > response =new HashMap<>();	
//		
////		for (Object o : x) {
////			
////		}
//	for (Object[] obj : x) {
//		
//		OfferingDetails offeringDetails = (OfferingDetails) obj[0]; 
//		ServiceCategory ServiceCategory = (ServiceCategory) obj[1];
//		
//		if(response.containsKey(ServiceCategory.getName()))
//		{
//			Res res = new Res();
//			
//			res.setCategoryName(ServiceCategory.getName());
//			res.setOfferingId(offeringDetails.getOfferingId());
//			res.setOfferingName(offeringDetails.getOfferingName());
//			res.setOfferinCategory(offeringDetails.getOfferingCategory());
//			
//			response.get(ServiceCategory.getName()).add(res);
//			
//		}
//		
//		else {
//		
//			Res res = new Res();
//			res.setCategoryName(ServiceCategory.getName());
//			res.setOfferingId(offeringDetails.getOfferingId());
//			res.setOfferingName(offeringDetails.getOfferingName());
//			res.setOfferinCategory(offeringDetails.getOfferingCategory());
//			List<Res> rest = new ArrayList<>() ;
//			rest.add(res);
//			response.put(ServiceCategory.getName(),rest);
//		}
//	}
//		
		
		
		return result;
		
	//	return contradiction.initUnSelectedCheckbox(serviceCategoryService.findServiceCategory(),offeringDetailsService.findAllTRMOfferingDetails());
	
	}
	
	@Transactional()
	public void insertOfferingContradiction(OfferingContradiction offeringContradiction) {
		
	
		offeringContradictionRepositoryOds.save(offeringContradiction);
		
		offeringContradictionRepositoryTrm.save(DynamicOfferingMapper.instance.mapOfferingContradictionEntityTRM(offeringContradiction));
		
		//	return true;
	}


}
