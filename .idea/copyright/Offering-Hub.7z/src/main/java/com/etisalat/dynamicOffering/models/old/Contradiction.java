package com.etisalat.dynamicOffering.models.old;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class Contradiction implements Serializable {

	
	List<Res[]> contradictionOffers;
	
	
	
}