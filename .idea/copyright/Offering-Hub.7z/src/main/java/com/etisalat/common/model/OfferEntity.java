package com.etisalat.common.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import lombok.Data;

@MappedSuperclass
@Data
public class OfferEntity implements Serializable {

	private static final long serialVersionUID = 7569290683796873430L;
	
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "offering_id")
//	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer offeringId;

	@Column(name = "offering_name")
	private String offeringName;

	@Column(name = "offering_Desc")
	private String offeringDesc;

	@Column(name = "Offering_Start_Dttm")
	@NotNull
	@Temporal(TemporalType.DATE)
	private Date startDttm;
	
	@Column(name = "Offering_end_Dttm")
	@Temporal(TemporalType.DATE)
	private Date endDttm;
	
	@Column(name = "Offering_Mask")
	private String offeringMask;
	
	@Column(name = "Offering_Val")
	private String offeringVal;
	
	@Column(name = "Offering_Bits")
	private String offeringBits;
	
//	@Column(name = "Bit_0")
//	private String bit0;
//	
//	@Column(name = "Bit_1")
//	private String bit1;
//	
//	@Column(name = "Bit_2")
//	private String bit2;
//	
//	@Column(name = "Bit_3")
//	private String bit3;
//	
//	@Column(name = "Bit_4")
//	private String bit4;
//	
//	@Column(name = "Bit_5")
//	private String bit5;
//	
//	@Column(name = "Bit_6")
//	private String bit6;
//	
//	@Column(name = "Bit_7")
//	private String bit7;
//	
//	@Column(name = "Bit_8")
//	private String bit8;
//	
//	@Column(name = "Bit_9")
//	private String bit9;
//	
//	@Column(name = "Bit_10")
//	private String bit10;
//	
//	@Column(name = "Bit_11")
//	private String bit11;
//	
//	@Column(name = "Bit_12")
//	private String bit12;
//	
//	@Column(name = "Bit_13")
//	private String bit13;
//	
//	@Column(name = "Bit_14")
//	private String bit14;
//	
//	@Column(name = "Bit_15")
//	private String bit15;
//	
//	@Column(name = "Bit_16")
//	private String bit16;
//	
//	@Column(name = "Bit_17")
//	private String bit17;
//	
//	@Column(name = "Bit_18")
//	private String bit18;
//	
//	@Column(name = "Bit_19")
//	private String bit19;
//	
//	@Column(name = "Bit_20")
//	private String bit20;
//	
//	@Column(name = "Bit_21")
//	private String bit21;
//	
//	@Column(name = "Bit_22")
//	private String bit22;
//	
//	@Column(name = "Bit_23")
//	private String bit23;
//	
//	@Column(name = "Bit_24")
//	private String bit24;
//	
//	@Column(name = "Bit_25")
//	private String bit25;
//	
//	@Column(name = "Bit_26")
//	private String bit26;
//	
//	@Column(name = "Bit_27")
//	private String bit27;
//	
//	@Column(name = "Bit_28")
//	private String bit28;
//	
//	@Column(name = "Bit_29")
//	private String bit29;
//	
//	@Column(name = "Bit_30")
//	private String bit30;
//	
//	@Column(name = "Bit_31")
//	private String bit31;
	
	@Column(name = "DWH_Entry_Date")
	@NotNull
	@Temporal(TemporalType.DATE)
	private Date dwhEntryDate;

	@Column(name = "SSS_Id")
	private Long serviceId;
	
	@Column(name = "Account_Group_Flag")
	private String accountGroupFlag;
	
	@Column(name = "Promotion_Plan_Before_Id")
	private String promoPlanBeforeId;
	
	@Column(name = "SSS_Name")
	private String serviceName;
	
	@Column(name = "Campaign_Notification_Flag")
	private String campNotifiFlag;

	@Column(name = "Bulk_Action_Flag")
	private String bulkActionFlag;
		
	@Column(name = "Engagement_Flag")
	private String engagementFlag;
	
	@Column(name = "Interactive_Flag")
	private String interactiveFlag;

	@Column(name = "Subscription_Template_Flag")
	private String subsTempFlag;
	
	@Column(name = "Offering_Type_ID")
	private String offeringTypeId;
	
	@Column(name = "Project")
	private String project;
	
	@Column(name = "Comments")
	private String comments;

}
