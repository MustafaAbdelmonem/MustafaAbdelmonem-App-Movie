package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferPxDynOfferingConverter {

	private Integer converterType;

	private boolean converterTypeNull = true;

	private long validity;

	private boolean validityNull = true;

	private float rate;

	private boolean rateNull = true;

	private float fees;

	private boolean feesNull = true;

	private String paymentMethod;

	private Integer offeringId;

	private boolean offeringIdNull = true;

}
