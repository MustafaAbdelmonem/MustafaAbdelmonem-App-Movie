package com.etisalat.dynamicOffering.database.trm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.trm.entity.PxOfferingLPK;

@Transactional
@Repository("pxOfferingLpkRepository")
public interface PxOfferingLpkRepository extends JpaRepository<PxOfferingLPK, Integer> {

	@Query(value="SELECT o.* FROM TRM_META.px_offering_lpk o WHERE o.service_id = :serviceId AND o.offering_val = :offeringVal", nativeQuery= true)
	PxOfferingLPK findByServiceIdAndOfferingValNative(@Param("serviceId") Integer serviceId, @Param("offeringVal") Integer offeringVal);

	@Query(value="SELECT o.* FROM TRM_META.px_offering_lpk o WHERE o.service_id = :serviceId", nativeQuery= true)
	PxOfferingLPK findByServiceIdNative(Integer valueOf);
	
}
