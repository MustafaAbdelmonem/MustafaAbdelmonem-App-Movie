package com.etisalat.dynamicOffering.database.ods.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.ods.entity.RunDetails;
import com.etisalat.dynamicOffering.database.ods.entity.RunDetailsId;

/**
 *
 * @author O-Mostafa.Teba
 */
public interface RunDetailsRepositoryOds extends JpaRepository<RunDetails, RunDetailsId> {

}