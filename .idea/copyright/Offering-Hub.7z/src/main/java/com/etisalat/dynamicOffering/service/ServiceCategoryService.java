
package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.trm.entity.ServiceCategory;
import com.etisalat.dynamicOffering.database.trm.repository.ServiceCategoryRepositoryTrm;


@Service
public class ServiceCategoryService {

	@Autowired
	private ServiceCategoryRepositoryTrm serviceCategoryRepositoryTrm;
	@Autowired
	OfferingLookupService offeringLookupService;

	@Transactional()
	public List<ServiceCategory> findServiceCategory() {
		return serviceCategoryRepositoryTrm.findAll();
	}

	@Transactional()
	public List<ServiceCategory> findServiceCategoryByTemplateId(Integer templateId) {

		return offeringLookupService.getServiceCategory(templateId);
	}

}
