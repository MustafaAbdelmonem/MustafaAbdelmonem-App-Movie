package com.etisalat.ivroffer.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.ValidationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.common.constant.EtisalatConstant;
import com.etisalat.ivroffer.model.IvrOffering;
import com.etisalat.ivroffer.model.OfferingCatalogVDB;
import com.etisalat.ivroffer.model.OfferingConfigVDB;
import com.etisalat.ivroffer.model.OfferingVDB;
import com.etisalat.ivroffer.repository.IVRRepo;
import com.etisalat.ivroffer.repository.VDBIvrRepository;
import com.etisalat.ivroffer.service.IIVRService;
import com.etisalat.ivroffer.service.IOfferingCatalogService;
import com.etisalat.ivroffer.service.IOfferingConfigService;

@Transactional
@Service("ivrService")
public class IVRServiceImpl implements IIVRService {
	
	private static final Log LOGGER = LogFactory.getLog(IVRServiceImpl.class);
	
	@Autowired
	IVRRepo ivrRepo;
	
	@Autowired
	VDBIvrRepository vdbIvrRepository;
	
	@Autowired
	IOfferingCatalogService catalogService;
	
	@Autowired
	IOfferingConfigService configSerivce;
	
	OfferingVDB offer;

	@Override
	public List<IvrOffering> listAll() {
		return ivrRepo.findAll();
	}
	
	public List<OfferingVDB> listIVROffersUsingVDB(int start, int pageSize) {
		List<OfferingVDB> ivrOfferingList = new ArrayList<>();
//		List<Object[]> paginatedList = ivrRepo.listIVROffers(new PageRequest(start, pageSize));
		List<Object[]> paginatedList = vdbIvrRepository.listIVROffersUsingVDB(new PageRequest(start, pageSize));
		paginatedList.stream().forEach(item -> {
			offer = (OfferingVDB)item[EtisalatConstant.OFFERING_INDEX];
			offer.setCatalog((OfferingCatalogVDB)item[EtisalatConstant.OFFERING_CATALOG_INDEX]);
			offer.setConfig((OfferingConfigVDB)item[EtisalatConstant.OFFERING_CONFIG_INDEX]);
			ivrOfferingList.add(offer);
		});
		return ivrOfferingList;
	}

	@Override
	public void delete(Integer offeringId) {
//		configSerivce.delete(offeringId);
//		catalogService.delete(offeringId);
//		ivrRepo.deleteByOfferingId(offeringId);
		
		configSerivce.deleteOfferingConfig(offeringId);
		LOGGER.debug("update offering_config delete_flag with 'Y' for ivr offer Id: " + offeringId);
		
		catalogService.deleteOfferingCatalog(offeringId);
		LOGGER.debug("update offering_catalog delete_flag with 'Y' for ivr offer Id: " + offeringId);
		
		ivrRepo.deleteIvrOffering(offeringId);
		LOGGER.debug("update Offering delete_flag with 'Y' for ivr offer Id: " + offeringId);
	}

	@Override
	public void updateOffer(IvrOffering offer) {
		offer.getCatalog().setDeleteFlag('N');
		catalogService.saveOrUpdateOfferingCatalog(offer.getCatalog());
		LOGGER.debug("Offering_Catalog is updated for ivr offer Id: " + offer.getOfferingId());
		
		offer.getConfig().setDeleteFlag('N');
		configSerivce.saveOrUpdateOfferingConfig(offer.getConfig());
		LOGGER.debug("Offering_Config is updated for ivr offer Id: " + offer.getOfferingId());
		
		offer.setAccountGroupFlag("D");
		offer.setOfferingDesc(offer.getOfferingName());
		offer.setDeleteFlag('N');
		ivrRepo.save(offer);
		LOGGER.debug("Offering is updated for ivr offer Id: " + offer.getOfferingId());
	}

	@Override
	public void saveOffer(IvrOffering offer) throws ValidationException {
//		Integer maxOfferingId = ivrRepo.findMaxOfferingId();
		Integer maxOfferingId = vdbIvrRepository.findMaxOfferingId();
		offer.setOfferingId(maxOfferingId+1);
		offer.setStartDttm(new Date());
		offer.setDwhEntryDate(new Date());
		offer.setAccountGroupFlag("D");
		offer.setOfferingDesc(offer.getOfferingName());
		offer.setDeleteFlag('N');
		ivrRepo.save(offer);
		
		if(offer.getOfferingId() != null) {
			LOGGER.debug("Ivr Offer Saved Successfully with Id: " + offer.getOfferingId());
			
			offer.getCatalog().setOfferingId(offer.getOfferingId());
			offer.getCatalog().setDeleteFlag('N');
			catalogService.saveOrUpdateOfferingCatalog(offer.getCatalog());
			LOGGER.debug("Offering_Catalog saved successfully for Ivr Offer Id: " + offer.getOfferingId());
			
			offer.getConfig().setOfferingId(offer.getOfferingId());
			offer.getConfig().setDeleteFlag('N');
			configSerivce.saveOrUpdateOfferingConfig(offer.getConfig());
			LOGGER.debug("Offering_Config saved successfully for Ivr Offer Id: " + offer.getOfferingId());
		} else {
			LOGGER.error("Saving Ivr Offer Error:  Offering Id must not be null!");
			throw new ValidationException("Offering Id must not be null !");
		}
	}

	@Override
	public OfferingVDB getOfferByOfferId(Integer offeringId) {
		OfferingVDB offer = new OfferingVDB();
//		Object object = ivrRepo.findByOfferingId(offeringId);
		Object object = vdbIvrRepository.findByOfferingId(offeringId);
		if(object != null) {
			LOGGER.debug("Get ivr offer with Id: " + offeringId);
			offer = (OfferingVDB)(((Object[]) object)[EtisalatConstant.OFFERING_INDEX]);
			offer.setCatalog((OfferingCatalogVDB)(((Object[]) object)[EtisalatConstant.OFFERING_CATALOG_INDEX]));
			offer.setConfig((OfferingConfigVDB)(((Object[]) object)[EtisalatConstant.OFFERING_CONFIG_INDEX]));
		}
		return offer;
	}

	@Override
	public int getTotalCount() {
//		return ivrRepo.getTotalCount();
		return vdbIvrRepository.getTotalCount();
	}

	@Override
	public boolean isOfferingNameOrDescDuplicated(String offeringName) {
//		return ivrRepo.findByOfferingNameOrOfferingDesc(offeringName, offeringName).isEmpty() ? false : true;
		return vdbIvrRepository.findByOfferingNameOrOfferingDesc(offeringName, offeringName).isEmpty() ? false : true;
	}

}
