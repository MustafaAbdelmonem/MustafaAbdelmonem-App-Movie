package com.etisalat.common.utils;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;

public class AuthUtils {
	
	public static String getUserIpAddress(HttpServletRequest request) {
		String remoteAddress = "";
		if(request != null) {
			remoteAddress = request.getHeader("X-FORWARDED-FOR");
			if(remoteAddress == null || "".equals(remoteAddress))
				System.out.println("locaaaaaaaal " + request.getLocalAddr() + "   /   " + request.getLocalName());
				try {
					System.out.println("Server " + InetAddress.getLocalHost());
					System.out.println("Server IP " + InetAddress.getLocalHost().getHostAddress());
					System.out.println("Server HostName " + InetAddress.getLocalHost().getHostName());
				} catch (UnknownHostException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				remoteAddress = request.getRemoteAddr();
		}
		return remoteAddress;
	}

}
