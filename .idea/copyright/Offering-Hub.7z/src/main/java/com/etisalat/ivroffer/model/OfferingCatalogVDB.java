package com.etisalat.ivroffer.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Entity
@Table(name = "Offering_Catalog", schema = "VDB")
@Data
public class OfferingCatalogVDB  implements Serializable {
	
	private static final long serialVersionUID = 6029888859457491153L;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name ="offering_id")
	private Integer offeringId;
	
	@Column(name ="Short_Code_Num")
	private String shortCode;
	
	@Column(name ="Offering_Opt_In_Type_Id")
	private String offeringOptInTypeId;
	
	@Transient
	private OfferingVDB offering;
	
	public OfferingCatalogVDB() {}

}
