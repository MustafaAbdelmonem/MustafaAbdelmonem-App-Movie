package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferConfigurationDTO {
	
	private String promotionPlanStartDate;
	private String promotionPlanEndDate;
	private Integer redemptionWindow;
	private Integer rechargeThreshold;
	
	private Integer maximumIncidentOfBonus;
	
	private Integer bonusValidity;
	private Integer promotionPlanDuration;
	private Integer offeringDuration;
	private Integer optinOfferingDuration;
	
	private boolean accumlation;
	private boolean subscriptionSendSM;
	// UIComponent addnewBonusButton;
	
	private boolean migrationFlag; 
	
	private boolean dynamicQuota; 
	
	private OfferDynBonusDTO dynBonus;
	
	private String targetBundle;
	private String sourceBundle;
	private String action;
	
	private OfferPxOfferingCapping pxOfferingCapping;
	
	private Integer accumlationDuration;
	
	private boolean bonusTypeFlag;
	
	private String offeringStartDate;
	private String offeringEndDate;
	private String dwhEntryDate;
	
	private boolean thresholdRequired;
	
	private boolean salefny;
	private boolean settlmentOffer;
	
	private Integer validRenewalPeriod;
	private OfferBonusDTO bonus;
	private OfferBonusDTO bonusDynamicDiscount = new OfferBonusDTO();
	private OfferBonusDTO bonusMultipleQuota = new OfferBonusDTO();
	
	private OfferPxDynOfferingConverter offeringConverter;
	
	private boolean renewalOnTime;

}
