package com.etisalat.dynamicOffering.controller.api;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.common.utils.AuthUtils;
import com.etisalat.dynamicOffering.controller.AbstractBaseController;
import com.etisalat.dynamicOffering.controller.util.APIResponse;
import com.etisalat.dynamicOffering.database.ods.entity.Channel;
import com.etisalat.dynamicOffering.service.ChannelService;;

/**
 * @author O-Mostafa.Teba
 *
 */
@RestController
@RequestMapping(APIName.CHANNEL)
public class ChannelController extends AbstractBaseController {

	@Autowired
	ChannelService channelService;

	@RequestMapping(value = APIName.CHANNEL_LIST, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findAllChannels(Pageable page, HttpServletRequest request) {
		LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
		return responseUtil.successResponse(channelService.findAllChannels(page));
	}

	@RequestMapping(value = APIName.CHANNEL_ADD , method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> addChannel(HttpServletRequest request) {
		LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
		Channel channel = new Channel();
		channel.setChannelId(9999L);
		channel.setChannelName("new channel");
		// channelRepositry.save(channel);
		return responseUtil.successResponse(channelService.addNewChannel(channel));
	}
	
	

}
