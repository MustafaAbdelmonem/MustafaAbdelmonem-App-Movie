package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.trm.entity.Offering;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingRepositoryTrm;


@Service
public class OfferingService extends AbstractBaseService {

	@Autowired
	OfferingRepositoryTrm offeringRepositoryTrm;
	

	@Transactional()
	public Integer getNextOfferId() {
		return offeringRepositoryTrm.getNextOfferId();
	}

	@Transactional()
	public List<Offering> findAllOfferingTrm() {
		return offeringRepositoryTrm.findAll();
	}
	
	@Transactional()
	public List<Offering> findAllOfferingOds() {
		return offeringRepositoryTrm.findAll();
	}
	
	@Transactional()
	public Offering saveOffering(Offering offering) {
		
		/*
		 * */
		if(offering.getOfferingId() == null)
			offering.setOfferingId(offeringRepositoryTrm.getNextOfferId());
		
	
		offeringRepositoryTrm.save(offering);
		
		return offering;
	}
}
