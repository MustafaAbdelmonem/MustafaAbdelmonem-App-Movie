package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferingBonusDTO {
	
	
	private Integer offeringId;
	private Integer trafficCaseId;
	private Integer thresholdId;
	private String trafficCase;
	private Float bonusValue;
	private Integer specialRorFlag;
	private Float specialRorVal;
	private Integer poolBonusFlag;
	private Float bonusCapping;
	private Integer mqPromoValidity;
	private Float mqBonusValue;
	private Integer mqMaxRecurrence;

}
