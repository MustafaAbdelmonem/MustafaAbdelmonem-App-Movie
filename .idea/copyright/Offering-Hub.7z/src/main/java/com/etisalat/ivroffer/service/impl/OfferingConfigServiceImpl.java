package com.etisalat.ivroffer.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.ivroffer.model.OfferingConfig;
import com.etisalat.ivroffer.repository.OfferingConfigRepo;
import com.etisalat.ivroffer.service.IOfferingConfigService;

@Transactional
@Service("configService")
public class OfferingConfigServiceImpl implements IOfferingConfigService {

	@Autowired
	OfferingConfigRepo offeringConfigRepo;
	
	@Override
	public void delete(Integer offeringId) {
		offeringConfigRepo.deleteOffer(offeringId);
	}

	@Override
	public void saveOrUpdateOfferingConfig(OfferingConfig config) {
		offeringConfigRepo.save(config);
	}

	@Override
	public void deleteOfferingConfig(Integer offeringId) {
		offeringConfigRepo.deleteOfferingConfig(offeringId);
	}
}
