package com.etisalat.subscriptionoffer.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Entity
@Table(name = "Offering_Catalog", schema = "TRM_LEAD")
@Data
public class SubscriptionOfferingCatalog  implements Serializable {
	
	private static final long serialVersionUID = 6029888859457491153L;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name ="offering_id")
	private Integer offeringId;
	
	@Column(name ="Short_Code_Num")
	private String shortCode;
	
	@Column(name ="Offering_Opt_In_Type_Id")
	private String offeringOptInTypeId;
	
	@Transient
	private SubscriptionOffer offering;
	
	@Column(name = "Delete_Flag", columnDefinition = "char(1) default N")
	private char deleteFlag = 'N';
	
	public SubscriptionOfferingCatalog() {}

}
