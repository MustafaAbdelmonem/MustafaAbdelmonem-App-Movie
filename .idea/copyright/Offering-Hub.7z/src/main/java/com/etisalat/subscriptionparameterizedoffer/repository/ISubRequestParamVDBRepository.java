package com.etisalat.subscriptionparameterizedoffer.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamVDB;

@Transactional
@Repository("subRequestParamVdbRepository")
public interface ISubRequestParamVDBRepository extends JpaRepository<SubRequestParamVDB, Integer> {

	@Query("SELECT coalesce(max(subRequestParam.requestParamId), 0) FROM SubRequestParamVDB subRequestParam")
	Integer getMaxRequestParamId();

}
