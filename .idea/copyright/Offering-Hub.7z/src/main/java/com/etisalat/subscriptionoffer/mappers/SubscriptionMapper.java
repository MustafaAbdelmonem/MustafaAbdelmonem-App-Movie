package com.etisalat.subscriptionoffer.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.etisalat.subscriptionoffer.dto.SubscriptionOfferDTO;
import com.etisalat.subscriptionoffer.model.SubscriptionOffer;
import com.etisalat.subscriptionoffer.model.SubscriptionOfferVDB;

@Mapper
public interface SubscriptionMapper {

	SubscriptionMapper instance = Mappers.getMapper(SubscriptionMapper.class);

	SubscriptionOfferDTO subscriptionOfferToDto(SubscriptionOffer offer);
	
	SubscriptionOfferDTO subscriptionOfferToDtoVDB(SubscriptionOfferVDB offer);

	SubscriptionOffer dtoToSubscriptionOffer(SubscriptionOfferDTO dto);
	
}
