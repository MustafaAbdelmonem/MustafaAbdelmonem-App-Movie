package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingBonus;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingBonusRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingBonusTRM;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingBonusRepositoryTrm;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.dynamicOffering.models.old.Bonus;
import com.etisalat.rtim.integration.RTIMintegration;
import com.google.gson.Gson;


@Service
public class OfferingBonusService extends AbstractBaseService {

	@Autowired
	OfferingBonusRepositoryOds offeringBonusRepositoryOds;

	@Autowired
	OfferingBonusRepositoryTrm offeringBonusRepositoryTrm;	
	
	RTIMintegration rTIMintegration = new RTIMintegration();
	
	@Autowired
	Gson gson;

	@Transactional()
	public List<OfferingBonusTRM> findAll() {
		return offeringBonusRepositoryTrm.findAll();
	}

	@Transactional()
	public List<com.etisalat.dynamicOffering.database.ods.entity.OfferingBonus> findAllODS() {
		return offeringBonusRepositoryOds.findAll();
	}

	@Transactional()
	public void insertOfferingBonus(OfferingBonus offeringBonus) {
		offeringBonusRepositoryOds.save(offeringBonus);
		offeringBonusRepositoryTrm.save(DynamicOfferingMapper.instance.mapOfferingBonusEntityTRM(offeringBonus));
	}
	
	@Transactional()
	public void insertOfferingBonusList(List<OfferingBonus> offeringBonusOdsList,List<OfferingBonusTRM> offeringBounsTrmList) {
		offeringBonusRepositoryOds.save(offeringBonusOdsList);
		offeringBonusRepositoryTrm.save(offeringBounsTrmList);
		
		offeringBonusOdsList.stream().forEach(bonus -> {
			try {
				rTIMintegration.insertRTIMDB(gson.toJson(bonus),"px_offering_bonus");
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	}

}
