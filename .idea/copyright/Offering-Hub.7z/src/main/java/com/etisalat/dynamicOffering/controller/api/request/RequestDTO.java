package com.etisalat.dynamicOffering.controller.api.request;

import java.util.List;

import lombok.Data;

@Data
public class RequestDTO {

	
	int offeringId;
	
	OfferingDTO offeringDTO;
	
	OfferingDetailsDTO offeringDetailsDTO;
	
	DynOfferingConverterDTO dynOfferingConverterDTO;
	
	OfferingCappingDTO offeringCappingDTO;
	
	List<OfferingThresholdDTO> offeringThresholdsDTO;
	
	List<OfferingBonusDTO> offeringBonusDTO;
	
	List<DynOfferingParameterDTO> dynOfferingParametersDTO;
	
	List<OfferingChannelDTO> offeringChannelsDTO;
	
	List<OfferingContradictionDTO> offeringContradictionsDTO;
	
	List<OfferingRateplanDTO> offeringRateplansDTO;
	
}
