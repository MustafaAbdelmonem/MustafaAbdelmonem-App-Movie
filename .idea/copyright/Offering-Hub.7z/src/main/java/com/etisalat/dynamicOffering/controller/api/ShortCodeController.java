package com.etisalat.dynamicOffering.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.dynamicOffering.controller.AbstractBaseController;
import com.etisalat.dynamicOffering.controller.util.APIResponse;
import com.etisalat.dynamicOffering.service.ShortCodeService;

/**
 * @author O-Mostafa.Teba
 *
 */
@RestController
@RequestMapping(APIName.SHORT_CODE)
public class ShortCodeController extends AbstractBaseController{

	@Autowired
	ShortCodeService shortCodeService;
	
	@CrossOrigin(origins = APIName.UI_URL)
	@RequestMapping(value = APIName.SHORT_CODE_LIST, method = RequestMethod.GET)
	public ResponseEntity<APIResponse> findAllShortCodes(Pageable page) {
		return responseUtil.successResponse(shortCodeService.findAllShortCodes());
	}
	
	@CrossOrigin(origins = APIName.UI_URL)
	@RequestMapping(value = APIName.SHORT_CODE_BY_TEMPATE_ID, method = RequestMethod.GET)
	public ResponseEntity<APIResponse> findShortCodesForTemplate(@PathVariable("template_id") Integer templateId) {
		return responseUtil.successResponse(shortCodeService.findByTemplateId(templateId));
	}
	
	@CrossOrigin(origins = APIName.UI_URL)
	@RequestMapping(value = APIName.SHORT_CODE_ATL, method = RequestMethod.GET)
	public ResponseEntity<APIResponse> findAvailableAtlShortcodes(@PathVariable("template_id") Integer templateId) {
		return responseUtil.successResponse(shortCodeService.findAvailableAtlShortcodes(templateId));
	}
	
	@CrossOrigin(origins = APIName.UI_URL)
	@RequestMapping(value = APIName.SHORT_CODE_BTL, method = RequestMethod.GET)
	public ResponseEntity<APIResponse> findAvailableBtlShortcodes(@PathVariable("template_id") Integer templateId) {
		return responseUtil.successResponse(shortCodeService.findAvailableBtlShortcodes(templateId));
	}
}