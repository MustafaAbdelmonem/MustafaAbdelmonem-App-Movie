package com.etisalat.dynamicOffering.models.old;

import java.util.List;

import lombok.Data;

@Data
public class Tier  {

	private Integer thesholdId;
	private Float thresholdValue;
	private Float poolBonusValue;
	private List<Bonus> bonusList;
	
}
