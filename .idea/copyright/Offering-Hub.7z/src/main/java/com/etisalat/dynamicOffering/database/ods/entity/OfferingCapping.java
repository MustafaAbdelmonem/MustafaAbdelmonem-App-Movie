package com.etisalat.dynamicOffering.database.ods.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "PX_OFFERING_CAPPING",schema = "ods")
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class OfferingCapping implements Serializable {
	
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_ID")
	private Integer offeringId;

	@Column(name = "CAPPING_DAILY")
	private Long cappingDaily;

	@Column(name = "CAPPING_WEEKLY")
	private Long cappingWeekly;
	
	@Column(name = "CAPPING_MONTHLY")
	private Long cappingMonthly;
	
	@Column(name = "CAPPING_TOTAL")
	private Long cappingTotal;
	
	@Column(name = "TARGET_BUNDLE")
	private String targetBundle;	
	
	@Column(name = "SOURCE_BUNDLE")
	private String sourceBundle;
	
	@Column(name = "ACTION")
	private String action;

	@Column(name = "TARGET_RP")
	private Integer targetRatePlan;
	
	@Column(name = "UPGRD_MIG_PERIOD")
	private Integer upgrdMigPeriod;

	@Column(name = "UNSETTLEMENT_OFFER")
	private String unsettlementOffer;
	
	@Column(name = "PRODUCTVALIDITY")
	private Integer productValidity;
	
	@Column(name = "TRANSACATIONAMOUNT")
	private Float transactionAmount;
	
	@Column(name = "BUNDLETYPE")
	private Integer bundleType;

}
