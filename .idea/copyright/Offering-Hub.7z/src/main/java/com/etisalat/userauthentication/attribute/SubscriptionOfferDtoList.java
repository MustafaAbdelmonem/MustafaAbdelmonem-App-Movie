package com.etisalat.userauthentication.attribute;

import java.util.ArrayList;
import java.util.List;

import com.etisalat.common.attribute.ReadableList;
import com.etisalat.subscriptionoffer.dto.SubscriptionOfferDTO;

import lombok.Data;

@Data
public class SubscriptionOfferDtoList extends ReadableList {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6907746932097802636L;
	
	private List<SubscriptionOfferDTO> subscriptionOffers = new ArrayList<>();

}
