package com.etisalat.dynamicOffering.database.trm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingTemplates;
/**
*
* @author O-Mostafa.Teba
*/
public interface OfferingTemplatesRepositoryTrm extends JpaRepository<OfferingTemplates, Integer> {

}
