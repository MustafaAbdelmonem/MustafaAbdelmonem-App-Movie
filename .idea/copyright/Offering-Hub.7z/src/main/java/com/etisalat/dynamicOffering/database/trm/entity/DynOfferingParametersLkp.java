package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "PX_DYN_OFFERING_PARAMETERS_LKP", schema = "TRM_META")
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class DynOfferingParametersLkp implements Serializable {
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "PARAMETER_TYPE_ID")
	private Integer parameterTypeId;
	
	@Column(name = "PARAMETER_TYPE_NAME")
	private String parameterTypeName;

}
