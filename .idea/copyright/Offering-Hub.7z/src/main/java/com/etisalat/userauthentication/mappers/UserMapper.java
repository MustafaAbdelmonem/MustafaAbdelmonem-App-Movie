package com.etisalat.userauthentication.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.etisalat.userauthentication.dto.UsersDTO;
import com.etisalat.userauthentication.model.Users;

@Mapper
public interface UserMapper {

	UserMapper instance = Mappers.getMapper(UserMapper.class);

	UsersDTO userToDTO(Users offer);

	Users dtoToUser(UsersDTO dto);
	
}
