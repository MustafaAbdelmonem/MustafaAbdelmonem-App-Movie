package com.etisalat.dynamicOffering.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.etisalat.common.SystemProperties;
import com.etisalat.dynamicOffering.controller.api.request.OfferBonusDTO;
import com.etisalat.dynamicOffering.controller.api.request.OfferChannelDTO;
import com.etisalat.dynamicOffering.controller.api.request.OfferPxDynOfferingConverter;
import com.etisalat.dynamicOffering.controller.api.request.OfferPxDynOfferingParametersDTO;
import com.etisalat.dynamicOffering.controller.api.request.OfferPxOfferingCapping;
import com.etisalat.dynamicOffering.controller.api.request.OfferTierDTO;
import com.etisalat.dynamicOffering.controller.api.request.PxOfferDTO;
import com.etisalat.dynamicOffering.controller.api.request.RequestDTO;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingBonus;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingChannel;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsAtl;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsBtl;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingThreshold;
import com.etisalat.dynamicOffering.database.ods.entity.PxDynOfferingParameters;
import com.etisalat.dynamicOffering.database.trm.entity.DynOfferingParameterTRM;
import com.etisalat.dynamicOffering.database.trm.entity.Offering;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingBonusTRM;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingChannelTRM;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingDetails;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingVal;
import com.etisalat.dynamicOffering.database.trm.entity.PxOfferingLPK;
import com.etisalat.dynamicOffering.enums.TrafficCase;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;

@Service
public class SavingOfferService {

	protected final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	OfferingService offeringService;

	@Autowired
	OfferingDetailsService offeringDetailsService;

	@Autowired
	OfferingThresholdService offeringThresholdService;

	@Autowired
	OfferingBonusService offeringBonusService;

	@Autowired
	DynOfferingParameterService dynOfferingParameterService;

	@Autowired
	OfferingChannelsService offeringChannelsService;

	@Autowired
	OfferingContradictionService offeringContradictionService;

	@Autowired
	OfferingCappingService offeringCappingService;

	@Autowired
	OfferingRateplanService offeringRateplanService;

	@Autowired
	DynOfferingConverterService dynOfferingConverterService;

	@Autowired
	OfferingValService offeringValService;

	@Autowired
	PxOfferingLpkService pxOfferingLpkService;

	private static Map<String, Integer> trafficCases = new HashMap<String, Integer>();

	private SystemProperties systemProperties = new SystemProperties();

	public int save(RequestDTO requestDTO, boolean update) {

		// Offering offering = new Offering();

		// Step 1
		requestDTO = saveOffering(requestDTO, update);

		// Step 2
		saveOfferingDetails(requestDTO, update);

		// Step 3
		insertThresholds(requestDTO, update);

		// Step 4
		insertBonus(requestDTO, update);

		// Step 5
		insertOfferingParameter(requestDTO, update);

		// Step 6
		insertChannels(requestDTO, update);

		// Step 7
		insertContradiction(requestDTO, update);

		// Step 8
		insertRatePlan(requestDTO, update);

		// Step 9
		// insertPxRatePlan(offer);

		// Step 10
		// insertOfferConverter(offer);

		return requestDTO.getOfferingId();
	}

	public RequestDTO saveOffering(RequestDTO requestDTO, boolean update) {

		Offering offering = DynamicOfferingMapper.instance.mapOfferingEntity(requestDTO.getOfferingDTO());

		if (!update) {
			offering.setOfferingStartDttm(new Date());
			offering.setDwhEntryDate(new Date());
		}
		offering.setAccountGroupFlag("D");
		offering.setPromotionPlanBeforeId(-1);

		// TODO check why below constants 270 and 0 ??? and convert to LOOK-UP

		if (requestDTO.getOfferingDTO().getTemplateId() == 1)
			offering.setPromotionPlanAfterId(270);
		else
			offering.setPromotionPlanAfterId(0);

//		offering.setOfferingEndDttm(null);
//		offering.setOfferingMask(null);
//		offering.setOfferingBits(null);
//		offering.setCampaignNotificationFlag(null);
//		offering.setBulkActionFlag(null);
//		offering.setEngagementFlag(null);

		offering = offeringService.saveOffering(offering);

		// set OfferId after saving
		requestDTO.setOfferingId(offering.getOfferingId());

		return requestDTO;
	}

	public void saveOfferingDetails(RequestDTO requestDTO, boolean update) {

		// set OfferId
		requestDTO.getOfferingDetailsDTO().setOfferingId(requestDTO.getOfferingId());

		/**/
		// offeringDetails.setOfferingId(requestDTO.getOfferingDetailsDTO().getOfferingId());

		// 5 (offer with attribute) -- 4 (promotion plan)
		requestDTO.getOfferingDetailsDTO().setInOfferTypeId(5);

		// offeringDetails.setShortCodeNum(String.valueOf(offer.getDefinition().getShortCode().getShortCode()));
		// offeringDetails.setOfferingCategory(offer.getDefinition().getCategoryId().toString());

		requestDTO.getOfferingDetailsDTO().setOfferHiddenFlag("true");

		// offeringDetails.setOfferingLineType(offer.getDefinition().getCampaignType());

		// offeringDetails.setOfferingShortDesc(offer.getDefinition().getUssdShortDescription());
		// offeringDetails.setOfferingLongDesc(offer.getDefinition().getUssdLongDescription());
		// offeringDetails.setOnlineFlag(offer.getDefinition().isOnline() == true ? 1 :
		// 0);

		// Rate plans are inserted in separate table
		// offeringDetails.setRatePlanFlag(offer.getDefinition().getEligibleRatePlanBTL());

		/*
		 * TODO check why salefny and SettlmentOffer in offer details
		 * 
		 */

		// offeringDetails.setSalefny(offer.getConfiguration().isSalefny() == true ? 1 :
		// 0);
		// offeringDetails.setSettlmentOffer(offer.getConfiguration().isSettlmentOffer()
		// == true ? 1 : 0);

		/**/
		// if (offer.getDefinition().getOptinFeesFlag())
		// offeringDetails.setOfferOptinFees(offer.getDefinition().getFees() == null ? 0
		// : offer.getDefinition().getFees());
		// else
		// offeringDetails.setOfferOptinFees(0F);

		// if (offer.getDefinition().getTemplateId() == 1)
		// offeringDetails.setPromotionPlanId(270); // from lookup
		// else
		// offeringDetails.setPromotionPlanId(0);

		/*
		 * TODO re-formate below code with correct logic ????
		 * 
		 */
		/*
		 * try { DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy"); Date
		 * promotionPlanStartDate = null; Date promotionPlanEndtDate = null;
		 * 
		 * if (!update) promotionPlanStartDate = new Date(); /* if
		 * (offer.getConfiguration().getPromotionPlanStartDate() != null)
		 * promotionPlanStartDate =
		 * formatter.parse(offer.getConfiguration().getPromotionPlanStartDate ());
		 */

		/*
		 * if (offer.getConfiguration().getPromotionPlanEndDate() != null)
		 * promotionPlanEndtDate =
		 * formatter.parse(offer.getConfiguration().getPromotionPlanEndDate());
		 */
		/*
		 * formatter = new SimpleDateFormat("yyyy-MM-dd"); String promotionPlanStartDt =
		 * null; String promotionPlanEndDt = null;
		 */
		/*
		 * if (!update) if (offer.getConfiguration().getPromotionPlanStartDate() !=
		 * null) promotionPlanStartDt = formatter.format(promotionPlanStartDate);
		 * 
		 * if (offer.getConfiguration().getPromotionPlanEndDate() != null)
		 * promotionPlanEndDt = formatter.format(promotionPlanEndtDate);
		 * 
		 * if (promotionPlanStartDt != null)
		 * offeringDetails.setPromotionPlanStartDt(formatter.parse(promotionPlanStartDt)
		 * ); else offeringDetails.setPromotionPlanStartDt(null);
		 * 
		 * if (promotionPlanEndDt != null)
		 * offeringDetails.setPromotionPlanEndDt(formatter.parse(promotionPlanEndDt));
		 * else offeringDetails.setPromotionPlanEndDt(null);
		 * 
		 * } catch (ParseException e) { // TODO Auto-generated catch block
		 * e.printStackTrace(); }
		 */

		/**/

		// offeringDetails.setAccumulationFlag(offer.getConfiguration().isAccumlation()
		// == true ? 1 : 0);

		// offeringDetails.setBonusValidity(offer.getConfiguration().getBonusValidity());
		// offeringDetails.setSubSendSmsFlag(offer.getConfiguration().isSubscriptionSendSMS()
		// == true ? 1 : 0);

		// offeringDetails.setOfferingVal(offer.getDefinition().getOfferingfval());

		// offeringDetails.setSssId((int)
		// offer.getDefinition().getShortCode().getServiceId());
		// offeringDetails.setSssName(offer.getDefinition().getShortCode().getServiceName());

		// OFFERING HUB ENHANCEMENT
		// offeringDetails.setCommercialServiceDescAR(offer.getDefinition().getCommercialServiceDescriptionAR());
		// offeringDetails.setCommercialServiceDescEN(offer.getDefinition().getCommercialServiceDescriptionEn());

		// case mutli tiers
		// offeringDetails.setMultipleThresholdFlag(offer.getConfiguration().getDynBonus().getTiers().size()
		// > 1 ? 1 : 0);

		// offeringDetails.setIsInformative(offer.getDefinition().isInformativeOffer()
		// == true ? 1 : 0);

		// offeringDetails.setResourceType(offer.getConfiguration().getDynBonus().getBonusType().toString());

		// offeringDetails.setOptinScriptAr(offer.getDefinition().getOptinScriptAr());
		// offeringDetails.setOptinScriptEn(offer.getDefinition().getOptinScriptEn());

		// offeringDetails.setBonusTypeFlag(offer.getConfiguration().isBonusTypeFlag()
		// == true ? 2 : 1);

		// if (offer.getConfiguration().isAccumlation() == true)
		// offeringDetails.setAccumlationDuration(offer.getConfiguration().getAccumlationDuration());

		OfferingDetails offeringDetailsRTM = DynamicOfferingMapper.instance
				.mapOfferingTrmEntity(requestDTO.getOfferingDetailsDTO());

		if (!update) {

			// TODO based lineType

			if (requestDTO.getOfferingDetailsDTO().getOfferingLineType().equals("ATL")) {
				OfferingDetailsAtl offeringDetailsAtl = DynamicOfferingMapper.instance
						.mapOfferingAtlEntity(requestDTO.getOfferingDetailsDTO());

				offeringDetailsService.insertATL(offeringDetailsAtl);
			} else if ((requestDTO.getOfferingDetailsDTO().getOfferingLineType().equals("BTL"))) {
				OfferingDetailsBtl offeringDetailsBtl = DynamicOfferingMapper.instance
						.mapOfferingBtlEntity(requestDTO.getOfferingDetailsDTO());

				offeringDetailsService.insertBTL(offeringDetailsBtl);
			}

			offeringDetailsService.insertOfferingDetailsTRM(offeringDetailsRTM);

		} else {

			// pxOfferingDetailsDao.update(new PxOfferingDetailsPk(offeringId),
			// pxOfferingDetails);
			// updatePxOfferingDetails(offeringId, offer);

		}

		// return offeringDetails;
	}

	public RequestDTO insertThresholds(RequestDTO requestDTO, boolean update) {

//		List<OfferingThreshold> offeringThresholds = DynamicOfferingMapper.instance.mapOfferingThresholdEntity(requestDTO.getOfferingThresholdsDTO());
//
//
//		for (OfferingThreshold offeringThreshold : offeringThresholds) {
//			
//			// set OfferId 
//			offeringThreshold.setOfferingId(requestDTO.getOfferingId());
//			
//			offeringThresholdService.insertOfferingThresholds(offeringThreshold);
//		}
//		

		return null;
	}

	public void insertBonus(RequestDTO requestDTO, boolean update) {

//		List<OfferingBonus> offeringBonusList = DynamicOfferingMapper.instance.mapOfferingBonusEntity(requestDTO.getOfferingBonusDTO());
//
//		
//		for (OfferingBonus offeringBonus: offeringBonusList) {
//			
//			//set offer Id
//			offeringBonus.setOfferingId(requestDTO.getOfferingId());
//			
//			offeringBonusService.insertOfferingBonusTRM(offeringBonus);
//		}

	}

	public void insertOfferingParameter(RequestDTO requestDTO, boolean update) {

		/*
		 * // TODO // add migration flag as a parameter if
		 * (offer.getConfiguration().isMigrationFlag()) { DynOfferingParameter
		 * dynOfferingParameter = new DynOfferingParameter(); }
		 * 
		 * // TODO // add dynamic quota flag as a parameter on Bonus on renewal if
		 * (offer.getDefinition().getTemplateId() == 3) {
		 * 
		 * }
		 * 
		 * // TODO // for only Bonus on renewal. for (OfferingParameter bonusParameter :
		 * offer.getConfiguration().getPxDynOfferingParametersList()) {
		 * 
		 * }
		 */

//		List<DynOfferingParameter> dynOfferingParameters = DynamicOfferingMapper.instance.mapDynOfferingParameterEntity(requestDTO.getDynOfferingParametersDTO());
//
//		for (DynOfferingParameter dynOfferingParameter : dynOfferingParameters) {
//
//			dynOfferingParameter.setOfferingId(requestDTO.getOfferingId());
//			
//			dynOfferingParameterService.insertOfferingParameterTRM(dynOfferingParameter);
//	
//		}

	}

	public void insertChannels(RequestDTO requestDTO, boolean update) {
//		
//		List<OfferingChannel> offeringChannels = DynamicOfferingMapper.instance.mapOfferingChannelsEntity(requestDTO.getOfferingChannelsDTO());
//
//		
//		for (OfferingChannel offeringChannel: offeringChannels) {
//			offeringChannel.setOfferingId(requestDTO.getOfferingId());
//			
//			offeringChannelsService.insertOfferingChannelsTRM(offeringChannel);
//		}
//		

	}

	public void insertContradiction(RequestDTO requestDTO, boolean update) {
//		
//		List<OfferingContradiction> offeringContradictions = DynamicOfferingMapper.instance.mapOfferingContradictionsEntity(requestDTO.getOfferingContradictionsDTO());
//
//		
//		for (OfferingContradiction offeringContradiction : offeringContradictions) {
//			
//			offeringContradiction.setOfferingId(requestDTO.getOfferingId());
//			
//			offeringContradictionService.insertOfferingContradictionTRM(offeringContradiction);
//		}

	}

	public void insertPxOfferCapping(RequestDTO requestDTO, boolean update) {
//		
//		OfferingCapping offeringCapping = DynamicOfferingMapper.instance.mapOfferingCappingsEntity(requestDTO.getOfferingCappingDTO());
//
//		offeringCappingService.insertOfferingCappingTRM(offeringCapping);
	}

	public void insertRatePlan(RequestDTO requestDTO, boolean update) {

//		List<OfferingRateplan> offeringRateplans = DynamicOfferingMapper.instance.mapOfferingRateplansEntity(requestDTO.getOfferingRateplansDTO());
//
//		
//		for (OfferingRateplan offeringRateplan : offeringRateplans) {
//			
//			offeringRateplan.setOfferingId(requestDTO.getOfferingId());
//			offeringRateplanService.insertOfferingRateplanTRM(offeringRateplan);
//		}

	}

	public void insertOfferConverter(RequestDTO requestDTO, boolean update) throws Exception {

//		DynOfferingConverter dynOfferingConverter = DynamicOfferingMapper.instance.mapDynOfferingConverterEntity(requestDTO.getDynOfferingConverterDTO());
//
//		dynOfferingConverterService.insertDynOfferingConverterTRM(dynOfferingConverter);
	}

	public int savePxOffer(PxOfferDTO pxOfferDTO, boolean isUpdate) throws Exception {
		/*** save Offer ***/
		return insertOrUpdateOffer(pxOfferDTO, isUpdate);
	}

	private Integer insertOrUpdateOffer(PxOfferDTO pxOfferDTO, boolean isUpdate) throws Exception {
		Offering offering;
		Integer offeringId;
		OfferingDetails pxOfferingDetails;
//		try {

		offering = insertOffering(pxOfferDTO, isUpdate);
		offeringId = offering.getOfferingId();
		pxOfferDTO.setId(offeringId);

		pxOfferingDetails = insertPxOfferingDetails(offeringId, pxOfferDTO, isUpdate);
		// offering hub enhancements

		if (!isUpdate) {
			insertThresholds(offeringId, pxOfferDTO, isUpdate);

			// add migration flag as a parameter
			if (pxOfferDTO.getConfiguration().isMigrationFlag()) {
				PxDynOfferingParameters bonusParameter = new PxDynOfferingParameters();
				bonusParameter.setOfferingId(offeringId);
				bonusParameter.setParameterTypeId(systemProperties.getParameterTypeId_migrationFlag());
				// bonusParameter.setParameterTxt("Migration_Flag");// the Migration flag when
				// true
				bonusParameter.setParameterTxt("Y");// the Migration flag is 1 when true
				dynOfferingParameterService.insertOfferingParameter(bonusParameter);
			} else {
				PxDynOfferingParameters bonusParameter = new PxDynOfferingParameters();
				bonusParameter.setOfferingId(offeringId);
				bonusParameter.setParameterTypeId(systemProperties.getParameterTypeId_migrationFlag());
				// bonusParameter.setParameterTxt("Migration_Flag");// the Migration flag when
				// true
				bonusParameter.setParameterTxt("N");// the Migration flag is 1 when true
				dynOfferingParameterService.insertOfferingParameter(bonusParameter);
			}

			// add dynamic quota flag as a parameter on Bonus on renewal
			if (pxOfferDTO.getDefinition().getPxOfferingTemplates().getTemplateId() == 3) {
				PxDynOfferingParameters bonusParameter = new PxDynOfferingParameters();
				bonusParameter.setOfferingId(offeringId);
				bonusParameter.setParameterTypeId(systemProperties.getParameterTypeId_dynamicQuotaFlag());

				bonusParameter.setParameterTxt(pxOfferDTO.getConfiguration().isDynamicQuota() == true ? "1" : "0");// DynamicQuota
																													// flag
																													// is
																													// 1
																													// when
																													// true
				dynOfferingParameterService.insertOfferingParameter(bonusParameter);
			}

			if (pxOfferDTO.getDefinition().getPxOfferingTemplates().getTemplateId() == 7) {
				PxDynOfferingParameters bounsParam = new PxDynOfferingParameters();
				bounsParam.setOfferingId(offeringId);
				bounsParam.setParameterTypeId(systemProperties.getParameterTypeId_renewalOnFlag());
				bounsParam.setParameterTxt(pxOfferDTO.getConfiguration().isRenewalOnTime() == true ? "1" : "0");
				dynOfferingParameterService.insertOfferingParameter(bounsParam);
			}

			if (pxOfferDTO.getDefinition().getPxOfferingTemplates().getTemplateId() == 6) {
				PxDynOfferingParameters bounsParam = new PxDynOfferingParameters();
				bounsParam.setOfferingId(offeringId);
				bounsParam.setParameterTypeId(systemProperties.getParameterTypeId_bundleTypeId());
				bounsParam.setParameterTxt(pxOfferDTO.getDefinition().getBundleType());
				dynOfferingParameterService.insertOfferingParameter(bounsParam);
			}

			// Partial Renewal parameters
			if (pxOfferDTO.getDefinition().getPxOfferingTemplates().getTemplateId() == 9) {
				PxDynOfferingParameters bounsParam = new PxDynOfferingParameters();
				bounsParam.setOfferingId(offeringId);
				bounsParam.setParameterTypeId(systemProperties.getParameterTypeId_offerType());
				bounsParam.setParameterTxt(pxOfferDTO.getDefinition().getPxOfferingOffval().getOfferType());
				dynOfferingParameterService.insertOfferingParameter(bounsParam);
			}

			List<PxDynOfferingParameters> odsBonusList = new ArrayList<>();
			List<DynOfferingParameterTRM> trmBonusList = new ArrayList<>();
			PxDynOfferingParameters param = null;
			for (OfferPxDynOfferingParametersDTO bonusParameter : pxOfferDTO.getConfiguration().getDynBonus()
					.getPxDynOfferingParametersList()) {
				// check filled parameters, as we initialize 6 params by
				// default

				if (bonusParameter.getParameterTxt() != null && !bonusParameter.getParameterTxt().isEmpty()) {
					bonusParameter.setOfferingId(offeringId);
					bonusParameter.setParameterTypeId(bonusParameter.getPxDynOfferingParamLkp().getParameterTypeId());
					bonusParameter.setParameterTxt(bonusParameter.getParameterTxt());

					param = DynamicOfferingMapper.instance.mapDtoToDynOfferingParameter(bonusParameter);
					odsBonusList.add(param);
					trmBonusList.add(DynamicOfferingMapper.instance.mapDynOfferingParameterEntityTRM(param));
				}
			}
			dynOfferingParameterService.insertOfferingParameters(odsBonusList, trmBonusList);

			insertChannels(offeringId, pxOfferDTO, isUpdate);

			// TODO contradiction later
//				insertContradiction(offeringId, pxOfferDTO, isUpdate);

			pxOfferDTO.getConfiguration().getPxOfferingCapping().setOfferingId(offeringId);

			// inject pxofferingcapping with
			// action,sourcebundle,targetbundle
			pxOfferDTO.getConfiguration().getPxOfferingCapping()
					.setSourceBundle(pxOfferDTO.getConfiguration().getSourceBundle());
			pxOfferDTO.getConfiguration().getPxOfferingCapping()
					.setTargetBundle(pxOfferDTO.getConfiguration().getTargetBundle());
			pxOfferDTO.getConfiguration().getPxOfferingCapping().setAction(pxOfferDTO.getConfiguration().getAction());

			// RENEWABLE ADDONS SCOPE | copy existing values into
			// pxofferingCapping.
			pxOfferDTO.getConfiguration().getPxOfferingCapping()
					.setUnsettlementOffer(pxOfferDTO.getConfiguration().isSettlmentOffer() == true ? "Y" : "N");
			pxOfferDTO.getConfiguration().getPxOfferingCapping()
					.setProductValidity(pxOfferDTO.getConfiguration().getBonusValidity());

			if (!pxOfferDTO.getConfiguration().getDynBonus().getTiers().isEmpty()
					&& (!pxOfferDTO.getConfiguration().getDynBonus().getTiers().get(0).getBonusList().isEmpty()))
				pxOfferDTO.getConfiguration().getPxOfferingCapping().setBundleType(pxOfferDTO.getConfiguration()
						.getDynBonus().getTiers().get(0).getBonusList().get(0).getBonusType().getId());

			insertPxOfferCapping(pxOfferDTO.getConfiguration().getPxOfferingCapping(), isUpdate);

			// TODO rateplans later
//				insertPxRatePlan(offeringId, pxOfferDTO, isUpdate);

			// Insert Converter Details
			insertOfferConverter(pxOfferDTO, offeringId);

		}
//			else {
//				updateThresholds(offeringId, pxOfferDTO, isUpdate);
//				updateChannels(offeringId, pxOfferDTO);
//				updateContradiction(offeringId, pxOfferDTO);
//				pxOfferDTO.getConfiguration().getPxOfferingCapping().setOfferingId(offeringId);
//				updatePxOfferCapping(offeringId, pxOfferDTO.getConfiguration().getPxOfferingCapping(), isUpdate);
//				updatePxOfferingRatePlan(offeringId, pxOfferDTO);
//			}
//		} catch (Exception e) {
//			if (!isUpdate)
//				rollBack(pxOfferDTO);
//			throw new Exception(e);
//
//		}
//			
//			// reload offer data
//			try {
//				prepareOffer(offer, offeringId, offer.getDefinition().getOfferName(), dataBean.getAvailableCategories(), getPxOfferingDetailsList(),
//
//				offeringChannelDao.findWhereOfferingIdEquals(offeringId), offeringContradictionDao.findWhereOfferingIdEquals(offeringId),
//						offeringThresholdDao.findWhereOfferingIdEquals(offeringId), offeringBonusDao.findWhereOfferingIdEquals(offeringId), dataBean.getOptin(), dataBean.getOptout(),
//						dataBean.getRedemption(), pxOfferingCappingDao.findWhereOfferingIdEquals(offeringId), getPxDynOfferingParametersLKP(), dataBean.getAvailableRatePlans());
//
//				if (update) {
//
//					dataBean.getAvailableOfferings().set(dataBean.getAvailableOfferings().indexOf(offering), offering);
//					dataBean.getAvailablePxOfferingDetails().set(dataBean.getAvailablePxOfferingDetails().indexOf(pxOfferingDetails), pxOfferingDetails);
//					dataBean.getAvailableOffers().set(dataBean.getAvailableOffers().indexOf(offer), offer);
//				} else {
//					dataBean.getAvailableOfferings().add(offering);
//					dataBean.getAvailablePxOfferingDetails().add(pxOfferingDetails);
//					dataBean.getAvailableOffers().add(offer);
//				}
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
		return offeringId;
	}

	private Offering insertOffering(PxOfferDTO offer, boolean update) {
		boolean offvalIsSet = false;

		Offering offering = new Offering();
		offering.setOfferingName(offer.getDefinition().getOfferName());
		offering.setOfferingDesc(offer.getDefinition().getOfferName());

		if (!update)
			offering.setOfferingStartDttm(new Date());
		offering.setOfferingEndDttm(null);
		offering.setOfferingMask(null);
		offering.setOfferingBits(null);

		List<OfferingVal> eligibleOffVals = offeringValService
				.findByServiceId(offer.getDefinition().getPxShortCode().getServiceId());
		if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 1) {// BOR

			if (offer.getDefinition().isPullOffer()) {

				for (OfferingVal offVal : eligibleOffVals) {
					if (offVal.getParameterName().equalsIgnoreCase("granting_mechanism")
							&& offVal.getParameterValue().equalsIgnoreCase("pull")) {
						offering.setOfferingVal(String.valueOf(offVal.getOfferingVal()));
					}

				}

			} else if (!offer.getDefinition().isPullOffer()) {
				for (OfferingVal offVal : eligibleOffVals) {
					if (offVal.getParameterName().equalsIgnoreCase("granting_mechanism")
							&& offVal.getParameterValue().equalsIgnoreCase("push")) {
						offering.setOfferingVal(String.valueOf(offVal.getOfferingVal()));
					}

				}
			}
		}
		// BONUS_ON_RENEWAL , PAY_AND_GET , RENEWABLE_ADDONS
		else {

			offering.setOfferingVal(String.valueOf(eligibleOffVals.get(0).getOfferingVal()));
		}

		if (!update)
			offering.setDwhEntryDate(new Date());

		// ?
		offering.setSssId((int) offer.getDefinition().getPxShortCode().getServiceId());
		offering.setSssName(offer.getDefinition().getPxShortCode().getServiceName());
		offering.setAccountGroupFlag("D");
		offering.setPromotionPlanBeforeId(-1);
		if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 1)
			offering.setPromotionPlanAfterId(270);
		else
			offering.setPromotionPlanAfterId(0);
		offering.setCampaignNotificationFlag(null);
		offering.setBulkActionFlag(null);
		offering.setEngagementFlag(null);

		if (!update)
			offering.setOfferingId(offeringService.saveOffering(offering).getOfferingId());
		else {
//			offeringDao.update(new OfferingPk(String.valueOf(offer.getId())), offering);
//			offering.setOfferingId(offer.getId());
//			// updateOffering(offer.getId(), offer);
//			// offering.setOfferingId(offer.getId());
		}

		return offering;
	}

	private OfferingDetails insertPxOfferingDetails(Integer offeringId, PxOfferDTO offer, boolean update)
			throws Exception {

		OfferingDetails pxOfferingDetails = new OfferingDetails();

		pxOfferingDetails.setOfferingId(offeringId);
		pxOfferingDetails.setOfferingName(offer.getDefinition().getOfferName());

		if (!update)
			pxOfferingDetails.setOfferingStartDt(new Date());

		if (!update)
			pxOfferingDetails.setDWHEntryDate(new Date());

		// 5 (offer with attribute) -- 4 (promotion plan)
		pxOfferingDetails.setInOfferTypeId(5);
		pxOfferingDetails.setOfferingEngDesc(offer.getDefinition().getMediaEnglishDescription());
		pxOfferingDetails.setOfferingArDesc(offer.getDefinition().getMediaArabicDescription());

		pxOfferingDetails.setValidRenewalPeriod(offer.getConfiguration().getValidRenewalPeriod() != null
				? offer.getConfiguration().getValidRenewalPeriod()
				: 0);

		pxOfferingDetails.setOfferingDuration(
				offer.getConfiguration().getOfferingDuration() != null ? offer.getConfiguration().getOfferingDuration()
						: 0);

		// pxOfferingDetails.setPromotionPlanDuration(offer.getConfiguration().getPromotionPlanDuration());

		pxOfferingDetails.setOptInOfferingDuration(offer.getConfiguration().getOptinOfferingDuration() != null
				? offer.getConfiguration().getOptinOfferingDuration()
				: 0);

		if (offer.getDefinition().isPullOffer())
			pxOfferingDetails.setRedemptionWindow(offer.getConfiguration().getRedemptionWindow());
		else
			pxOfferingDetails.setRedemptionWindow(0);

		pxOfferingDetails.setShortCodeNum(String.valueOf(offer.getDefinition().getPxShortCode().getShortCode()));
		pxOfferingDetails.setOfferingCategory(offer.getDefinition().getPxServiceCategory().getCategoryId().trim());
		pxOfferingDetails.setOfferHiddenFlag("true");
		pxOfferingDetails.setOfferingLineType(offer.getDefinition().getSelectedCampaignType());
		pxOfferingDetails.setOfferingShortDesc(offer.getDefinition().getUssdShortDescription());
		pxOfferingDetails.setOfferingLongDesc(offer.getDefinition().getUssdLongDescription());
		pxOfferingDetails.setOnlineFlag(offer.getDefinition().isOnline() == true ? 1 : 0);

		// Rate plans are inserted in separate table
		pxOfferingDetails.setRatePlanFlag(offer.getDefinition().getRatePlan());

		// Commented as there's no ref to this obj in model class and also not saved in
		// old dynamic offering
//		pxOfferingDetails.setSalefny(offer.getConfiguration().isSalefny() == true ? 1 : 0);
//		pxOfferingDetails.setSettlmentOffer(offer.getConfiguration().isSettlmentOffer() == true ? 1 : 0);

		if (offer.getDefinition().isOptinFeesFlag())
			pxOfferingDetails
					.setOfferOptinFees(offer.getDefinition().getFees() == null ? 0 : offer.getDefinition().getFees());
		else
			pxOfferingDetails.setOfferOptinFees(0f);

		if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 1)
			pxOfferingDetails.setPromotionPlanId(270);// from lookup
		else
			pxOfferingDetails.setPromotionPlanId(0);

		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");

		Date promotionPlanStartDate = null;

		Date promotionPlanEndtDate = null;

		if (!update)
			promotionPlanStartDate = new Date();
		/*
		 * if (offer.getConfiguration().getPromotionPlanStartDate() != null)
		 * promotionPlanStartDate =
		 * formatter.parse(offer.getConfiguration().getPromotionPlanStartDate ());
		 */

		if (offer.getConfiguration().getPromotionPlanEndDate() != null)
			promotionPlanEndtDate = formatter.parse(offer.getConfiguration().getPromotionPlanEndDate());

//		formatter = new SimpleDateFormat("yyyy-MM-dd");
		String promotionPlanStartDt = null;
		String promotionPlanEndDt = null;

		if (!update)
			/* if (offer.getConfiguration().getPromotionPlanStartDate() != null) */
			promotionPlanStartDt = formatter.format(promotionPlanStartDate);

		if (offer.getConfiguration().getPromotionPlanEndDate() != null)
			promotionPlanEndDt = formatter.format(promotionPlanEndtDate);

		if (promotionPlanStartDt != null)
			pxOfferingDetails.setPromotionPlanStartDt(formatter.parse(promotionPlanStartDt));
		else
			pxOfferingDetails.setPromotionPlanStartDt(null);

		if (promotionPlanEndDt != null)
			pxOfferingDetails.setPromotionPlanEndDt(formatter.parse(promotionPlanEndDt));
		else
			pxOfferingDetails.setPromotionPlanEndDt(null);

		pxOfferingDetails.setAccumulationFlag(offer.getConfiguration().isAccumlation() == true ? 1 : 0);

		pxOfferingDetails.setBonusValidity(offer.getConfiguration().getBonusValidity());
		pxOfferingDetails.setSubSendSmsFlag(offer.getConfiguration().isSubscriptionSendSM() == true ? 1 : 0);

		List<OfferingVal> eligibleOffVals = offeringValService
				.findByServiceId(offer.getDefinition().getPxShortCode().getServiceId());

		if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 1) {// BOR

			if (offer.getDefinition().isPullOffer()) {

				for (OfferingVal offVal : eligibleOffVals) {
					if (offVal.getParameterName().equalsIgnoreCase("granting_mechanism")
							&& offVal.getParameterValue().equalsIgnoreCase("pull")) {
						pxOfferingDetails.setOfferingVal(offVal.getOfferingVal());
					}

				}

			} else if (!offer.getDefinition().isPullOffer()) {
				for (OfferingVal offVal : eligibleOffVals) {
					if (offVal.getParameterName().equalsIgnoreCase("granting_mechanism")
							&& offVal.getParameterValue().equalsIgnoreCase("push")) {
						pxOfferingDetails.setOfferingVal(offVal.getOfferingVal());
					}

				}
			}
		} else if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 2) { // PAY
																							// AND
																							// GET

			pxOfferingDetails.setOfferingVal(eligibleOffVals.get(0).getOfferingVal());
		}
		// Bonus on renewal
		else if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 3) {

			try {
				pxOfferingDetails.setOfferingVal(eligibleOffVals.get(0).getOfferingVal());
			} catch (Exception e) {
				System.out.println("outOfBoundException");
			}
		}

		else if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 6) {
			pxOfferingDetails.setOfferingVal(offer.getDefinition().getPxOfferingOffval().getOfferingVal());

		}

		else if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 7) {

			pxOfferingDetails.setOfferingVal(offer.getDefinition().getPxOfferingOffval().getOfferingVal());

		}
		// Use And Get
		else if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 8) {

			try {
				pxOfferingDetails.setOfferingVal(eligibleOffVals.get(0).getOfferingVal());
			} catch (Exception e) {
				System.out.println("outOfBoundException");
			}
		}

		pxOfferingDetails.setSssId((int) offer.getDefinition().getPxShortCode().getServiceId());
		pxOfferingDetails.setSssName(offer.getDefinition().getPxShortCode().getServiceName());

		if (offer.getDefinition().isPullOffer())
			pxOfferingDetails.setGrantingMechanism(2);
		else
			pxOfferingDetails.setGrantingMechanism(1);

		// OFFERING HUB ENHANCEMENT
		pxOfferingDetails.setCommercialServiceDescAR(offer.getDefinition().getCommercialArabicServiceDescription());
		pxOfferingDetails.setCommercialServiceDescEN(offer.getDefinition().getCommercialEnglishServiceDescription());
		// case mutli tiers
		pxOfferingDetails
				.setMultipleThresholdFlag(offer.getConfiguration().getDynBonus().getTiers().size() > 1 ? 1 : 0);

		pxOfferingDetails.setIsInformative(offer.getDefinition().isInformativeOffer() == true ? 1 : 0);
		pxOfferingDetails.setResourceType(offer.getConfiguration().getDynBonus().getBonusType().toString());

		pxOfferingDetails.setOptinScriptAr(offer.getDefinition().getOptinScriptAr());
		pxOfferingDetails.setOptinScriptEn(offer.getDefinition().getOptinScriptEn());

		pxOfferingDetails.setBonusTypeFlag(offer.getConfiguration().isBonusTypeFlag() == true ? 2 : 1);

		if (offer.getConfiguration().isAccumlation() == true)
			pxOfferingDetails.setAccumlationDuration(offer.getConfiguration().getAccumlationDuration());

//		   /**
//		   
//		    * zika change and pay and get */ 
//		    	
//		PxOfferingLPK  pxOfferingLPK = pxOfferingLPKDao.findWhereServiceIdEquals(String.valueOf(offer.getDefinition().getPxShortCode().getServiceId()), offer.getDefinition().getPxOfferingOffval().getOfferingVal());
//		    
//			
//		//PxOfferingLPK pxOfferingLPK = pxOfferingLPKDao.findWhereServiceId(String.valueOf(offer.getDefinition().getPxShortCode().getServiceId()));

		/****** Changed by @Eman ******/
		// TODO need to check with mustafa :D
		PxOfferingLPK pxOfferingLPK = null;

		if (offer.getDefinition().getPxOfferingOffval() != null && offer.getDefinition().getPxOfferingOffval().getOfferingVal() != null) {
			LOGGER.info("Condition 1 - Offering_Val value is not null : " + offer.getDefinition().getPxOfferingOffval().getOfferingVal());
			pxOfferingLPK = pxOfferingLpkService.findByServiceIdAndOfferingValNative(
					String.valueOf(offer.getDefinition().getPxShortCode().getServiceId()),
					String.valueOf(offer.getDefinition().getPxOfferingOffval().getOfferingVal()));
		} else {
			LOGGER.info("Condition 2 - Offering_Val value is null");
			pxOfferingLPK = pxOfferingLpkService
					.findByServiceIdNative(String.valueOf(offer.getDefinition().getPxShortCode().getServiceId()));
		}

		pxOfferingDetails.setPlatformId(pxOfferingLPK.getPlatformId());
		pxOfferingDetails.setOperationId(pxOfferingLPK.getOperationId());
		pxOfferingDetails.setProductName(pxOfferingLPK.getProductName());

		pxOfferingDetails.setPlatformArDesc(pxOfferingLPK.getPlatformArDesc());
		pxOfferingDetails.setPlatformEnDesc(pxOfferingLPK.getPlatformEnDesc());

		if (!update) {
			offeringDetailsService.insertOfferingDetails(pxOfferingDetails);
		} else {

//			pxOfferingDetailsDao.update(new PxOfferingDetailsPk(offeringId), pxOfferingDetails);
//			// updatePxOfferingDetails(offeringId, offer);

		}

		return pxOfferingDetails;

	}

	private void insertThresholds(Integer offeringId, PxOfferDTO offer, boolean update) throws Exception {

		OfferingThreshold threshold;
		int counter = 4;
		int thresholdId = 1;
//		// List<Tier> tiers = offer.getConfiguration().getDynBonus().getTiers();
//		Collections.sort(offer.getConfiguration().getDynBonus().getTiers());
		offer.getConfiguration().getDynBonus().getTiers().stream().sorted();

		for (OfferTierDTO t : offer.getConfiguration().getDynBonus().getTiers()) {
			threshold = new OfferingThreshold();
			threshold.setOfferingId(offeringId);
			threshold.setThresholdId(thresholdId);
			if (offer.getConfiguration().getDynBonus().getBonusType().equals(TrafficCase.POOL)
					|| offer.getConfiguration().getDynBonus().getBonusType().equals(TrafficCase.MIXED))
				threshold.setPoolValue(t.getPoolBonusValue());
			else
				threshold.setPoolValue(0f);
			threshold.setThresholdValue(t.getThresholdValue());
			offeringThresholdService.insertOfferingThreshold(threshold);

			insertBonus(offeringId, t, thresholdId, offer.getConfiguration().getDynBonus().getBonusType(), update);

			thresholdId++;

		}
		// check for missing threshold(s) and add them
		if (thresholdId > 2 && thresholdId < counter) {

			// for (int i = 0; i < counter - thresholdId; i++) {
			threshold = new OfferingThreshold();
			threshold.setOfferingId(offeringId);
			threshold.setThresholdId(thresholdId);
			if (offer.getConfiguration().getDynBonus().getBonusType().equals(TrafficCase.POOL)
					|| offer.getConfiguration().getDynBonus().getBonusType().equals(TrafficCase.MIXED))
				threshold.setPoolValue(0f);
			else
				threshold.setPoolValue(0f);
			threshold.setThresholdValue(2000f);
			offeringThresholdService.insertOfferingThreshold(threshold);

			insertBonus(offeringId, new OfferTierDTO(), thresholdId,
					offer.getConfiguration().getDynBonus().getBonusType(), update);

			thresholdId++;

			// }

		}

	}

	@SuppressWarnings("null")
	private void insertBonus(Integer offeringId, OfferTierDTO tier, int thresholdId, TrafficCase bonusType,
			boolean update) throws Exception {

		OfferingBonus offeringBonus;
		String trafficCase;
		List<OfferingBonus> offeringBonusList = new ArrayList<OfferingBonus>();

		boolean isBonusOnRenewal = !bonusType.equals(TrafficCase.UNIT) && !bonusType.equals(TrafficCase.POOL)
				&& !bonusType.equals(TrafficCase.MIXED);

		try {
			for (OfferBonusDTO bonus : tier.getBonusList()) {
				offeringBonus = new OfferingBonus();

				offeringBonus.setThresholdId(thresholdId);
				offeringBonus.setPoolBonusFlag(bonus.isPoolBonusFlag() == true ? 1 : 0);
				offeringBonus.setOfferingId(offeringId);
				System.out.println("offeringId" + offeringId);

				if (bonusType.equals(TrafficCase.POOL)
						|| (bonusType.equals(TrafficCase.MIXED) && (bonus.isPoolBonusFlag())))
					offeringBonus
							.setBonusValue((bonus.getConsumptionValue() == null ? 0f : bonus.getConsumptionValue()));
				else if (bonusType.equals(TrafficCase.UNIT)
						|| (bonusType.equals(TrafficCase.MIXED) && (!bonus.isPoolBonusFlag())))
					offeringBonus.setBonusValue(bonus.getBonusValue() == null ? 0 : bonus.getBonusValue());

				else if (bonusType.equals(TrafficCase.VOUCHER) || bonusType.equals(TrafficCase.DYNAMIC_DISCOUNT)
						|| bonusType.equals(TrafficCase.MORE_PLUS) || bonusType.equals(TrafficCase.USAGE_PERCENTAGE)
						|| bonusType.equals(TrafficCase.VOUCHER_UBER) || bonusType.equals(TrafficCase.VOUCHER_FAWRY)) {
//					offeringBonus.setBonusValue(Integer.parseInt(bonus.getVoucherID()));
					offeringBonus.setBonusValue(Float.valueOf(bonus.getBonusValue()));
					offeringBonus.setMqPromoValidity(0);
					offeringBonus.setMqBonusValue(0f);
					offeringBonus.setMqMaxRecurrence(0);

				} else if (bonusType.equals(TrafficCase.MULTIPLE_QUOTA)) {
					offeringBonus.setBonusValue(bonus.getBonusValue() == null ? 0 : bonus.getBonusValue());
					offeringBonus.setMqPromoValidity(bonus.getPromoValidity());
					offeringBonus.setMqBonusValue(bonus.getMultipleQuotaValue());
					offeringBonus.setMqMaxRecurrence(bonus.getMultipleQuotaMaxRecurrence());

//				}
//
//				else if (bonusType.equals(TrafficCase.DYNAMIC_DISCOUNT)) {
//					offeringBonus.setBonusValue(bonus.getBonusDynamicDiscount());
//					offeringBonus.setMqPromoValidity(0);
//					offeringBonus.setMqBonusValue(0f);
//					offeringBonus.setMqMaxRecurrence(0);
//
				} else if (bonusType.equals(TrafficCase.MONTH_ON_OFF)) {
					offeringBonus.setMqPromoValidity(0);
					offeringBonus.setMqBonusValue(0f);
					offeringBonus.setMqMaxRecurrence(0);

				}

//				else if (bonusType.equals(TrafficCase.VOUCHER_FAWRY)) {
////					offeringBonus.setBonusValue(Integer.parseInt(bonus.getFawryVoucherId()));
//					offeringBonus.setBonusValue(Float.valueOf(bonus.getFawryVoucherId()));
//				}
//				else if (bonusType.equals(TrafficCase.VOUCHER_UBER)) {
//					offeringBonus.setBonusValue(Integer.parseInt(bonus.getUberVoucherId()));
				// offeringBonus.setBonusValue(Float.valueOf(bonus.getUberVoucherId()));
				// }
//				else if (bonusType.equals(TrafficCase.USAGE_PERCENTAGE)) {
////					offeringBonus.setBonusValue(Integer.parseInt(bonus.getUsagePercentage()));
//					offeringBonus.setBonusValue(Float.valueOf(bonus.getUsagePercentage()));
//				}
//				else if (bonusType.equals(TrafficCase.MORE_PLUS)) {
////					offeringBonus.setBonusValue(Integer.parseInt(bonus.getMorePlus()));
//					offeringBonus.setBonusValue(Float.valueOf(bonus.getMorePlus()));
//				}

				offeringBonus.setSpecialRorFlag(bonus.isSpecialROR() == true ? 1 : 0);
				offeringBonus.setSpecialRorVal(bonus.getSpecialRORValue() == null ? 0f : bonus.getSpecialRORValue());

				if ((!isBonusOnRenewal) && (bonus.getBonusCategory() != null))
					trafficCase = bonus.getBonusCategory().getName() + "-" + bonus.getBonusType().getName();
				else {

					trafficCase = bonusType.toString();
				}
				offeringBonus.setTrafficCase(trafficCase);
				offeringBonus.setTrafficCaseId(getTrafficCases().get(trafficCase));

				offeringBonus.setBonusCapping(bonus.getBonusCapping());

				offeringBonusList.add(offeringBonus);
			}

			System.out.println("Found " + tier.getBonusList().size() + " bonus in tier " + tier.getThresholdValue());

			List<OfferingBonusTRM> offeringBounsTrmList = new ArrayList<>();
			for (OfferingBonus offeringBonusObject : offeringBonusList) {
				offeringBounsTrmList.add(DynamicOfferingMapper.instance.mapOfferingBonusEntityTRM(offeringBonusObject));
			}
			offeringBonusService.insertOfferingBonusList(offeringBonusList, offeringBounsTrmList);

			///////////////////////////////// notSelectedOfferingBonusList////////////////

//			
//			List<OfferingBonus> notSelectedOfferingBonusList = new ArrayList<OfferingBonus>();
//
//			boolean found;
//
//			for (Entry<String, Integer> t : getTrafficCases().entrySet()) {
//				found = false;
//				for (OfferingBonus offeringBonusObject : offeringBonusList) {
//
//					if (((Integer) t.getValue()).intValue() == offeringBonusObject.getTrafficCaseId()) {
//
//						found = true;
//
//					}
//
//				}
//
//				if (!found) {
//					offeringBonus = new OfferingBonus();
//					// offering hub enhancement
//					offeringBonus.setThresholdId(thresholdId);
//					offeringBonus.setPoolBonusFlag(0);
//					/** offering hub enhancement **/
//					offeringBonus.setOfferingId(offeringId);
//					offeringBonus.setBonusValue(0f);
//					offeringBonus.setSpecialRorFlag(0);
//					offeringBonus.setSpecialRorVal(0f);
//					offeringBonus.setTrafficCase(t.getKey());
//					offeringBonus.setTrafficCaseId(t.getValue());
//					offeringBonus.setMqPromoValidity(0);
//					offeringBonus.setMqMaxRecurrence(0);
//					offeringBonus.setMqBonusValue(0f);
//
//					notSelectedOfferingBonusList.add(offeringBonus);
//
//				}
//
//			}
//			
//			List<OfferingBonusTRM> notSelectedOfferingBounsTrmList = new ArrayList<>();
//			for (OfferingBonus notSelectedOfferingBonus : notSelectedOfferingBonusList) {
//				notSelectedOfferingBounsTrmList.add(DynamicOfferingMapper.instance.mapOfferingBonusEntityTRM(notSelectedOfferingBonus));
//			}
//			offeringBonusService.insertOfferingBonusList(notSelectedOfferingBonusList, notSelectedOfferingBounsTrmList);

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed while inserting traffic cases");
		}

	}

	public Map<String, Integer> getTrafficCases() {
		trafficCases = new HashMap<String, Integer>();
		trafficCases.put("On_net" + "-" + "Voice", 1);
		trafficCases.put("Cross_net" + "-" + "Voice", 2);
		trafficCases.put("On_net" + "-" + "SMS", 3);
		trafficCases.put("Cross_net" + "-" + "SMS", 4);
		trafficCases.put(" " + "-" + "MI", 5);
		trafficCases.put("VOUCHER", 6);
		trafficCases.put("DYNAMIC_DISCOUNT", 7);
		trafficCases.put("MULTIPLE_QUOTA", 8);
		trafficCases.put("MONTH_ON_OFF", 9);

		trafficCases.put(" " + "-" + "UNITS", 10);
		trafficCases.put(" " + "-" + "UNITS_VOICE", 11);
		trafficCases.put(" " + "-" + "UNITS_ONNET_MI", 12);
		trafficCases.put(" " + "-" + "UNITS_ONNET_CORSSNET_MI", 13);

		trafficCases.put("VOUCHER_FAWRY", 14);

		trafficCases.put("VOUCHER_UBER", 15);

		trafficCases.put("Hybrid_Features", 17);

		trafficCases.put("USAGE_PERCENTAGE", 18);

		trafficCases.put("MorePlus", 19);
		return trafficCases;
	}

	private void insertChannels(Integer offeringId, PxOfferDTO offer, boolean update) throws Exception {

		List<OfferingChannel> offeringChannelList = new ArrayList<>();
		List<OfferingChannelTRM> offeringChannelTrmList = new ArrayList<>();

		try {

			OfferingChannel offeringChannel = null;

			for (OfferChannelDTO channel : offer.getDefinition().getOfferingChannelList()) {
				offeringChannel = new OfferingChannel();
				offeringChannel.setOfferingId(offeringId);
				offeringChannel.setChannelId((long) channel.getChannelId());
				offeringChannel.setChannelTypeId(channel.getChannelTypeId());
				offeringChannelList.add(offeringChannel);
				offeringChannelTrmList.add(DynamicOfferingMapper.instance.mapOfferingChannelToTRM(offeringChannel));
			}

			offeringChannelsService.insertOfferingChannelsList(offeringChannelList, offeringChannelTrmList);

//			for (Entry<String, Boolean> t : offer.getDefinition().getOptin().entrySet()) {
//
//				if (t.getValue() == Boolean.TRUE) {
//					offeringChannel = new OfferingChannel();
//					offeringChannel.setOfferingId(offeringId);
//					offeringChannel.setChannelId(findKeyByValue(dataBean.getChannelIds(), t.getKey()));
//					offeringChannel.setChannelTypeId(dataBean.getChannelTypes().get("OptIn"));// optin
//					offeringChannelList.add(offeringChannel);
//
//				}
//
//			}
//			
//			for (Entry<String, Boolean> t : offer.getDefinition().getOptout().entrySet()) {
//
//				if (t.getValue() == Boolean.TRUE) {
//					offeringChannel = new OfferingChannel();
//					offeringChannel.setOfferingId(offeringId);
//					offeringChannel.setChannelId(findKeyByValue(dataBean.getChannelIds(), t.getKey()));
//					offeringChannel.setChannelTypeId(dataBean.getChannelTypes().get("OptOut"));// optout
//					offeringChannelList.add(offeringChannel);
//				}
//
//			}
//
//			for (Entry<String, Boolean> t : offer.getDefinition().getRedemption().entrySet()) {
//
//				if (t.getValue() == Boolean.TRUE) {
//					offeringChannel = new OfferingChannel();
//					offeringChannel.setOfferingId(offeringId);
//					offeringChannel.setChannelId(findKeyByValue(dataBean.getChannelIds(), t.getKey()));
//					offeringChannel.setChannelTypeId(dataBean.getChannelTypes().get("Redemption"));// redemption
//					offeringChannelList.add(offeringChannel);
//				}
//
//			}
//
//			for (OfferingChannel channel : offeringChannelList) {
//				offeringChannelDao.insert(channel);
//			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Failed while inserting channels");
		}

		/*
		 * for (Entry t : offer.getDefinition().getConfirmation().entrySet()) {
		 * 
		 * if (t.getValue() == Boolean.TRUE) { offeringChannel.setChannelId(4);
		 * offeringChannel
		 * .setChannelTypeId(dataBean.getChannelTypes().get("confirmation"));//
		 * confirmation offeringChannelDao.insert(offeringChannel); }
		 * 
		 * }
		 */

	}

	private void insertPxOfferCapping(OfferPxOfferingCapping offeringCapping, boolean update) throws Exception {
		offeringCappingService.insertOfferingCapping(
				DynamicOfferingMapper.instance.mapDtoToDynOfferingCappingEntityODS(offeringCapping));
	}

	public void insertOfferConverter(PxOfferDTO offer, Integer offeringId) throws Exception {
		OfferPxDynOfferingConverter offeringConvOb = offer.getConfiguration().getOfferingConverter();

		if (offeringConvOb != null) {
			offeringConvOb.setOfferingId(offeringId);
			dynOfferingConverterService.insertDynOfferingConverter(
					DynamicOfferingMapper.instance.mapDtoToDynOfferingConverterOds(offeringConvOb));
		}
	}

}
