package com.etisalat.userauthentication.service.impl;

import javax.transaction.Transactional;
import javax.xml.bind.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.etisalat.userauthentication.model.Users;
import com.etisalat.userauthentication.repository.UserRepository;
import com.etisalat.userauthentication.service.UserAuthenticationService;

@Transactional
@Service("userService")
public class UserServiceImpl implements UserAuthenticationService {

	@Autowired
	UserRepository userRepository;
	
	@Override
	public Users findUserByName(String userName) {
		// TODO Auto-generated method stub
		return userRepository.findByUserNameIgnoreCase(userName);
	}
	
	// for Login
	@Override
	public Users findUserByNameAndPassword(String userName, String userPassword) {
		// TODO Auto-generated method stub
		Users user = findUserByName(userName);
		if(user != null && user.getUserPassword().equals(userPassword))
			return user;
		else
			return null;
	}
	
	@Override
	public void saveUser(Users user) throws ValidationException {
		Users dbUser = findUserByName(user.getUserName());
		if(dbUser == null) {
			user.setUserId(userRepository.findMaxUserId()+1);
			userRepository.save(user);
		} else {
			throw new ValidationException("User already exist");
		}
		
	}

}
