package com.etisalat.userauthentication.service;

import java.util.List;

import javax.xml.bind.ValidationException;

import com.etisalat.subscriptionoffer.model.SubscriptionOffer;
import com.etisalat.userauthentication.model.Users;

public interface UserAuthenticationService {

	Users findUserByName(String userName);

	void saveUser(Users user) throws ValidationException;

	Users findUserByNameAndPassword(String userName, String userPassword);


}
