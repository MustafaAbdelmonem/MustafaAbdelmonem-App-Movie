package com.etisalat.subscriptionparameterizedoffer.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.etisalat.common.model.CustomOfferEntity;
import com.etisalat.subscriptionparameterizedoffer.dto.OfferParamValueDTO;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "OFFERING_EMAN", schema = "TRM_STAGING_T")
@Inheritance(strategy = InheritanceType.JOINED)
public class SubscriptionParameterizedOffer extends CustomOfferEntity {

	private static final long serialVersionUID = 6580000530752046248L;
	
	@Transient
	private SubscriptionParameterizedOfferingCatalog catalog;
	
	@Transient
	private TsiProcessConfig tsiProcessConfig;
	
	@Transient
	private List<SubRequestParamTRM> subRequestParamTRM = new ArrayList<>();
	
	@Transient
	private List<SubRequestParamTDB> subRequestParamTDB = new ArrayList<>();
	
	@Transient
	private List<OfferingSubRequestParam> offeringSubRequestParam = new ArrayList<>();
	
	@Transient
	private Map<String , String> paramValMap = new HashMap<>();
	
	@Transient
	private List<OfferParamValueDTO> offerParamValue = new ArrayList<>();
	
//	public List<OfferingSubRequestParam> prepareOfferingSubRequestParam(){
//		offeringSubRequestParam.stream().forEach(item -> {
//			if(item.getRequestParamId() == null) {//paramValMap.get(param.getRequestParamName())
//				item.setRequestParamId(subRequestParamTDB.stream().filter(param -> ));
//			}
//		});
//		return offeringSubRequestParam;
//	}
	
	public SubscriptionParameterizedOffer(){}
	
	public SubscriptionParameterizedOffer(SubscriptionParameterizedOffer offer, SubscriptionParameterizedOfferingCatalog catalog ,
			List<OfferingSubRequestParam> offeringSubRequestParam , List<SubRequestParamTDB> subRequestParamTDB , List<SubRequestParamTRM> subRequestParamTRM ,
			TsiProcessConfig tsiProcessConfig){
		this.setOfferingSubRequestParam(offeringSubRequestParam);
		this.setSubRequestParamTDB(subRequestParamTDB);
		this.setSubRequestParamTRM(subRequestParamTRM);
		this.setTsiProcessConfig(tsiProcessConfig);
		
	}

}
