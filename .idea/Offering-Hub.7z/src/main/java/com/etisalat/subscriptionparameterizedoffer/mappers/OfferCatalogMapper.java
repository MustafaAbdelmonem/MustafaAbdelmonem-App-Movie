package com.etisalat.subscriptionparameterizedoffer.mappers;

import com.etisalat.subscriptionparameterizedoffer.dto.OfferingCatalogDTO;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOfferingCatalog;

public interface OfferCatalogMapper {
	
	OfferingCatalogDTO catalogToDto(SubscriptionParameterizedOfferingCatalog catalog);
	
	SubscriptionParameterizedOfferingCatalog dtoToCatalog(OfferingCatalogDTO dto);

}
