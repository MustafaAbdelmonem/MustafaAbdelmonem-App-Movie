package com.etisalat.subscriptionparameterizedoffer.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.etisalat.subscriptionparameterizedoffer.dto.SubscriptionParameterizedOfferDTO;
import com.etisalat.subscriptionparameterizedoffer.mappers.OfferParamValueMapper;
import com.etisalat.subscriptionparameterizedoffer.model.OfferingSubRequestParam;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOffer;
import com.etisalat.subscriptionparameterizedoffer.repository.IOfferingSubRequestParamRepository;
import com.etisalat.subscriptionparameterizedoffer.service.IOfferingSubRequestParamService;
import com.etisalat.subscriptionparameterizedoffer.service.ISubRequestParamTdbService;
import com.etisalat.subscriptionparameterizedoffer.service.ISubRequestParamTrmService;

@Transactional
@Service("offeringSubRequestParamService")
public class OfferingSubRequestParamServiceImpl implements IOfferingSubRequestParamService {
	
	@Autowired
	IOfferingSubRequestParamRepository offeringSubRequestParamRepository;
	
	@Autowired
	ISubRequestParamTdbService subRequestParamTdbService;
	
	@Autowired
	ISubRequestParamTrmService subRequestParamTrmService;
	
	@Override
	public void saveOfferingSubRequestParam(List<OfferingSubRequestParam> entities, SubscriptionParameterizedOfferDTO dto) {
		List<OfferingSubRequestParam> toBeSaved = new ArrayList<>();
		dto.getOfferParamValue().stream().filter(item -> !item.isDeleted()).forEach(item -> {
			item.setOfferingId(dto.getOfferingId());
			item.setDeleteFlag('N');
			toBeSaved.add(OfferParamValueMapper.instance.toOfferingSubParamEntity(item));
		});
		offeringSubRequestParamRepository.save(toBeSaved);
	}
	
	@Override
	public void updateOfferingSubRequestParam(SubscriptionParameterizedOffer offer, SubscriptionParameterizedOfferDTO dto) {
		List<OfferingSubRequestParam> toBeDeleted = offer.getOfferingSubRequestParam().stream().filter(item -> item.isDeleted()).collect(Collectors.toList());
		if(toBeDeleted != null && !toBeDeleted.isEmpty())
			offeringSubRequestParamRepository.delete(toBeDeleted);

//		List<OfferingSubRequestParam> toBeSaved = offer.getOfferingSubRequestParam().stream().filter(item -> !item.isDeleted()).collect(Collectors.toList());
		List<OfferingSubRequestParam> toBeSaved = new ArrayList<>();
		dto.getOfferParamValue().stream().filter(item -> !item.isDeleted()).forEach(item -> {
			item.setOfferingId(offer.getOfferingId());
			item.setDeleteFlag('N');
			toBeSaved.add(OfferParamValueMapper.instance.toOfferingSubParamEntity(item));
		});
		offeringSubRequestParamRepository.save(toBeSaved);
	}

	@Override
	public void delete(Integer offeringId) {
		offeringSubRequestParamRepository.deleteByOfferingId(offeringId);
	}

	@Override
	public void deleteParameters(Integer offeringId) {
		offeringSubRequestParamRepository.deleteParameters(offeringId);
	}

}
