package com.etisalat.subscriptionparameterizedoffer.repository;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTDB;

@Transactional
@Repository("subRequestParamTdbRepository")
public interface ISubRequestParamTdbRepository extends JpaRepository<SubRequestParamTDB, Integer> {

	@Query("SELECT coalesce(max(subRequestParam.requestParamId), 0) FROM SubRequestParamTDB subRequestParam")
	Integer getMaxRequestParamId();

	@Query("FROM SubRequestParamTDB subRequestParam WHERE requestParamName IN (:paramNames)")
	List<SubRequestParamTDB> findInRequestParamName(@Param("paramNames") List<String> paramNames);


}
