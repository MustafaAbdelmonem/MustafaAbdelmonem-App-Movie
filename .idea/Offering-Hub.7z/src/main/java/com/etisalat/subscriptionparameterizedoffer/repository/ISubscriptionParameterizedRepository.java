package com.etisalat.subscriptionparameterizedoffer.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOffer;

@Transactional
@Repository("subscriptionParameterizedRepository")
public interface ISubscriptionParameterizedRepository extends JpaRepository<SubscriptionParameterizedOffer, Integer> {

	@Query("SELECT subscriptionOffer , offeringCatalog , offeringSubRequestParam , subRequestParamTdb , subRequestParamTrm , tsiProcessConfig "
			+ "FROM SubscriptionParameterizedOffer subscriptionOffer, SubscriptionParameterizedOfferingCatalog offeringCatalog "
			+ ", OfferingSubRequestParam offeringSubRequestParam , SubRequestParamTDB subRequestParamTdb "
			+ ", SubRequestParamTRM subRequestParamTrm , TsiProcessConfig tsiProcessConfig "
			+ "WHERE offeringCatalog.offeringId = subscriptionOffer.offeringId "
			+ "AND offeringSubRequestParam.offeringId = subscriptionOffer.offeringId "
			+ "AND subRequestParamTdb.requestParamId = subRequestParamTrm.requestParamId "
			+ "AND subRequestParamTdb.requestParamId = offeringSubRequestParam.requestParamId "
			+ "AND subRequestParamTrm.requestParamId = offeringSubRequestParam.requestParamId "
			+ "AND ( (tsiProcessConfig.configKey = 'PersonalizedSubscription_Services_Commands' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) "
			+ "OR (tsiProcessConfig.configKey = 'PersonalizedSubscription_OnlineDB_Services' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) ) "
			+ "AND tsiProcessConfig.configGroup = :configGroup "
			+ "AND subscriptionOffer.offeringId = :offeringId "
			+ "ORDER BY subRequestParamTdb.requestParamId DESC")
	Object[] findByOfferingId(@Param("offeringId") Integer offeringId, @Param("configGroup") String configGroup);
	
	@Query("SELECT coalesce(max(subscriptionOffer.offeringId), 0) FROM SubscriptionParameterizedOffer subscriptionOffer")
	Integer findMaxOfferingId();

	void deleteByOfferingId(Integer offeringId);

	@Query("SELECT subscriptionOffer , offeringCatalog , offeringSubRequestParam , subRequestParamTdb , subRequestParamTrm , tsiProcessConfig "
			+ "FROM SubscriptionParameterizedOffer subscriptionOffer, SubscriptionParameterizedOfferingCatalog offeringCatalog "
			+ ", OfferingSubRequestParam offeringSubRequestParam , SubRequestParamTDB subRequestParamTdb "
			+ ", SubRequestParamTRM subRequestParamTrm , TsiProcessConfig tsiProcessConfig "
			+ "WHERE offeringCatalog.offeringId = subscriptionOffer.offeringId "
			+ "AND offeringSubRequestParam.offeringId = subscriptionOffer.offeringId "
			+ "AND subRequestParamTdb.requestParamId = subRequestParamTrm.requestParamId "
			+ "AND subRequestParamTdb.requestParamId = offeringSubRequestParam.requestParamId "
			+ "AND subRequestParamTrm.requestParamId = offeringSubRequestParam.requestParamId "
			+ "AND tsiProcessConfig.configGroup = :configGroup "
			+ "AND ( (tsiProcessConfig.configKey = 'PersonalizedSubscription_Services_Commands' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) "
			+ "OR (tsiProcessConfig.configKey = 'PersonalizedSubscription_OnlineDB_Services' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) ) "
			+ "ORDER BY subscriptionOffer.offeringId DESC")
	List<Object[]> listSubscriptionOffers(Pageable pageable, @Param("configGroup") String configGroup);
	
	@Query(value = "SELECT subscriptionOffer.offering_id as offering1_2_0_, offeringCatalog.offering_id as offering1_0_1_, offeringSubRequestParam.Offering_Id as Offering1_3_2_, subRequestParamTdb.Request_Param_Id as Request_1_4_3_, subRequestParamTrm.Request_Param_Id as Request_1_5_4_, tsiProcessConfig.Config_Id as Config_I1_6_5_, \r\n" + 
			"subscriptionOffer.Account_Group_Flag as Account_2_2_0_, subscriptionOffer.Bit_0 as Bit_3_2_0_, subscriptionOffer.Bit_1 as Bit_4_2_0_, subscriptionOffer.Bit_10 as Bit_5_2_0_, subscriptionOffer.Bit_11 as Bit_6_2_0_, subscriptionOffer.Bit_12 as Bit_7_2_0_, subscriptionOffer.Bit_13 as Bit_8_2_0_, subscriptionOffer.Bit_14 as Bit_9_2_0_, subscriptionOffer.Bit_15 as Bit_10_2_0_, \r\n" + 
			"subscriptionOffer.Bit_16 as Bit_11_2_0_, subscriptionOffer.Bit_17 as Bit_12_2_0_, subscriptionOffer.Bit_18 as Bit_13_2_0_, subscriptionOffer.Bit_19 as Bit_14_2_0_, subscriptionOffer.Bit_2 as Bit_15_2_0_, subscriptionOffer.Bit_20 as Bit_16_2_0_, subscriptionOffer.Bit_21 as Bit_17_2_0_, subscriptionOffer.Bit_22 as Bit_18_2_0_, \r\n" + 
			"subscriptionOffer.Bit_23 as Bit_19_2_0_, subscriptionOffer.Bit_24 as Bit_20_2_0_, subscriptionOffer.Bit_25 as Bit_21_2_0_, subscriptionOffer.Bit_26 as Bit_22_2_0_, subscriptionOffer.Bit_27 as Bit_23_2_0_, subscriptionOffer.Bit_28 as Bit_24_2_0_, subscriptionOffer.Bit_29 as Bit_25_2_0_, subscriptionOffer.Bit_3 as Bit_26_2_0_,\r\n" + 
			"subscriptionOffer.Bit_30 as Bit_27_2_0_, subscriptionOffer.Bit_31 as Bit_28_2_0_, subscriptionOffer.Bit_4 as Bit_29_2_0_, subscriptionOffer.Bit_5 as Bit_30_2_0_, subscriptionOffer.Bit_6 as Bit_31_2_0_, subscriptionOffer.Bit_7 as Bit_32_2_0_, subscriptionOffer.Bit_8 as Bit_33_2_0_, subscriptionOffer.Bit_9 as Bit_34_2_0_, \r\n" + 
			"subscriptionOffer.Bulk_Action_Flag as Bulk_Ac35_2_0_, subscriptionOffer.Campaign_Notification_Flag as Campaig36_2_0_, subscriptionOffer.Comments as Comment37_2_0_, subscriptionOffer.DWH_Entry_Date as DWH_Ent38_2_0_, subscriptionOffer.Offering_end_Dttm as Offerin39_2_0_,\r\n" + 
			"subscriptionOffer.Engagement_Flag as Engagem40_2_0_, subscriptionOffer.Interactive_Flag as Interac41_2_0_, subscriptionOffer.Offering_Bits as Offerin42_2_0_, subscriptionOffer.offering_Desc as offerin43_2_0_, subscriptionOffer.Offering_Mask as Offerin44_2_0_, subscriptionOffer.offering_name as offerin45_2_0_, \r\n" + 
			"subscriptionOffer.Offering_Type_ID as Offerin46_2_0_, subscriptionOffer.Offering_Val as Offerin47_2_0_, subscriptionOffer.Project as Project48_2_0_, subscriptionOffer.Promotion_Plan_Before_Id as Promoti49_2_0_, subscriptionOffer.SSS_Id as SSS_Id50_2_0_, subscriptionOffer.SSS_Name as SSS_Nam51_2_0_, \r\n" + 
			"subscriptionOffer.Offering_Start_Dttm as Offerin52_2_0_, subscriptionOffer.Subscription_Template_Flag as Subscri53_2_0_, offeringCatalog.Offering_Opt_In_Type_Id as Offering2_0_1_, offeringCatalog.Short_Code_Num as Short_Co3_0_1_, offeringSubRequestParam.Request_Num_Param_Val as Request_2_3_2_, \r\n" + 
			"offeringSubRequestParam.Request_Param_Id as Request_3_3_2_, offeringSubRequestParam.Request_Txt_Param_Val as Request_4_3_2_, subRequestParamTdb.Request_Param_Name as Request_2_4_3_, subRequestParamTdb.Subscription_Template_Flag as Subscrip3_4_3_, subRequestParamTrm.Request_Param_Name as Request_2_5_4_, \r\n" + 
			"subRequestParamTrm.Subscription_Template_Flag as Subscrip3_5_4_, tsiProcessConfig.Config_Group as Config_G2_6_5_, tsiProcessConfig.Config_Key as Config_K3_6_5_, tsiProcessConfig.Config_Value as Config_V4_6_5_  "
			+ "FROM TRM_STAGING_T.offering_eman subscriptionOffer "
			+ "INNER JOIN TRM_STAGING_T.Offering_Catalog_EMAN offeringCatalog ON offeringCatalog.offering_Id = subscriptionOffer.offering_Id "
			+ "INNER JOIN TRM_STAGING_T.Offering_Sub_Request_Param_EMAN offeringSubRequestParam ON offeringSubRequestParam.offering_Id = subscriptionOffer.offering_Id "
			+ "INNER JOIN TRM_STAGING_T.Sub_Request_Param_TDB_EMAN subRequestParamTdb ON subRequestParamTdb.request_Param_Id = offeringSubRequestParam.request_Param_Id "
			+ "INNER JOIN TRM_STAGING_T.Sub_Request_Param_TRM_EMAN subRequestParamTrm ON subRequestParamTrm.request_Param_Id = offeringSubRequestParam.request_Param_Id "
			+ "INNER JOIN TRM_STAGING_T.Tsi_Process_Config_EMAN tsiProcessConfig ON ( (tsiProcessConfig.config_Key = 'PersonalizedSubscription_Services_Commands' AND (tsiProcessConfig.config_Value LIKE '%;'||subscriptionOffer.SSS_Name||'=%' OR tsiProcessConfig.config_Value LIKE subscriptionOffer.SSS_Name||'=%')) "
			+ "OR (tsiProcessConfig.config_Key = 'PersonalizedSubscription_OnlineDB_Services' AND (tsiProcessConfig.config_Value LIKE  '%;'||subscriptionOffer.SSS_Name||'=%' OR tsiProcessConfig.config_Value LIKE subscriptionOffer.SSS_Name||'=%')) ) "
			+ "WHERE subRequestParamTdb.request_Param_Id = subRequestParamTrm.request_Param_Id "
			+ "AND tsiProcessConfig.config_Group = :configGroup "
			+ "AND subscriptionOffer.offering_Id = :offeringId ", nativeQuery=true)
	Object[] findByOfferingIdUsingSql(@Param("offeringId") Integer offeringId, @Param("configGroup") String configGroup);

	@Query("SELECT coalesce(COUNT(*), 0) "
			+ "FROM SubscriptionParameterizedOffer subscriptionOffer , TsiProcessConfig tsiProcessConfig "
			+ "WHERE subscriptionOffer.offeringId IN (SELECT offeringCatalog.offeringId FROM SubscriptionParameterizedOfferingCatalog offeringCatalog) "
			+ "AND subscriptionOffer.offeringId IN (SELECT offeringSubRequestParam.offeringId FROM OfferingSubRequestParam offeringSubRequestParam) "
			+ "AND tsiProcessConfig.configGroup = :configGroup "
			+ "AND ( (tsiProcessConfig.configKey = 'PersonalizedSubscription_Services_Commands' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) "
			+ "OR (tsiProcessConfig.configKey = 'PersonalizedSubscription_OnlineDB_Services' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) )")
	int getTotalCount(@Param("configGroup") String configGroup);

	List<SubscriptionParameterizedOffer> findByOfferingNameOrOfferingDesc(String offeringName, String offeringDesc);

	@Transactional
	@Modifying
	@Query("UPDATE SubscriptionParameterizedOffer SET deleteFlag = 'Y' WHERE offering_id =:offeringId")
	void deleteSubParamOffer(@Param("offeringId") Integer offeringId);

	
//	boolean isOfferingNameOrDescDuplicated(String offeringName);

}
