package com.etisalat.subscriptionparameterizedoffer.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.etisalat.subscriptionparameterizedoffer.model.TsiProcessConfig;

@Transactional
@Repository("tsiProcessConfigRepository")
public interface ITsiProcessConfigRepository extends JpaRepository<TsiProcessConfig, Integer> {

	TsiProcessConfig findByConfigKey(String personalizedsubscriptionServicesCommands);

	TsiProcessConfig findByConfigKeyAndConfigGroup(String personalizedsubscriptionOnlinedbServices,
			String personalizedSubscriptionGroup);

}
