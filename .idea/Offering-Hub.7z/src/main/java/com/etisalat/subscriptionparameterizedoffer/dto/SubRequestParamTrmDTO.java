package com.etisalat.subscriptionparameterizedoffer.dto;

import lombok.Data;

@Data
public class SubRequestParamTrmDTO {

	private Integer requestParamId;
	private String requestParamName;
	private Character subscriptionTemplateFlag;
}
