package com.etisalat.subscriptionparameterizedoffer.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "TSI_PROCESS_CONFIG_EMAN", schema = "TRM_STAGING_T")
public class TsiProcessConfig implements Serializable {

	private static final long serialVersionUID = 1462308616747240945L;
	
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "Config_Id")
	private Integer configId;
	
	@NotNull
	@Column(name = "Config_Group")
	private String configGroup;
	
	@NotNull
	@Column(name = "Config_Key")
	private String configKey;
	
	@NotNull
	@Column(name = "Config_Value")
	private String configValue;
	
	@Transient
	private boolean batchDB;
	
	@Transient
	private String commandTxt;

}
