package com.etisalat.subscriptionparameterizedoffer.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.etisalat.common.model.CustomOfferEntity;
import com.etisalat.subscriptionparameterizedoffer.dto.OfferParamValueDTO;

import lombok.Data;

@Entity
@Data
@Table(name = "OFFERING_EMAN", schema = "TRM_STAGING_T")
public class SubscriptionParameterizedOfferVDB extends CustomOfferEntity {

	private static final long serialVersionUID = -7278290828250885934L;
	
	@Transient
	private SubscriptionParameterizedOfferingCatalogVDB catalog;
	
	@Transient
	private TsiProcessConfig tsiProcessConfig;
	
	@Transient
	private List<SubRequestParamTRM> subRequestParamTRM = new ArrayList<>();
	
	@Transient
	private List<SubRequestParamVDB> subRequestParamTDB = new ArrayList<>();
	
	@Transient
	private List<OfferingSubRequestParamVDB> offeringSubRequestParam = new ArrayList<>();
	
	@Transient
	private Map<String , String> paramValMap = new HashMap<>();
	
	@Transient
	private List<OfferParamValueDTO> offerParamValue = new ArrayList<>();
	
}
