package com.etisalat.subscriptionparameterizedoffer.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.ivroffer.model.OfferingVDB;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOfferVDB;

@Transactional
@Repository("VDBSubParamRepository")
public interface VDBISubscriptionParameterizedRepository extends JpaRepository<SubscriptionParameterizedOfferVDB, Long> {


	@Query("SELECT COALESCE(MAX(subscriptionOffer.offeringId), 0) FROM SubscriptionParameterizedOfferVDB subscriptionOffer")
	Integer findMaxOfferingId();
	
	@Query("SELECT subscriptionOffer , offeringCatalog , offeringSubRequestParam , subRequestParamVdb , subRequestParamTrm , tsiProcessConfig "
			+ "FROM SubscriptionParameterizedOfferVDB subscriptionOffer, SubscriptionParameterizedOfferingCatalogVDB offeringCatalog "
			+ ", OfferingSubRequestParamVDB offeringSubRequestParam , SubRequestParamVDB subRequestParamVdb "
			+ ", SubRequestParamTRM subRequestParamTrm , TsiProcessConfig tsiProcessConfig "
			+ "WHERE offeringCatalog.offeringId = subscriptionOffer.offeringId "
			+ "AND offeringSubRequestParam.offeringId = subscriptionOffer.offeringId "
			+ "AND subRequestParamVdb.requestParamId = subRequestParamTrm.requestParamId "
			+ "AND subRequestParamVdb.requestParamId = offeringSubRequestParam.requestParamId "
			+ "AND subRequestParamTrm.requestParamId = offeringSubRequestParam.requestParamId "
			+ "AND ( (tsiProcessConfig.configKey = 'PersonalizedSubscription_Services_Commands' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) "
			+ "OR (tsiProcessConfig.configKey = 'PersonalizedSubscription_OnlineDB_Services' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) ) "
			+ "AND tsiProcessConfig.configGroup = :configGroup "
			+ "AND subscriptionOffer.offeringId = :offeringId "
			+ "AND subscriptionOffer.deleteFlag <> 'Y'"
			+ "AND (subscriptionOffer.accountGroupFlag <> 'O' OR subscriptionOffer.accountGroupFlag IS NULL)"
			+ "ORDER BY subRequestParamVdb.requestParamId DESC")
	Object[] findByOfferingId(@Param("offeringId") Integer offeringId, @Param("configGroup") String configGroup);

	@Query("SELECT coalesce(COUNT(*), 0) "
			+ "FROM SubscriptionParameterizedOfferVDB subscriptionOffer , TsiProcessConfig tsiProcessConfig "
			+ "WHERE subscriptionOffer.deleteFlag <> 'Y' AND (subscriptionOffer.accountGroupFlag <> 'O' OR subscriptionOffer.accountGroupFlag IS NULL)"
			+ "AND subscriptionOffer.offeringId IN (SELECT offeringCatalog.offeringId FROM SubscriptionParameterizedOfferingCatalogVDB offeringCatalog) "
			+ "AND subscriptionOffer.offeringId IN (SELECT offeringSubRequestParam.offeringId FROM OfferingSubRequestParamVDB offeringSubRequestParam) "
			+ "AND tsiProcessConfig.configGroup = :configGroup "
			+ "AND ( (tsiProcessConfig.configKey = 'PersonalizedSubscription_Services_Commands' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) "
			+ "OR (tsiProcessConfig.configKey = 'PersonalizedSubscription_OnlineDB_Services' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) )")
	int getTotalCount(@Param("configGroup") String configGroup);

	List<OfferingVDB> findByOfferingNameOrOfferingDesc(String offeringName, String offeringDesc);
	
	@Query("SELECT subscriptionOffer , offeringCatalog , offeringSubRequestParam , subRequestParamVdb , subRequestParamTrm , tsiProcessConfig "
			+ "FROM SubscriptionParameterizedOfferVDB subscriptionOffer, SubscriptionParameterizedOfferingCatalogVDB offeringCatalog "
			+ ", OfferingSubRequestParamVDB offeringSubRequestParam , SubRequestParamVDB subRequestParamVdb "
			+ ", SubRequestParamTRM subRequestParamTrm , TsiProcessConfig tsiProcessConfig "
			+ "WHERE subscriptionOffer.deleteFlag <> 'Y' AND (subscriptionOffer.accountGroupFlag <> 'O' OR subscriptionOffer.accountGroupFlag IS NULL) "
			+ "AND offeringCatalog.offeringId = subscriptionOffer.offeringId "
			+ "AND offeringSubRequestParam.offeringId = subscriptionOffer.offeringId "
			+ "AND subRequestParamVdb.requestParamId = subRequestParamTrm.requestParamId "
			+ "AND subRequestParamVdb.requestParamId = offeringSubRequestParam.requestParamId "
			+ "AND subRequestParamTrm.requestParamId = offeringSubRequestParam.requestParamId "
			+ "AND tsiProcessConfig.configGroup = :configGroup "
			+ "AND ( (tsiProcessConfig.configKey = 'PersonalizedSubscription_Services_Commands' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) "
			+ "OR (tsiProcessConfig.configKey = 'PersonalizedSubscription_OnlineDB_Services' AND (tsiProcessConfig.configValue LIKE CONCAT('%;',subscriptionOffer.serviceName,'=%') OR tsiProcessConfig.configValue LIKE CONCAT(subscriptionOffer.serviceName,'=%'))) ) "
			+ "ORDER BY subscriptionOffer.offeringId DESC")
	List<Object[]> listSubscriptionOffersVDB(Pageable pageable, @Param("configGroup") String configGroup);

}
