package com.etisalat.subscriptionparameterizedoffer.service;

import java.util.List;

import com.etisalat.subscriptionparameterizedoffer.dto.SubscriptionParameterizedOfferDTO;
import com.etisalat.subscriptionparameterizedoffer.model.OfferingSubRequestParam;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOffer;

public interface IOfferingSubRequestParamService {

	void saveOfferingSubRequestParam(List<OfferingSubRequestParam> list, SubscriptionParameterizedOfferDTO dto);

	void updateOfferingSubRequestParam(SubscriptionParameterizedOffer offer, SubscriptionParameterizedOfferDTO dto);

	void delete(Integer offeringId);

	void deleteParameters(Integer offeringId);

}
