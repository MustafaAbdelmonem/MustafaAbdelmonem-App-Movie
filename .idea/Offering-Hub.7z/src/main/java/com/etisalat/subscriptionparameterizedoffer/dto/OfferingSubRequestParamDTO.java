package com.etisalat.subscriptionparameterizedoffer.dto;

import lombok.Data;

@Data
public class OfferingSubRequestParamDTO {

	private Integer offeringId;
	private Integer requestParamId;
	private Integer requestNumParamVal;
	private String requestTxtParamVal;
	private boolean deleted;
	private char deleteFlag;
}
