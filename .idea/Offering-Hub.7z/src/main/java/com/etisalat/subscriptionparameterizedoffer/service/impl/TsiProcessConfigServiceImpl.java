package com.etisalat.subscriptionparameterizedoffer.service.impl;

import java.util.Arrays;

import javax.transaction.Transactional;
import javax.xml.bind.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.etisalat.common.constant.EtisalatConstant;
import com.etisalat.subscriptionparameterizedoffer.model.TsiProcessConfig;
import com.etisalat.subscriptionparameterizedoffer.repository.ITsiProcessConfigRepository;
import com.etisalat.subscriptionparameterizedoffer.service.ITsiProcessConfigService;

@Transactional
@Service("tsiProcessConfigService")
public class TsiProcessConfigServiceImpl implements ITsiProcessConfigService {
	
	@Autowired
	ITsiProcessConfigRepository tsiProcessConfigRepository;
	
	@Override
	public void saveOrUpdateTsiProcessConfig(boolean batchDB, String serviceName, String commandTxt) throws ValidationException {
		TsiProcessConfig tsiProcessConfig = batchDB ? tsiProcessConfigRepository.findByConfigKeyAndConfigGroup(EtisalatConstant.PERSONALIZEDSUBSCRIPTION_SERVICES_COMMANDS, EtisalatConstant.PERSONALIZED_SUBSCRIPTION_GROUP)
				: tsiProcessConfigRepository.findByConfigKeyAndConfigGroup(EtisalatConstant.PERSONALIZEDSUBSCRIPTION_ONLINEDB_SERVICES, EtisalatConstant.PERSONALIZED_SUBSCRIPTION_GROUP);
		if(tsiProcessConfig != null) {
			boolean isNewConfig = true;
			if(batchDB) {
				for (String smsParameter : tsiProcessConfig.getConfigValue().split(";")) {
					if(smsParameter.split("=")[0].trim().equals(serviceName)) {
						isNewConfig = false;
						if(smsParameter.split("=").length >= 2) 
							smsParameter.split("=")[1] = commandTxt;
						else
							smsParameter.split("=")[1] = "";
						break;
					}
				}
			} else {
//				if(!Arrays.asList(tsiProcessConfig.getConfigValue().split(";")).contains(serviceName)) {
//					tsiProcessConfig.setConfigValue(tsiProcessConfig.getConfigValue() + ";" + serviceName);
//				}
				if(Arrays.asList(tsiProcessConfig.getConfigValue().split(";")).contains(serviceName)) {
					isNewConfig = false;
				}
			}
			
			if(isNewConfig) {
				String newConfig = batchDB ? tsiProcessConfig.getConfigValue() + ";" + serviceName + "=" + commandTxt : tsiProcessConfig.getConfigValue() + ";" + serviceName;
				tsiProcessConfig.setConfigValue(newConfig);
			}
			tsiProcessConfigRepository.save(tsiProcessConfig);
		} else {
			throw new ValidationException("TsiProcessConfig must not be null !");
		}
	}

}
