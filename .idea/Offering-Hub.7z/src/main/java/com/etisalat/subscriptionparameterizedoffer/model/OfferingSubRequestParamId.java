package com.etisalat.subscriptionparameterizedoffer.model;

import java.io.Serializable;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class OfferingSubRequestParamId implements Serializable {
	
	private Integer offeringId;
	private Integer requestParamId;
}
