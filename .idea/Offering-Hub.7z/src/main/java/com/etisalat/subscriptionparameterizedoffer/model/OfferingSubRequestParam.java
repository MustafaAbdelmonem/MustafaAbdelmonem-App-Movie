package com.etisalat.subscriptionparameterizedoffer.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@IdClass(OfferingSubRequestParamId.class)
@Table(name = "OFFERING_SUB_REQUEST_PARAM_EMAN", schema = "TRM_STAGING_T", 
	uniqueConstraints=@UniqueConstraint(columnNames= {"Offering_Id" , "Request_Param_Id"}))
public class OfferingSubRequestParam implements Serializable {
	
	private static final long serialVersionUID = -9182860549395313396L;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "Offering_Id")
	private Integer offeringId;
	
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "Request_Param_Id")
	private Integer requestParamId;
	
	@Column(name = "Request_Num_Param_Val")
	private Integer requestNumParamVal;
	
	@NotNull
	@Column(name = "Request_Txt_Param_Val")
	private String requestTxtParamVal;
	
	@Transient
	private boolean deleted;
	
	@Column(name = "Delete_Flag", columnDefinition = "char(1) default N")
	private char deleteFlag = 'N';
	
}
