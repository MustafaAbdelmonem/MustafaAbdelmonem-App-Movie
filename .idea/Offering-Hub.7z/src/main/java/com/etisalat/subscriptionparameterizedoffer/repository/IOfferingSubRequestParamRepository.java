package com.etisalat.subscriptionparameterizedoffer.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.etisalat.subscriptionparameterizedoffer.model.OfferingSubRequestParam;

@Transactional
@Repository("offeringSubRequestParamRepository")
public interface IOfferingSubRequestParamRepository extends JpaRepository<OfferingSubRequestParam, Integer> {

	@Transactional
	@Modifying
	@Query("DELETE FROM OfferingSubRequestParam WHERE offering_id =:offeringId")
	void deleteByOfferingId(@Param("offeringId") Integer offeringId);

	@Transactional
	@Modifying
	@Query("UPDATE OfferingSubRequestParam SET deleteFlag = 'Y' WHERE offering_id =:offeringId")
	void deleteParameters(@Param("offeringId") Integer offeringId);

}
