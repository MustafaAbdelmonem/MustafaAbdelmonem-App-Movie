package com.etisalat.subscriptionparameterizedoffer.model;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "SUB_REQUEST_PARAM_TRM_EMAN", schema = "TRM_STAGING_T")
public class SubRequestParamTRM implements Serializable {

	private static final long serialVersionUID = -5275642525767047218L;
	
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "Request_Param_Id")
	private Integer requestParamId;
	
	@NotNull
	@Column(name="Request_Param_Name")
	private String requestParamName;
	
	@NotNull
	@Column(name="Subscription_Template_Flag", columnDefinition = "char(1) default Y", length = 1)
	private Character subscriptionTemplateFlag = 'Y';

}
