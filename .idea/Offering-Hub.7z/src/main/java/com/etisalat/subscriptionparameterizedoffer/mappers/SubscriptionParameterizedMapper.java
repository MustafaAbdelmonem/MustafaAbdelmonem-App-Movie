package com.etisalat.subscriptionparameterizedoffer.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.etisalat.subscriptionparameterizedoffer.dto.SubscriptionParameterizedOfferDTO;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOffer;
import com.etisalat.subscriptionparameterizedoffer.model.SubscriptionParameterizedOfferVDB;

@Mapper
public interface SubscriptionParameterizedMapper {

	SubscriptionParameterizedMapper instance = Mappers.getMapper(SubscriptionParameterizedMapper.class);

	SubscriptionParameterizedOfferDTO subscriptionOfferToDto(SubscriptionParameterizedOffer offer);
	
	SubscriptionParameterizedOfferDTO subscriptionOfferToDtoUsingVDB(SubscriptionParameterizedOfferVDB offer);

	SubscriptionParameterizedOffer dtoToSubscriptionOffer(SubscriptionParameterizedOfferDTO dto);
	
}
