package com.etisalat.subscriptionparameterizedoffer.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.etisalat.subscriptionparameterizedoffer.dto.OfferParamValueDTO;
import com.etisalat.subscriptionparameterizedoffer.dto.OfferingSubRequestParamDTO;
import com.etisalat.subscriptionparameterizedoffer.dto.SubRequestParamTdbDTO;
import com.etisalat.subscriptionparameterizedoffer.model.OfferingSubRequestParam;
import com.etisalat.subscriptionparameterizedoffer.model.OfferingSubRequestParamVDB;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTDB;
import com.etisalat.subscriptionparameterizedoffer.model.SubRequestParamTRM;

@Mapper
public interface OfferParamValueMapper {

	OfferParamValueMapper instance = Mappers.getMapper(OfferParamValueMapper.class);
	
	SubRequestParamTDB toTdbEntity(OfferParamValueDTO dto);
	
	SubRequestParamTRM toTrmEntity(OfferParamValueDTO dto);
	
	OfferingSubRequestParam toOfferingSubParamEntity(OfferParamValueDTO dto);
	
	OfferParamValueDTO tdbToOfferingSubParamDTO(SubRequestParamTdbDTO dto);
	
	OfferParamValueDTO valuesDtoToOfferParamValueDTO(OfferingSubRequestParamDTO dto);
	
	OfferParamValueDTO valuesToOfferParamValueDTO(OfferingSubRequestParam entity);
	
	OfferParamValueDTO valuesToOfferParamValueDTOUsingVDB(OfferingSubRequestParamVDB entity);
	
}
