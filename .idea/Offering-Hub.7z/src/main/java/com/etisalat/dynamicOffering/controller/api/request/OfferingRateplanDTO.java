package com.etisalat.dynamicOffering.controller.api.request;

import java.util.Date;

import lombok.Data;

@Data
public class OfferingRateplanDTO {
	
	private Integer offeringId;
	private Integer ratePlanProductId;
	private Date startDate;
	private Date endDate;
	
}
