package com.etisalat.dynamicOffering.models.old;

import com.etisalat.dynamicOffering.enums.Type;

public class Node {

	
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 483480253905611582L;

	private Type type;

	private Integer id;

	private String name;

	public Node(int id, String name, Type type) {

		this.id = id;
		this.name = name;
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	// Eclipse Generated hashCode and equals
	@Override
	public int hashCode() {
		return id;
	}

	@Override
	public String toString() {
		return "{" + id + "," + name + "}";
	}

	public int compareTo(Node node) {
		return this.getName().compareTo(node.getName());
	}
}
