package com.etisalat.dynamicOffering.models.old;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

@Data
public class ContradictionR implements Serializable {

	List<Integer> contradictionOfferDetailsIds;
	
}
