package com.etisalat.dynamicOffering.controller.api.request;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class OfferDefinitionDTO {

	private String offerName;
	private boolean online;
	private boolean optinFeesFlag;
	private Float fees;
	private List<String> categories = new ArrayList<>();
	
	// not being used anymore, use pxServiceCategory instead
	private String selectedCategory;
	private String selectedCampaignType;

	private OfferPxServiceCategoryDTO pxServiceCategory;

	private String ussdShortDescription;
	private String ussdLongDescription;

	private String mediaArabicDescription;
	private String mediaEnglishDescription;

	// optin : Map<string , boolean>;
	// optout : Map<string , boolean>;
	// redemption : Map<string , boolean>;
	// confirmation : Map<string , boolean>;

	private List<OfferChannelDTO> offeringChannelList = new ArrayList<>();;

	private boolean pullOffer;
	private boolean informativeOffer;
	private String commercialEnglishServiceDescription;
	private String commercialArabicServiceDescription;

	private OfferPxShortcode pxShortCode;
	private String optinScriptAr;
	private String optinScriptEn;

	private OfferPxOfferingTemplates pxOfferingTemplates;

	private Integer ratePlan;
	
	//TODO
//	private unSelectedTree : any ;//TreeNode = new TreeNode();
//	private unSelectedNodes : any[]; //TreeNode[] = [];

//	private selectedTree : any; //TreeNode = new TreeNode();
//	private selectedNodes : any[]; //TreeNode[] = [];;

	private static String OTHER = "other";

	private String platformEnglishDescription;
	private String platformArabicDescription;
	
	private String platformId;
	private String productName;
	private String operationId;
	
	
	private OfferPxOfferingOffval pxOfferingOffval;

	private String bundleType; 
}
