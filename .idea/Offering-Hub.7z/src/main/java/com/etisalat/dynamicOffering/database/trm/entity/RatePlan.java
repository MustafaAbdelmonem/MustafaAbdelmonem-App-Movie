package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Entity
@Table(name = "RATE_PLAN")
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class RatePlan implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "Rate_Plan_Product_Id")
	Integer ratePlanProductId;
//
//	@Column(name = "Rate_Plan_Cd")
//	String ratePlanCd;

	@Column(name = "Rate_Plan_Desc")
	String ratePlanDesc;

	@Column(name = "Service_Class_Cd")
	String serviceClassCd;

//	@Column(name = "Service_Class_Desc")
//	String serviceClassDesc;

//	@Column(name = "Rate_Plan_Category")
//	String ratePlanCategory;
//
	@Column(name = "Rate_Plan_Type")
	String ratePlanType;
	
	@Column(name = "Rate_Plan_Group")
	String ratePlanGroup;

//	@Column(name = "RP_Short_Desc")
//	String rpShortDesc;
//	
//	@Column(name = "Life_Cycle_Flag")
//	Integer lifeCycleFlag;
//
//	@Column(name = "Special_Handling_Flag")
//	Integer specialHandlingFlag;
//	
//	@Column(name = "Rate_Plan_Sub_Group")
//	String ratePlanSubGroup;
//
//	@Column(name = "Rate_Plan_Class")
//	String ratePlanClass;

//	@Column(name = "Budget_Group1")
//	String budgetGroup1;
//
//	@Column(name = "Budget_Group2")
//	String budgetGroup2;
//
//	@Column(name = "Budget_Group3")
//	String budgetGroup3;
//
//	@Column(name = "Budget_Group4")
//	String budgetGroup4;
//	
//	@Column(name = "Int_Group_1")
//	String intGroup1;
//
//	@Column(name = "Int_Group_2")
//	String intGroup2;
//
//	@Column(name = "Tax_Flag")
//	String taxFlag;
//	
//	@Column(name = "Temp_Blocking_Offering_Id")
//	Integer tempBlockingOfferingId;
//
//	@Column(name = "PAG_Eligibility_Flag")
//	Short pagEligibilityFlag;
//
//	@Column(name = "Default_More_Flag")
//	String defaultMoreFlag;
//
//	@Column(name = "Dashboard_Category")
//	String dashboardCategory;
//
//	@Column(name = "GeoMarketingCategory")
//	String geoMarketingCategory;
//
//	@Column(name = "SIS_Rate_Plan_Staff_Dist_Group")
//	String sisRatePlanStaffDistGroup;
//
//	@Column(name = "SIS_Rate_Plan_Staff_Ret_Group")
//	String sisRatePlanStaffRetGroup;
//
//	@Column(name = "CSS_Rate_Plan_ID")
//	Integer cssRatePlanId;
//	
//	@Column(name = "BOBR_Type")
//	String bobrType;

}
