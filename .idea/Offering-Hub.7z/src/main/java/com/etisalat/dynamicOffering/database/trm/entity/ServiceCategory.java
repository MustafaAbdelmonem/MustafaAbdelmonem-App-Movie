package com.etisalat.dynamicOffering.database.trm.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "PX_SERVICE_CATEGORY")
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class ServiceCategory {

	@Id
	@Column(name = "CATEGORY_ID")
	String categoryId;

	@Column(name = "parentID")
	String parentID;

	@Column(name = "NAME")
	String name;

	@Column(name = "ARABIC_NAME")
	String arabicName;

	@Column(name = "CAT_HIDDEN_FLAG")
	String catHiddenFlag;

	@Column(name = "CATEGORY_PRIORITY")
	Integer categoryPriority;

	@Column(name = "DWH_ENTRY_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	Date dwhEntryDate;
}
