package com.etisalat.dynamicOffering.controller.api.request;

import java.util.List;

import com.etisalat.dynamicOffering.enums.TrafficCase;

import lombok.Data;

@Data
public class OfferDynBonusDTO {

	private TrafficCase bonusType; // unit or pool or mixed
	private List<OfferTierDTO> tiers;
	private boolean dynBonusCompleted;
	
	private List<OfferPxDynOfferingParametersDTO> pxDynOfferingParametersList;

}
