package com.etisalat.dynamicOffering.models.old;

import lombok.Data;

@Data
public class ShortCode {
	
	private Integer shortCode;
	private Integer serviceId;
	private String serviceName;
	
}
