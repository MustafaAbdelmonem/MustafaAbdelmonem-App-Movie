package com.etisalat.dynamicOffering.database.trm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.trm.entity.DynOfferingConverterTRM;


public interface DynOfferingConverterRepositoryTrm extends JpaRepository<DynOfferingConverterTRM, Integer> {

}