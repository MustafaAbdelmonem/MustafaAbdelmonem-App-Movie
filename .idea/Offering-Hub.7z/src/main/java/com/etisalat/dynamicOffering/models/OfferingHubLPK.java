package com.etisalat.dynamicOffering.models;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingTemplates;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingVal;
import com.etisalat.dynamicOffering.database.trm.entity.ServiceCategory;
import com.etisalat.dynamicOffering.database.trm.entity.Shortcode;

import lombok.Data;
@Data
public class OfferingHubLPK  {

	
	private List <OfferingVal> pxOfferingOffval = new ArrayList<>();
	
	private Set<Shortcode>	 pxShortCode = new HashSet<Shortcode>(); 
	
	private OfferingTemplates offeringTemplates;
	
	private List<Properties>  traffiCades = new ArrayList<>();
	
	private List<ServiceCategory> pxServiceCategory = new ArrayList<>();
	
	
//	private List <OfferTypes> offerTypes;	
//	
//
//	private List<ServiceCategory> serviceCategory;
//	
//
//	private Info info;
//	@Data
//	public class OfferTypes{
//		private Integer serviceId;
//		
//		private Integer shortCode;
//		
//		private String parameterValue;
//		
//		private Integer offeringVal;
//
//		private Integer templateId;
//
//		private String templateName;
//
//		private String parameterName;
//
//		private String offerType;
//
//		private String serviceName;
//		
//		
//	}
//
//	@Data
//	public class Info {
// 	
//	private String operationId;
//
//	private String platformId;
//
//	private String productName;
//
//	private String platformArDesc;
//
//	private String platformEnDesc;
//	
//	
//	}

	
	
}
