package com.etisalat.dynamicOffering.models.old;

import java.io.Serializable;

import lombok.Data;

@Data
public class Offer implements Serializable {

	private Integer offerId;
	private Definition definition;
	private Configuration configuration;
	private Contradiction contradiction;

}
