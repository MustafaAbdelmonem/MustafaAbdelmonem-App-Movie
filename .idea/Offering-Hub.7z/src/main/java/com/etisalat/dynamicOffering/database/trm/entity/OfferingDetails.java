package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name = "PX_OFFERING_DETAILS")
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class OfferingDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_ID")
	private Integer offeringId;
	
	@Size(max = 50)
	@Column(name = "OFFERING_NAME")
	private String offeringName;
	
	@Column(name = "OFFERING_START_DT")
	@Temporal(TemporalType.DATE)
	private Date offeringStartDt;
	
	@Column(name = "OFFERING_END_DT")
	@Temporal(TemporalType.DATE)
	private Date offeringEndDt;
	
	@Column(name = "OFFERING_DURATION")
	private Integer offeringDuration;
	
	@Column(name = "OPT_IN_OFFERING_DURATION")
	private Integer optInOfferingDuration;
	
	@Column(name = "SSS_ID")
	private Integer sssId;
	
	@Size(max = 100)
	@Column(name = "SSS_NAME")
	private String sssName;
	
	@Size(max = 10)
	@Column(name = "SHORT_CODE_NUM")
	private String shortCodeNum;
	
	@Size(max = 255)
	@Column(name = "OFFERING_CATEGORY")
	private String offeringCategory;
	
	@Column(name = "OFFER_PRIORITY")
	private Integer offerPriority;
	
	@Size(max = 100)
	@Column(name = "OFFERING_BITS")
	private String offeringBits;
	
	@Column(name = "OFFERING_VAL")
	private Integer offeringVal;
	
	@Column(name = "OFFERING_MASK")
	private Integer offeringMask;
	
	@Column(name = "IN_OFFER_TYPE_ID")
	private Integer inOfferTypeId;
	
	@Size(max = 255)
	@Column(name = "OFFERING_ENG_DESC")
	private String offeringEngDesc;
	
	@Size(max = 255)
	@Column(name = "OFFERING_AR_DESC")
	private String offeringArDesc;
	
	@Size(max = 3)
	@Column(name = "OFFERING_LINE_TYPE")
	private String offeringLineType;
	
	@Size(max = 10)
	@Column(name = "OFFER_HIDDEN_FLAG")
	private String offerHiddenFlag;
	
	@Column(name = "IS_INFORMATIVE")
	private Integer isInformative;
	
	@Size(max = 1000)
	@Column(name = "OFFERING_SHORT_DESC")
	private String offeringShortDesc;
	
	@Size(max = 1000)
	@Column(name = "OFFERING_LONG_DESC")
	private String offeringLongDesc;
	
	@Column(name = "Online_Flag")
	private Integer onlineFlag;
	
	@Column(name = "OFFER_OPTIN_FEES")
	private Float offerOptinFees;
	
	@Column(name = "REDEMPTION_WINDOW")
	private Integer redemptionWindow;
	
	@Column(name = "PROMOTION_PLAN_ID")
	private Integer promotionPlanId;
	
	@Column(name = "PROMOTION_PLAN_DURATION")
	private Integer promotionPlanDuration;
	
	@Column(name = "PROMOTION_PLAN_START_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date promotionPlanStartDt;
	
	@Column(name = "PROMOTION_PLAN_END_DT")
	@Temporal(TemporalType.TIMESTAMP)
	private Date promotionPlanEndDt;
	
	@Column(name = "ACCUMULATION_FLAG")
	private Integer accumulationFlag;

	@Column(name = "BONUS_VALIDITY")
	private Integer bonusValidity;
	
	@Column(name = "SUB_SEND_SMS_FLAG")
	private Integer subSendSmsFlag;
	
	@Column(name = "DWH_ENTRY_DATE")
	@Temporal(TemporalType.DATE)
	private Date DWHEntryDate;
	
	@Column(name = "GRANTING_MECHANISM")
	private Integer grantingMechanism;
	
	@Column(name = "MULTIPLE_THRESHOLD_FLAG")
	private Integer multipleThresholdFlag;
	
	@Size(max = 100)
	@Column(name = "COMMERCIAL_SERVICE_ENDESC")
	private String commercialServiceDescEN;
	
	@Size(max = 100)
	@Column(name = "COMMERCIAL_SERVICE_ARDESC")
	private String commercialServiceDescAR;
	
	@Size(max = 100)
	@Column(name = "RESOURCE_TYPE")
	private String resourceType;
	
	@Column(name = "ACCUMLATION_DURATION")
	private Integer accumlationDuration;
	
	@Column(name = "BONUS_TYPE_FLAG")
	private Integer bonusTypeFlag;
	
	@Size(max = 1000)
	@Column(name = "OPTIN_SCRIPT_AR")
	private String optinScriptAr;
	
	@Size(max = 1000)
	@Column(name = "OPTIN_SCRIPT_EN")
	private String optinScriptEn;
	
	@Column(name = "RATE_PLAN_FLAG")
	private Integer ratePlanFlag;
	
	@Size(max = 2)
	@Column(name = "OFFERING_FLAG")
	private String offeringFlag;
	
	@Column(name = "VALID_RENEWAL_PERIOD")
	private Integer validRenewalPeriod;
	
	@Size(max = 255)
	@Column(name = "OPERATION_ID")
	private String operationId;
	
	@Size(max = 255)
	@Column(name = "PLATFORM_ID")
	private String platformId;
	
	@Size(max = 255)
	@Column(name = "PRODUCT_NAME")
	private String productName;
	
	@Size(max = 255)
	@Column(name = "PLATFORM_AR_DESC")
	private String platformArDesc;
	
	@Size(max = 255)
	@Column(name = "PLATFORM_EN_DESC")
	private String platformEnDesc;
	
}
