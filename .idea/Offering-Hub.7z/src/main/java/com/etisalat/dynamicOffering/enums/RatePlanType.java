package com.etisalat.dynamicOffering.enums;

public enum RatePlanType {
	CAT, OFFER, RATE_PLAN_GROUP, RATE_PLAN, ROOT
}