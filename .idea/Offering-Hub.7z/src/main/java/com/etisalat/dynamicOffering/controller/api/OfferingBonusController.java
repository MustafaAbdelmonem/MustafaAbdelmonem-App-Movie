package com.etisalat.dynamicOffering.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.dynamicOffering.controller.AbstractBaseController;
import com.etisalat.dynamicOffering.controller.util.APIResponse;
import com.etisalat.dynamicOffering.service.OfferingBonusService;

/**
 *
 * @author O-Mostafa.Teba
 */

@RestController
@RequestMapping(APIName.OFFERING_BONUS)
public class OfferingBonusController extends AbstractBaseController {

	@Autowired
	OfferingBonusService offeringBonusService;

	@RequestMapping(value = APIName.OFFERING_BONUS_LIST, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findAll() {
		return responseUtil.successResponse(offeringBonusService.findAllODS());
	}
	
	
}
