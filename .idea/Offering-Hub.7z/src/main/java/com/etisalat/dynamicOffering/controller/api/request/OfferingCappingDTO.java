package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferingCappingDTO {
	
	private Integer offeringId;
	private Long cappingDaily;
	private Long cappingWeekly;
	private Long cappingMonthly;
	private Long cappingTotal;
	private String targetBundle;
	private String sourceBundle;
	private String action;
	private Integer targetRatePlan;
	private String unsettlementOffer;
	private Integer productValidity;
	private Float transactionAmount;
	private Integer bundleType;

}
