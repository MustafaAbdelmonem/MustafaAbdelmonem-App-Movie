package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "offering_bonus")
@IdClass(OfferingBonusId.class)
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class OfferingBonusTRM implements Serializable {
	
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_ID")
	private Integer offeringId;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "TRAFFIC_CASE_ID")
	protected Integer trafficCaseId;
	
	@Column(name = "THRESHOLD_ID")
	protected Integer thresholdId;

	@Column(name = "TRAFFIC_CASE")
	protected String trafficCase;

	@Column(name = "BONUS_VALUE")
	protected Float bonusValue;

	@Column(name = "SPECIAL_ROR_FLAG")
	protected Integer specialRorFlag;

	@Column(name = "SPECIAL_ROR_VAL")
	protected Float specialRorVal;
	
	@Column(name = "POOL_BONUS_FLAG")
	protected Integer poolBonusFlag;

	@Column(name = "BONUS_CAPPING")
	private Float bonusCapping;

	@Column(name = "MQ_PROMO_VALIDITY")
	protected Integer mqPromoValidity;

	@Column(name = "MQ_BONUS_VALUE")
	protected Float mqBonusValue;

	@Column(name = "MQ_MAX_RECURRENCE")
	protected Integer mqMaxRecurrence;

}
