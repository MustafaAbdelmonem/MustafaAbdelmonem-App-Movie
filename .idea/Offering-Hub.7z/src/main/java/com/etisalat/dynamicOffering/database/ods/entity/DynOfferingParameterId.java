package com.etisalat.dynamicOffering.database.ods.entity;

import java.io.Serializable;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class DynOfferingParameterId implements Serializable {

	private Integer offeringId;

	private Integer parameterTypeId;

}
