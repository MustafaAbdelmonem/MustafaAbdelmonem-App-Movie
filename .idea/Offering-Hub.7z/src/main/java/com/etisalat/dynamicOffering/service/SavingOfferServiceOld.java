//package com.etisalat.dynamicOffering.service;
//
//import java.text.DateFormat;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.etisalat.common.utils.Constant;
//import com.etisalat.dynamicOffering.database.ods.entity.DynOfferingConverter;
//import com.etisalat.dynamicOffering.database.ods.entity.OfferingChannel;
//import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsAtl;
//import com.etisalat.dynamicOffering.database.ods.entity.OfferingRateplan;
//import com.etisalat.dynamicOffering.database.ods.entity.OfferingThreshold;
//import com.etisalat.dynamicOffering.database.ods.entity.PxDynOfferingParameters;
//import com.etisalat.dynamicOffering.database.trm.entity.Offering;
//import com.etisalat.dynamicOffering.database.trm.repository.OfferingContradictionRepositoryTrm;
//import com.etisalat.dynamicOffering.enums.TrafficCase;
//import com.etisalat.dynamicOffering.enums.Type;
//import com.etisalat.dynamicOffering.models.old.Node;
//import com.etisalat.dynamicOffering.models.old.Offer;
//import com.etisalat.dynamicOffering.models.old.Tier;
//import com.etisalat.dynamicOffering.models.old.TreeNode;
//
//@Service
//public class SavingOfferServiceOld {
//
//	@Autowired
//	OfferingService offeringService;
//
//	@Autowired
//	OfferingDetailsService offeringDetailsService;
//
//	@Autowired
//	OfferingThresholdService offeringThresholdService;
//
//	@Autowired
//	OfferingBonusService offeringBonusService;
//
//	@Autowired
//	DynOfferingParameterService dynOfferingParameterService;
//
//	@Autowired
//	OfferingChannelsService offeringChannelsService;
//
//	@Autowired
//	OfferingContradictionService offeringContradictionService;
//
//	@Autowired
//	OfferingCappingService offeringCappingService;
//
//	@Autowired
//	OfferingRateplanService offeringRateplanService;
//
//	@Autowired
//	DynOfferingConverterService dynOfferingConverterService;
//
//	@Autowired
//	OfferingContradictionRepositoryTrm offeringContradictionRepositoryTrm;
//
//	public int save(Offer offer, boolean update) {
//
//		// Offering offering = new Offering();
//
//		// Step 1
//		offer = saveOffering(offer, update);
//
//		// Step 2
//		try {
//			saveOfferingDetails(offer, update);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		// Step 3
//		insertThresholds(offer, update);
//
//		// Step 4
//		// insertBonus(offer, update);
//
//		// Step 5
//		insertOfferingParameter(offer, update);
//
//		// Step 6
//		try {
//			insertChannels(offer, update);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		// Step 7
//		try {
//			insertContradiction(offer, update);
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		insertPxOfferCapping(offer, update);
//
//		// Step 8
//		insertRatePlan(offer, update);
//
//		// Step 9
//		// insertPxRatePlan(offer);
//
//		// Step 10
//		// insertOfferConverter(offer);
//
//		return offer.getOfferId();
//	}
//
//	public Offer saveOffering(Offer offer, boolean update) {
//
//		// Offering offering =
//		// DynamicOfferingMapper.instance.mapOfferingEntity(Offer.getOfferingDTO());
//
//		Offering offering = new Offering();
//
//		offering.setOfferingName(offer.getDefinition().getOfferName());
//		offering.setOfferingDesc(offer.getDefinition().getOfferName());
//
//		if (!update) {
//			offering.setOfferingStartDttm(new Date());
//			offering.setDwhEntryDate(new Date());
//		}
//		offering.setAccountGroupFlag("D");
//		offering.setPromotionPlanBeforeId(-1);
//
//		// TODO check why below constants 270 and 0 ??? and convert to LOOK-UP
//
//		if (offer.getDefinition().getTemplateId() == 1)
//			offering.setPromotionPlanAfterId(270);
//		else
//			offering.setPromotionPlanAfterId(0);
//
////		offering.setSssId( offer.getDefinition().getOfferingHubLPK().getOfferTypes().getServiceId());
////		offering.setSssName(offer.getDefinition().getOfferingHubLPK().getOfferTypes().getServiceName());
//
////		offering.setOfferingEndDttm(null);
////		offering.setOfferingMask(null);
////		offering.setOfferingBits(null);
////		offering.setCampaignNotificationFlag(null);
////		offering.setBulkActionFlag(null);
////		offering.setEngagementFlag(null);
//
//		offering.setOfferingVal(String.valueOf(offer.getDefinition().getOfferingfval()));
//
//		offering = offeringService.saveOffering(offering);
//
//		// set OfferId after saving
//		offer.setOfferId(offering.getOfferingId());
//
//		return offer;
//	}
//
//	public void saveOfferingDetails(Offer offer, boolean update) throws Exception {
//
//		OfferingDetailsAtl offeringDetailsAtl = new OfferingDetailsAtl();
//
//		offeringDetailsAtl.setOfferingId(offer.getOfferId());
//		offeringDetailsAtl.setOfferingName(offer.getDefinition().getOfferName());
//
//		if (!update)
//			offeringDetailsAtl.setOfferingStartDt(new Date());
//
//		// 5 (offer with attribute) -- 4 (promotion plan)
//		offeringDetailsAtl.setInOfferTypeId(5);
//		offeringDetailsAtl.setOfferingEngDesc(offer.getDefinition().getMediaDescriptionEN());
//		offeringDetailsAtl.setOfferingArDesc(offer.getDefinition().getMediaDescriptionAR());
//
//		offeringDetailsAtl.setValidRenewalPeriod(offer.getConfiguration().getValidRenewalPeriod() != null
//				? offer.getConfiguration().getValidRenewalPeriod()
//				: 0);
//
//		offeringDetailsAtl.setOfferingDuration(
//				offer.getConfiguration().getOfferingDuration() != null ? offer.getConfiguration().getOfferingDuration()
//						: 0);
//
//		// offeringDetailsAtl.setPromotionPlanDuration(offer.getConfiguration().getPromotionPlanDuration());
//
//		offeringDetailsAtl.setOptInOfferingDuration(offer.getConfiguration().getOptinOfferingDuration() != null
//				? offer.getConfiguration().getOptinOfferingDuration()
//				: 0);
//
//		if (offer.getDefinition().isPullOffer())
//			offeringDetailsAtl.setRedemptionWindow(offer.getConfiguration().getRedemptionWindow());
//		else
//			offeringDetailsAtl.setRedemptionWindow(0);
//
//		offeringDetailsAtl.setShortCodeNum(String.valueOf(offer.getDefinition().getShortCode().getShortCode()));
//		offeringDetailsAtl.setOfferingCategory(String.valueOf(offer.getDefinition().getCategoryId()));
//		offeringDetailsAtl.setOfferHiddenFlag("true");
//		offeringDetailsAtl.setOfferingLineType(offer.getDefinition().getCampaignType());
//		offeringDetailsAtl.setOfferingShortDesc(offer.getDefinition().getUssdShortDescription());
//		offeringDetailsAtl.setOfferingLongDesc(offer.getDefinition().getUssdLongDescription());
//		offeringDetailsAtl.setOnlineFlag(offer.getDefinition().isOnline() == true ? 1 : 0);
//
//		// Rate plans are inserted in separate table
//		offeringDetailsAtl.setRatePlanFlag(offer.getDefinition().getTargetRatePlanId());
//
//		offeringDetailsAtl.setSalefnyFlag(offer.getConfiguration().isSalefny() == true ? 1 : 0);
//
//		//// offeringDetailsAtl.setSettlmentOffer(offer.getConfiguration().isSettlmentOffer()
//		//// == true ? 1 : 0);
//
//		if (offer.getDefinition().getOptinFeesFlag())
//			offeringDetailsAtl
//					.setOfferOptinFees(offer.getDefinition().getFees() == null ? 0 : offer.getDefinition().getFees());
//		else
//			offeringDetailsAtl.setOfferOptinFees(0.0f);
//
//		if (offer.getDefinition().getTemplateId() == 1)
//			offeringDetailsAtl.setPromotionPlanId(270);// from lookup
//		else
//			offeringDetailsAtl.setPromotionPlanId(0);
//
//		DateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
//
//		Date promotionPlanStartDate = null;
//
//		Date promotionPlanEndtDate = null;
//
//		if (!update)
//			promotionPlanStartDate = new Date();
//		/*
//		 * if (offer.getConfiguration().getPromotionPlanStartDate() != null)
//		 * promotionPlanStartDate =
//		 * formatter.parse(offer.getConfiguration().getPromotionPlanStartDate ());
//		 */
//
//		if (offer.getConfiguration().getPromotionPlanEndDate() != null)
//			promotionPlanEndtDate = formatter.parse(offer.getConfiguration().getPromotionPlanEndDate());
//
//		formatter = new SimpleDateFormat("yyyy-MM-dd");
//		String promotionPlanStartDt = null;
//		String promotionPlanEndDt = null;
//
//		if (!update)
//			/* if (offer.getConfiguration().getPromotionPlanStartDate() != null) */
//			promotionPlanStartDt = formatter.format(promotionPlanStartDate);
//
//		if (offer.getConfiguration().getPromotionPlanEndDate() != null)
//			promotionPlanEndDt = formatter.format(promotionPlanEndtDate);
//
//		if (promotionPlanStartDt != null)
//			offeringDetailsAtl.setPromotionPlanStartDt(formatter.parse(promotionPlanStartDt));
//		else
//			offeringDetailsAtl.setPromotionPlanStartDt(null);
//
//		if (promotionPlanEndDt != null)
//			offeringDetailsAtl.setPromotionPlanEndDt(formatter.parse(promotionPlanEndDt));
//		else
//			offeringDetailsAtl.setPromotionPlanEndDt(null);
//
//		//// TRM
//		//// offeringDetailsAtl.setAccumulationFlag(offer.getConfiguration().isAccumlation()
//		//// == true ? 1 : 0);
//
//		offeringDetailsAtl.setBonusValidity(offer.getConfiguration().getBonusValidity());
//		offeringDetailsAtl.setSubSendSmsFlag(offer.getConfiguration().isSubscriptionSendSMS() == true ? 1 : 0);
//
//		/*
//		 * List<PxOfferingOffval> eligibleOffVals =
//		 * pxOfferingOffvalDao.findWhereServiceIdEquals(offer.getDefinition().
//		 * getPxShortCode().getServiceId());
//		 * 
//		 * if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 1) {//
//		 * BOR
//		 * 
//		 * if (offer.getDefinition().isPullOffer()) {
//		 * 
//		 * 
//		 * 
//		 * for (PxOfferingOffval offVal : eligibleOffVals) { if
//		 * (offVal.getParameterName().equalsIgnoreCase("granting_mechanism") &&
//		 * offVal.getParameterValue().equalsIgnoreCase("pull")) {
//		 * offeringDetailsAtl.setOfferingVal(offVal.getOfferingVal()); }
//		 * 
//		 * }
//		 * 
//		 * } else if (!offer.getDefinition().isPullOffer()) { for (PxOfferingOffval
//		 * offVal : eligibleOffVals) { if
//		 * (offVal.getParameterName().equalsIgnoreCase("granting_mechanism") &&
//		 * offVal.getParameterValue().equalsIgnoreCase("push")) {
//		 * offeringDetailsAtl.setOfferingVal(offVal.getOfferingVal()); }
//		 * 
//		 * } } } else if (offer.getDefinition().getPxOfferingTemplates().getTemplateId()
//		 * == 2) { // PAY // AND // GET
//		 * 
//		 * offeringDetailsAtl.setOfferingVal(eligibleOffVals.get(0).getOfferingVal()); }
//		 * // Bonus on renewal else if
//		 * (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 3) {
//		 * 
//		 * try {
//		 * offeringDetailsAtl.setOfferingVal(eligibleOffVals.get(0).getOfferingVal()); }
//		 * catch (Exception e) { System.out.println("outOfBoundException"); } }
//		 * 
//		 * 
//		 * else if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 6)
//		 * {
//		 * offeringDetailsAtl.setOfferingVal(offer.getDefinition().getPxOfferingOffval()
//		 * .getOfferingVal());
//		 * 
//		 * }
//		 * 
//		 * 
//		 * else if (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 7)
//		 * {
//		 * 
//		 * 
//		 * offeringDetailsAtl.setOfferingVal(offer.getDefinition().getPxOfferingOffval()
//		 * .getOfferingVal());
//		 * 
//		 * } // Use And Get else if
//		 * (offer.getDefinition().getPxOfferingTemplates().getTemplateId() == 8) {
//		 * 
//		 * try {
//		 * offeringDetailsAtl.setOfferingVal(eligibleOffVals.get(0).getOfferingVal()); }
//		 * catch (Exception e) { System.out.println("outOfBoundException"); } }
//		 */
//
//		offeringDetailsAtl.setOfferingVal(offer.getDefinition().getOfferingfval());
//
//		offeringDetailsAtl.setSssId((int) offer.getDefinition().getShortCode().getServiceId());
//		offeringDetailsAtl.setSssName(offer.getDefinition().getShortCode().getServiceName());
//
//		if (offer.getDefinition().isPullOffer())
//			offeringDetailsAtl.setGrantingMechanism(2);
//		else
//			offeringDetailsAtl.setGrantingMechanism(1);
//
//		// OFFERING HUB ENHANCEMENT
//		offeringDetailsAtl.setCommercialServiceArdesc(offer.getDefinition().getCommercialServiceDescriptionAR());
//		offeringDetailsAtl.setCommercialServiceEndesc(offer.getDefinition().getCommercialServiceDescriptionEn());
//		// case mutli tiers
//		offeringDetailsAtl
//				.setMultipleThresholdFlag(offer.getConfiguration().getDynBonus().getTiers().size() > 1 ? 1 : 0);
//
//		offeringDetailsAtl.setIsInformative(offer.getDefinition().isInformativeOffer() == true ? 1 : 0);
//		offeringDetailsAtl.setResourceType(offer.getConfiguration().getDynBonus().getBonusType().toString());
//
//		offeringDetailsAtl.setOptinScriptAr(offer.getDefinition().getOptinScriptAr());
//		offeringDetailsAtl.setOptinScriptEn(offer.getDefinition().getOptinScriptEn());
//
//		offeringDetailsAtl.setBonusTypeFlag(offer.getConfiguration().isBonusTypeFlag() == true ? 2 : 1);
//
//		if (offer.getConfiguration().isAccumlation() == true)
//			offeringDetailsAtl.setAccumlationDuration(offer.getConfiguration().getAccumlationDuration());
//
////		offeringDetailsAtl.setPLATFORM_ID(offer.getPlatformId());
////		offeringDetailsAtl.setOPERATIONID(offer.getOperationId());
////		offeringDetailsAtl.setPRODUCT_NAME(offer.getProductName());
////		
////		offeringDetailsAtl.setPLATFORM_AR_DESC(offer.getPlatformArDesc());
////		offeringDetailsAtl.setPLATFORM_EN_DESC(offer.getPlatformEnDesc());
//
//		/**
//		 * 
//		 * zika change and pay and get
//		 * 
//		 * PxOfferingLPK pxOfferingLPK =
//		 * pxOfferingLPKDao.findWhereServiceIdEquals(String.valueOf(offer.getDefinition().getPxShortCode().getServiceId()),
//		 * offer.getDefinition().getPxOfferingOffval().getOfferingVal());
//		 * 
//		 * 
//		 * //PxOfferingLPK pxOfferingLPK =
//		 * pxOfferingLPKDao.findWhereServiceId(String.valueOf(offer.getDefinition().getPxShortCode().getServiceId()));
//		 * 
//		 * offeringDetailsAtl.setPLATFORM_ID(pxOfferingLPK.getPlatformId());
//		 * offeringDetailsAtl.setOPERATIONID(pxOfferingLPK.getOperationId());
//		 * offeringDetailsAtl.setPRODUCT_NAME(pxOfferingLPK.getProductName());
//		 * 
//		 * offeringDetailsAtl.setPLATFORM_AR_DESC(pxOfferingLPK.getPlatformArDesc());
//		 * offeringDetailsAtl.setPLATFORM_EN_DESC(pxOfferingLPK.getPlatformEnDesc());
//		 */
//
//		offeringDetailsService.insertATL(offeringDetailsAtl);
//		// return offeringDetailsService.insertATL(offeringDetailsAtl);
//
//	}
//
//	public void insertThresholds(Offer offer, boolean update) {
//
//		OfferingThreshold threshold;
//		int counter = 4;
//		int thresholdId = 1;
//		// List<Tier> tiers = offer.getConfiguration().getDynBonus().getTiers();
//
//		// *** Collections.sort(offer.getConfiguration().getDynBonus().getTiers());
//
//		for (Tier t : offer.getConfiguration().getDynBonus().getTiers()) {
//			threshold = new OfferingThreshold();
//			threshold.setOfferingId(offer.getOfferId());
//			threshold.setThresholdId(thresholdId);
//			if (offer.getConfiguration().getDynBonus().getBonusType().equals(TrafficCase.POOL)
//					|| offer.getConfiguration().getDynBonus().getBonusType().equals(TrafficCase.MIXED))
//				threshold.setPoolValue(t.getPoolBonusValue());
//			else
//				threshold.setPoolValue(0f);
//			threshold.setThresholdValue(t.getThresholdValue().floatValue());
//
//			offeringThresholdService.insertOfferingThreshold(threshold);
//			insertBonus(offer, update);
//			thresholdId++;
//
//		}
//		// check for missing threshold(s) and add them
//		if (thresholdId > 2 && thresholdId < counter) {
//
//			// for (int i = 0; i < counter - thresholdId; i++) {
//			threshold = new OfferingThreshold();
//			threshold.setOfferingId(offer.getOfferId());
//			threshold.setThresholdId(thresholdId);
//			if (offer.getConfiguration().getDynBonus().getBonusType().equals(TrafficCase.POOL)
//					|| offer.getConfiguration().getDynBonus().getBonusType().equals(TrafficCase.MIXED))
//				threshold.setPoolValue(0f);
//			else
//				threshold.setPoolValue(0f);
//			threshold.setThresholdValue(2000f);
//			offeringThresholdService.insertOfferingThreshold(threshold);
//
//			insertBonus(offer, update);
//
//			thresholdId++;
//
//			// }
//
//		}
//
//	}
//
//	public void insertBonus(Offer offer, boolean update) {
//
//		offeringBonusService.insertOfferingBonus(offer.getConfiguration().getOfferingBonus());
//		
//		
//	}
//
//	public void insertOfferingParameter(Offer offer, boolean update) {
//
//		// add migration flag as a parameter
//		if (offer.getConfiguration().isMigrationFlag()) {
//			PxDynOfferingParameters bonusParameter = new PxDynOfferingParameters();
//			bonusParameter.setOfferingId(offer.getOfferId());
//			bonusParameter.setParameterTypeId(Constant.parameterTypeId_migrationFlag);
//			// bonusParameter.setParameterTxt("Migration_Flag");// the Migration flag when
//			// true
//			bonusParameter.setParameterTxt("1");// the Migration flag is 1 when true
//			dynOfferingParameterService.insertOfferingParameter(bonusParameter);
//		}
//
//		// add dynamic quota flag as a parameter on Bonus on renewal
//		if (offer.getDefinition().getTemplateId() == 3) {
//			PxDynOfferingParameters bonusParameter = new PxDynOfferingParameters();
//			bonusParameter.setOfferingId(offer.getOfferId());
//			bonusParameter.setParameterTypeId(Constant.parameterTypeId_dynamicQuotaFlag);
//
//			bonusParameter.setParameterTxt(offer.getConfiguration().isDynamicQuota() == true ? "1" : "0");// DynamicQuota
//																											// flag is 1
//																											// when true
//			dynOfferingParameterService.insertOfferingParameter(bonusParameter);
//		}
//
//		if (offer.getDefinition().getTemplateId() == 7) {
//			PxDynOfferingParameters bounsParam = new PxDynOfferingParameters();
//			bounsParam.setOfferingId(offer.getOfferId());
//			bounsParam.setParameterTypeId(Constant.parameterTypeId_renewalOnFlag);
//			bounsParam.setParameterTxt(offer.getConfiguration().isRenewalOnTime() == true ? "1" : "0");
//			dynOfferingParameterService.insertOfferingParameter(bounsParam);
//		}
//
//		if (offer.getDefinition().getTemplateId() == 6) {
//			PxDynOfferingParameters bounsParam = new PxDynOfferingParameters();
//			bounsParam.setOfferingId(offer.getOfferId());
//			bounsParam.setParameterTypeId(Constant.parameterTypeId_bundleTypeId);
//			bounsParam.setParameterTxt(offer.getDefinition().getBundleType());
//			dynOfferingParameterService.insertOfferingParameter(bounsParam);
//		}
//
//		for (PxDynOfferingParameters bonusParameter : offer.getConfiguration().getDynBonus()
//				.getPxDynOfferingParametersList()) {
//			// check filled parameters, as we initialize 6 params by
//			// default
//			if (bonusParameter.getParameterTxt() != null && !bonusParameter.getParameterTxt().isEmpty()) {
//				bonusParameter.setOfferingId(offer.getOfferId());
//				bonusParameter.setParameterTypeId(bonusParameter.getParameterTypeId());
//				bonusParameter.setParameterTxt(bonusParameter.getParameterTxt());
//				dynOfferingParameterService.insertOfferingParameter(bonusParameter);
//			}
//		}
//
//	}
//
//	public void insertChannels(Offer offer, boolean update) throws Exception {
//
//		try {
//
//			for (OfferingChannel channel : offer.getDefinition().getOfferingChannelList()) {
//				offeringChannelsService.insertOfferingChannels(channel);
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new Exception("Failed while inserting channels");
//		}
//
//	}
//
//	public void insertContradiction(Offer offer, boolean update) throws Exception {
////		List<OfferingContradiction> offeringContradictionList = new ArrayList<OfferingContradiction>();
////		OfferingContradiction offeringContradiction;
////		TreeNode selectedContradictions = offer.getContradiction().getSelectedTree();
////		TreeNode unSelectedContradictions = offer.getContradiction().getUnSelectedTree();
////
////		boolean catPartiallySelected;
////
////		try {
////
////			for (TreeNode cateNode : selectedContradictions.getChildren()) {
////
////				catPartiallySelected = false;
////
////				// prepare category data
////				offeringContradiction = new OfferingContradiction();
////				offeringContradiction.setOfferingId(offer.getOfferId());
////				offeringContradiction.setContradictingId(((Node) cateNode.getData()).getId());
////				offeringContradiction.setContradictingTypeId(1);
////
////				for (TreeNode unSelectedCateNode : unSelectedContradictions.getChildren())
////
////				{
////					if (((Node) cateNode.getData()).getId().intValue() == ((Node) unSelectedCateNode.getData()).getId().intValue()) {
////						catPartiallySelected = true;
////					}
////				}
////
////				if (!catPartiallySelected) {
////					offeringContradictionList.add(offeringContradiction);
////				} else {
////					for (TreeNode offerNode : cateNode.getChildren()) {
////
////						// prepare offer data
////						offeringContradiction = new OfferingContradiction();
////						offeringContradiction.setOfferingId(offer.getOfferId());
////						offeringContradiction.setContradictingId(((Node) offerNode.getData()).getId());
////						offeringContradiction.setContradictingTypeId(2);
////						// add offer to contradiction
////						offeringContradictionList.add(offeringContradiction);
////
////					}
////				}
////
////			}
////
////			for (OfferingContradiction                                                                          contradiction : offeringContradictionList) {
////			offeringContradictionService.insertOfferingContradiction(contradiction);
////			}
////		} catch (Exception e) {
////			e.printStackTrace();
////			throw new Exception("Failed while inserting traffic contradictions");
////		}
//
//	}
//	
//	
//	public void insertPxOfferCapping(Offer offer, boolean update) {
//
//		offeringCappingService.insertOfferingCapping(offer.getConfiguration().getOfferCapping());
//	}
//
//	
//	
//	public void insertRatePlan(Offer offer, boolean update) {
//
//
//		OfferingRateplan ratePlan;
//
//		for (TreeNode n : offer.getDefinition().getSelectedNodes()) {
//			if (((Node) n.getData()).getType().equals(Type.RATE_PLAN)) {
//				ratePlan = new OfferingRateplan();
//				ratePlan.setRatePlanProductId(((Node) n.getData()).getId());
//				ratePlan.setOfferingId(offer.getOfferId());
//				ratePlan.setStartDate(new Date());
//				ratePlan.setEndDate(null);
//				offeringRateplanService.insertOfferingRateplanTRM(ratePlan);
//			}
//
//		}
//	}
//
//	public void insertOfferConverter(Offer offer, boolean update) {
//
//		DynOfferingConverter offeringConvOb = offer.getConfiguration().getDynOfferingConverter();
//		offeringConvOb.setOfferingId(offer.getOfferId());
//
//		if (offeringConvOb != null) {
//			dynOfferingConverterService.insertDynOfferingConverter(offeringConvOb);
//		}
//
//		//
////		DynOfferingConverter dynOfferingConverter = DynamicOfferingMapper.instance
////				.mapDynOfferingConverterEntity(Offer.getDynOfferingConverterDTO());
////
////		dynOfferingConverterService.insertDynOfferingConverterTRM(dynOfferingConverter);
//	}
//
//}
