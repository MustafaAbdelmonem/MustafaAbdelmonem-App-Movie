package com.etisalat.dynamicOffering.database.ods.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.ods.entity.DynOfferingParameterId;
import com.etisalat.dynamicOffering.database.ods.entity.PxDynOfferingParameters;

public interface DynOfferingParameterRepositoryOds extends JpaRepository<PxDynOfferingParameters, DynOfferingParameterId> {

}