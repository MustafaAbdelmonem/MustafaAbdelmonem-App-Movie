package com.etisalat.dynamicOffering.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.trm.entity.PxOfferingLPK;
import com.etisalat.dynamicOffering.database.trm.repository.PxOfferingLpkRepository;

@Service
public class PxOfferingLpkService extends AbstractBaseService {

	@Autowired
	PxOfferingLpkRepository pxOfferingLpkRepository;
		
	@Transactional()
	public PxOfferingLPK findByServiceIdNative(String serviceId) {
		return pxOfferingLpkRepository.findByServiceIdNative(Integer.valueOf(serviceId));
	}
	
	@Transactional()
	public PxOfferingLPK findByServiceIdAndOfferingValNative(String serviceId, String offeringVal) {
		return pxOfferingLpkRepository.findByServiceIdAndOfferingValNative(Integer.valueOf(serviceId), Integer.valueOf(offeringVal));
	}

}
