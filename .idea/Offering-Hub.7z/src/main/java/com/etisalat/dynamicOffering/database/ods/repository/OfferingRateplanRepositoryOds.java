package com.etisalat.dynamicOffering.database.ods.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingRateplan;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingRateplanId;

/**
 *
 * @author O-Mostafa.Teba
 */
public interface OfferingRateplanRepositoryOds extends JpaRepository<OfferingRateplan, OfferingRateplanId> {

}