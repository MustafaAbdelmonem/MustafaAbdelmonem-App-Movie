package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

public class OfferingValId implements Serializable {

	private Integer serviceId;

	private String parameterValue;

	private Integer offeringVal;

}
