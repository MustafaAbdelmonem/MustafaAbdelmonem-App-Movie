package com.etisalat.dynamicOffering.enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public enum ConfigrationAction {

	RENEWAL("Renewal"),
	MIGRATION("Migration"),
	AMR("AMR");

	private String name;

	ConfigrationAction(String name) {
		this.name = name;
	}
	
	public static  List<Properties> getAllData(){
		List<Properties> data = new ArrayList<Properties>();
		for(ConfigrationAction tc : ConfigrationAction.values()) {
			Properties prop = new Properties();
			prop.put("name", tc.name);
			data.add(prop);
		}
		return data;
	}
	
	public static  List<Properties> getData(List<ConfigrationAction> list){
		List<Properties> data = new ArrayList<Properties>();
		for(ConfigrationAction tc : list) {
			Properties prop = new Properties();
			prop.put("name", tc.name);
			data.add(prop);
		}
		return data;
	}
	
}
