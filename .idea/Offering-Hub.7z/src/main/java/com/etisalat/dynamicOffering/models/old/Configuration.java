package com.etisalat.dynamicOffering.models.old;

import java.io.Serializable;
import java.util.List;

import com.etisalat.dynamicOffering.database.ods.entity.DynOfferingConverter;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingBonus;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingCapping;

import lombok.Data;

@Data
public class Configuration implements Serializable {

	
	
	
	private OfferingBonus offeringBonus;
	
	
	private String promotionPlanStartDate;
	private String promotionPlanEndDate;
	private Integer promotionPlanDuration;
	private Integer offeringDuration;

	// eligibility duration
	private Integer optinOfferingDuration;
	private Integer redemptionWindow;
	private boolean salefny;
	private boolean settlmentOffer;
	private boolean accumlation;
	private int accumlationDuration;
	private boolean subscriptionSendSMS;
	private boolean migrationFlag;
	private OfferingCapping offerCapping;
	
	// TODO what is business need for this attribute ??
	private Float rechargeThreshold;
	private Integer BonusValidity;
	private Integer validRenewalPeriod;
	private Integer maximumIncidentOfBonus;
	private String bonusType;
	private boolean renewalOnTime;
	
	// Fixed(false) or Percentage(true).
	private boolean bonusTypeFlag;
	private float transactionAmount;
	private String targetBundle;
	private String sourceBundle;
	private String action;
	private boolean dynamicQuota;
	private DynBonus dynBonus;
	private List<OfferingParameter> pxDynOfferingParametersList;
	private DynOfferingConverter dynOfferingConverter;

}
