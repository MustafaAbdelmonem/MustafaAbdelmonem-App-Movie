package com.etisalat.dynamicOffering.database.trm.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingDetails;
import org.springframework.data.repository.query.Param;
/**
 *
 * @author O-Mostafa.Teba
 */
public interface OfferingDetailsRepositoryTrm extends JpaRepository<OfferingDetails, Integer> {
	
	List<OfferingDetails> findByOfferingCategory(String offeringCategory);
	
	List<OfferingDetails>  findByOfferingName(String offeringName);

	//m.samir
	List<OfferingDetails>  findByOfferingId(Integer offeringId);

	List<OfferingDetails>  findByOfferingVal(Integer offeringVal,Pageable pageable);

	// i need to check the performance of this result
	@Query("select count(*) from OfferingDetails t where t.offeringVal=:offeringVal")
	int countOfferingval(@Param("offeringVal") Integer offeringVal);



}