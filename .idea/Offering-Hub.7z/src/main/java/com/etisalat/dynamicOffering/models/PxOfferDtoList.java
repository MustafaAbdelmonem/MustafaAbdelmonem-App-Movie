package com.etisalat.dynamicOffering.models;

import java.util.ArrayList;
import java.util.List;

import com.etisalat.common.attribute.ReadableList;
import com.etisalat.dynamicOffering.database.trm.entity.Offering;

import lombok.Data;


@Data
public class PxOfferDtoList extends ReadableList {

	
	
private static final long serialVersionUID = 6907746932097802636L;
	
	private List<Offering> pxOffers = new ArrayList<>();

}
