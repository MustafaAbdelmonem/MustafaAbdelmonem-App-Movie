package com.etisalat.dynamicOffering.enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public enum BonusType {
	
	VOICE(1,"Voice"),
	SMS(2,"SMS"),
	MI(3,"MI"),
	UNITS(4,"UNITS"),
	UNITS_VOICE(5,"UNITS_VOICE"),
	UNITS_ONNET_MI(6,"UNITS_ONNET_MI"),
	UNITS_ONNET_CORSSNET_MI(7,"UNITS_ONNET_CORSSNET_MI");
	
	private Integer id;
	private String name;
	
	 BonusType(Integer id, String name) {
		this.id = id;
		this.name = name;
	}
	 
	 public static  List<Properties> getData(){
		List<Properties> data = new ArrayList<Properties>();
		for(BonusType bt : BonusType.values()) {
			Properties prop = new Properties();
			prop.put("name", bt.name);
			prop.put("id", bt.id.toString());
			data.add(prop);
		}
		return data;
	}
}
