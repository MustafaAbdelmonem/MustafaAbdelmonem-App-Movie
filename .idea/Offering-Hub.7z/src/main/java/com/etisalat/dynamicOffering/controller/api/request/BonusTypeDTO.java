package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class BonusTypeDTO {

	private Integer id;
	private String name;
	
}
