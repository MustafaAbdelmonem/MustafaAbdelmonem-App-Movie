package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferPxDynOfferingParametersDTO {
	
	private PxDynOfferingParametersLkpDTO pxDynOfferingParamLkp;

	private Integer offeringId;

	private boolean offeringIdNull = true;
	
	private Integer parameterTypeId;
	
	private boolean parameterTypeIdNull = true;

	private float parameter1;

	private boolean parameter1Null = true;

	private float parameter2;

	private boolean parameter2Null = true;

	private float parameter3;

	private boolean parameter3Null = true;

	private String parameterTxt;

}
