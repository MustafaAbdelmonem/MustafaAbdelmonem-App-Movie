package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "px_OfferingHub_LPK", uniqueConstraints = {
		@UniqueConstraint(columnNames = { "SERVICE_ID", "SHORT_CODE", "OFFERING_VAL", "PARAMETER_VALUE" }) })
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class OfferingHubLpkTRM implements Serializable {
	private static final long serialVersionUID = 1L;

	
	@Column(name = "SERVICE_ID")
	private Integer serviceId;
	
	@Column(name = "SHORT_CODE")
	private Integer shortCode;
	
	@Column(name = "PARAMETER_VALUE")
	private String parameterValue;
	
	@Id
	@Basic(optional = false)
	@Column(name = "OFFERING_VAL")
	private Integer offeringVal;

	@Column(name = "TEMPLATE_ID")
	Integer templateId;

	@Column(name = "TEMPLATE_NAME")
	private String templateName;

	@Column(name = "PARAMETER_NAME")
	private String parameterName;

	@Column(name = "OFFER_TYPE")
	private String offerType;

	@Column(name = "SERVICE_NAME")
	String serviceName;

	@Column(name = "OPERATION_ID")
	private String operationId;

	@Column(name = "PLATFORM_ID")
	private String platformId;

	@Column(name = "PRODUCT_NAME")
	private String productName;

	@Column(name = "PLATFORM_AR_DESC")
	private String platformArDesc;

	@Column(name = "PLATFORM_EN_DESC")
	private String platformEnDesc;

}
