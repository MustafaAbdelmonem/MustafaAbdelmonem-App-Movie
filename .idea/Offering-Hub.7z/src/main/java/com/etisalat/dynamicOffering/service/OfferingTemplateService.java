package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingTemplates;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingTemplatesRepositoryTrm;

/**
 *
 * @author O-Mostafa.Teba
 */
@Service
public class OfferingTemplateService 	{

	@Autowired
	private OfferingTemplatesRepositoryTrm pxOfferingTemplatesRepositoryTrm;

	@Transactional()
	public List<OfferingTemplates> findAll() {
		return pxOfferingTemplatesRepositoryTrm.findAll();
	}
}
