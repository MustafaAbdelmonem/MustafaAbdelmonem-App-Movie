package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "PX_RUN_DETAILS")
@IdClass(RunDetailsId.class)
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class RunDetails implements Serializable
{
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "COMMUNICATION_ID")
	private String communicationId;

	@Column(name = "COMMUNICATION_NAME")
	private String communicationName;

	@NotNull
	@Column(name = "STEP_ID")
	private String stepId;

	@Column(name = "PROCESS_DTTM")
	@Temporal(TemporalType.TIMESTAMP)
	private Date processDttm;

	@Column(name = "COLLATERAL_TEMPLATE_ID")
	private String collateralTemplateId;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_ID")
	private Integer offeringId;

	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_RUN_ID")
	private Integer offeringRunId;

	@Column(name = "OFFERING_RUN_START_DT")
	@Temporal(TemporalType.DATE)
	private Date offeringRunStartDt;

	@Column(name = "OFFERING_RUN_END_DT")
	@Temporal(TemporalType.DATE)
	private Date offeringRunEndDt;

	@Column(name = "OFFER_ENJOYING_DURATION")
	private Integer offerEnjoyingDuration;

	@Column(name = "NUMBER_OF_SUBS")
	private Integer numberOfSubs;

	@Column(name = "EFFECTIVE_DATE")
	private Date effectiveDate;

	@Column(name = "VALUE_SEGMENT_ID")
	private Integer valueSegmentId;

	@Column(name = "HIDDEN_FLAG")
	private String runHiddenFlag;

}
