package com.etisalat.dynamicOffering.controller.api.request;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Data
public class DynOfferingParameterDTO implements Serializable {
	
	private Integer offeringId;
	private Integer parameterTypeId;
	private Integer parameter1;
	private Integer parameter2;
	private Integer parameter3;
	private String parameterTxt;

}
