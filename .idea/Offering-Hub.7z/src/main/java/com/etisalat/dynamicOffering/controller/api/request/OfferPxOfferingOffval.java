package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferPxOfferingOffval {

	private Integer serviceId;

	private boolean serviceIdNull = true;

	private String parameterName;

	private String parameterValue;

	private Integer offeringVal;

	private boolean offeringValNull = true;

	private String offerType;
}
