package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.entity.Channel;
import com.etisalat.dynamicOffering.database.ods.repository.ChannelRepositoryOds;;

/**
 * @author O-Mostafa.Teba
 *
 */
@Service
public class ChannelService extends AbstractBaseService {

	@Autowired
	ChannelRepositoryOds channelRepositry;

	@Transactional()
	public List<Channel> findAllChannels(Pageable page) {
		return channelRepositry.findAll();
	}

	@Transactional(transactionManager = "")
	public Channel addNewChannel(Channel channel) {
		return channelRepositry.save(channel);
	}

	@Transactional(transactionManager = "")
	public void deletChannel(Channel channel) {
		channelRepositry.delete(channel);
	}

}
