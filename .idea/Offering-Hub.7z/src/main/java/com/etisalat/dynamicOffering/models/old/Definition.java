package com.etisalat.dynamicOffering.models.old;

import java.io.Serializable;
import java.util.List;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingChannel;
import com.etisalat.dynamicOffering.database.trm.entity.ServiceCategory;
import com.etisalat.dynamicOffering.models.OfferingHubLPK;

import lombok.Data;

@Data
public class Definition implements Serializable {

	
	private String offerName;

	private Integer templateId;
	
	private OfferingHubLPK offeringHubLPK;

	private ServiceCategory serviceCategory;
	
	private Integer categoryId;
	private ShortCode shortCode;
	
	private Integer offeringfval;

	private Boolean optinFeesFlag;
	private Float fees;

	private String campaignType;

	private Integer targetRatePlanId;
	
	private Integer eligibleRatePlanBTL;
	private List<Integer> eligibleRatePlanIdsATL;

	private String grantingMechanism;

	
	private TreeNode unSelectedTree;
	private TreeNode[] unSelectedNodes;

	private TreeNode selectedTree;
	private TreeNode[] selectedNodes;

	
//	private Map<String, Boolean> optin;
//	private Map<String, Boolean> optout;
//	private Map<String, Boolean> redemption;
//	private Map<String, Boolean> confirmation;

	private List<OfferingChannel> offeringChannelList;

	private String commercialServiceDescriptionEn;
	private String commercialServiceDescriptionAR;

	private String mediaDescriptionEN;
	private String mediaDescriptionAR;

	private String ussdShortDescription;
	private String ussdLongDescription;

	private String optinScriptAr;
	private String optinScriptEn;

	private String platformDescriptionEn;
	private String platformDescriptionAR;

	private boolean online;
	private boolean informativeOffer;
	private boolean pullOffer;
	
	private String bundleType;

}
