package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

/**
*
* @author O-Mostafa.Teba
*/
@Data
public class OfferingChannelDTO {	
	
	private Integer offeringId;
	private Integer channelId;
	private Integer channeltypeId;

}
