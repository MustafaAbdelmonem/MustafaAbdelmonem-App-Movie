package com.etisalat.dynamicOffering.models.old;

import java.io.Serializable;
import java.util.List;

import com.etisalat.dynamicOffering.database.ods.entity.PxDynOfferingParameters;
import com.etisalat.dynamicOffering.enums.BonusType;

import lombok.Data;

@Data
public class DynBonus implements Serializable {
	
	
	
	private BonusType bonusType; // unit or pool or mixed
	private List<Tier> tiers;
	private boolean dynBonusCompleted;

	private List<PxDynOfferingParameters> pxDynOfferingParametersList;
	
//
//	private String bonusType;
//	private String bonusTypeValue;
//	
//	private List<Tier> tiers;
//	private Float bonusValue;
//	
//	private Integer consumptionValue;
//	
//	private boolean specialROR;
//	private Integer specialRORValue;
//	
//	// TODO Consume from pool
//	private boolean poolBonusFlag;
//	
//	private float bonusCapping;
//	
//	private String voucherID;
//	
//	private Float bonusDynamicDiscount;
//	
//	private Integer promoValidity;
//	
//	private Float multipleQuotaValue;
//	
//	private Integer multipleQuotaMaxRecurrence;
//	
//	private String fawryVoucherId;
//	
//	private String uberVoucherId;
//
//	private String usagePercentage;
		
}
