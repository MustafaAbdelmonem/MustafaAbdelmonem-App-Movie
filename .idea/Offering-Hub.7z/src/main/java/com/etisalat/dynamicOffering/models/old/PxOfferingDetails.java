package com.etisalat.dynamicOffering.models.old;

import java.io.Serializable;
import java.util.Date;

public class PxOfferingDetails implements Serializable, Comparable<PxOfferingDetails> {


	protected String PRODUCT_NAME ;

	protected String PLATFORM_ID;

	protected String OPERATIONID;

	protected String PLATFORM_AR_DESC;

	protected String PLATFORM_EN_DESC;
	
	
	
	
	
	
	public String getPRODUCT_NAME() {
		return PRODUCT_NAME;
	}

	public void setPRODUCT_NAME(String pRODUCT_NAME) {
		PRODUCT_NAME = pRODUCT_NAME;
	}

	public String getPLATFORM_ID() {
		return PLATFORM_ID;
	}

	public void setPLATFORM_ID(String pLATFORM_ID) {
		PLATFORM_ID = pLATFORM_ID;
	}

	public String getOPERATIONID() {
		return OPERATIONID;
	}

	public void setOPERATIONID(String oPERATIONID) {
		OPERATIONID = oPERATIONID;
	}

	public String getPLATFORM_AR_DESC() {
		return PLATFORM_AR_DESC;
	}

	public void setPLATFORM_AR_DESC(String pLATFORM_AR_DESC) {
		PLATFORM_AR_DESC = pLATFORM_AR_DESC;
	}

	public String getPLATFORM_EN_DESC() {
		return PLATFORM_EN_DESC;
	}

	public void setPLATFORM_EN_DESC(String pLATFORM_EN_DESC) {
		PLATFORM_EN_DESC = pLATFORM_EN_DESC;
	}

	/**
	 * This attribute maps to the column OFFERING_ID in the px_offering_details
	 * table.
	 */
	protected int offeringId;

	private Integer redemptionWindow;

	/**
	 * This attribute represents whether the primitive attribute offeringId is
	 * null.
	 */
	protected boolean offeringIdNull = true;

	/**
	 * This attribute maps to the column OFFERING_NAME in the
	 * px_offering_details table.
	 */
	protected String offeringName;

	/**
	 * This attribute maps to the column OFFERING_START_DT in the
	 * px_offering_details table.
	 */
	protected Date offeringStartDt;

	/**
	 * This attribute maps to the column OFFERING_END_DT in the
	 * px_offering_details table.
	 */
	protected Date offeringEndDt;

	/**
	 * This attribute maps to the column OFFERING_DURATION in the
	 * px_offering_details table.
	 */
	protected int offeringDuration;

	/**
	 * This attribute represents whether the primitive attribute
	 * offeringDuration is null.
	 */
	protected boolean offeringDurationNull = true;

	/**
	 * This attribute maps to the column OPT_IN_OFFERING_DURATION in the
	 * px_offering_details table.
	 */
	protected int optInOfferingDuration;

	/**
	 * This attribute represents whether the primitive attribute
	 * optInOfferingDuration is null.
	 */
	protected boolean optInOfferingDurationNull = true;

	/**
	 * This attribute maps to the column SSS_ID in the px_offering_details
	 * table.
	 */
	protected int sssId;

	/**
	 * This attribute represents whether the primitive attribute sssId is null.
	 */
	protected boolean sssIdNull = true;

	/**
	 * This attribute maps to the column SSS_NAME in the px_offering_details
	 * table.
	 */
	protected String sssName;

	/**
	 * This attribute maps to the column SHORT_CODE_NUM in the
	 * px_offering_details table.
	 */
	protected String shortCodeNum;

	/**
	 * This attribute maps to the column OFFERING_CATEGORY in the
	 * px_offering_details table.
	 */
	protected String offeringCategory;

	/**
	 * This attribute maps to the column OFFER_PRIORITY in the
	 * px_offering_details table.
	 */
	protected int offerPriority;

	/**
	 * This attribute represents whether the primitive attribute offerPriority
	 * is null.
	 */
	protected boolean offerPriorityNull = true;

	/**
	 * This attribute maps to the column OFFERING_BITS in the
	 * px_offering_details table.
	 */
	protected String offeringBits;

	/**
	 * This attribute maps to the column OFFERING_VAL in the px_offering_details
	 * table.
	 */
	protected int offeringVal;

	/**
	 * This attribute represents whether the primitive attribute offeringVal is
	 * null.
	 */
	protected boolean offeringValNull = true;

	/**
	 * This attribute maps to the column OFFERING_MASK in the
	 * px_offering_details table.
	 */
	protected int offeringMask;

	/**
	 * This attribute represents whether the primitive attribute offeringMask is
	 * null.
	 */
	protected boolean offeringMaskNull = true;

	/**
	 * This attribute maps to the column IN_OFFER_TYPE_ID in the
	 * px_offering_details table.
	 */
	protected int inOfferTypeId;

	/**
	 * This attribute represents whether the primitive attribute inOfferTypeId
	 * is null.
	 */
	protected boolean inOfferTypeIdNull = true;

	/**
	 * This attribute maps to the column OFFERING_ENG_DESC in the
	 * px_offering_details table.
	 */
	protected String offeringEngDesc;

	/**
	 * This attribute maps to the column OFFERING_AR_DESC in the
	 * px_offering_details table.
	 */
	protected String offeringArDesc;

	/**
	 * This attribute maps to the column OFFERING_LINE_TYPE in the
	 * px_offering_details table.
	 */
	protected String offeringLineType;

	/**
	 * This attribute maps to the column OFFER_HIDDEN_FLAG in the
	 * px_offering_details table.
	 */
	protected String offerHiddenFlag;

	/**
	 * This attribute maps to the column Offering_Short_Desc in the
	 * px_offering_details table.
	 */
	protected String offeringShortDesc;

	/**
	 * This attribute maps to the column Offering_Long_Desc in the
	 * px_offering_details table.
	 */
	protected String offeringLongDesc;

	/**
	 * This attribute maps to the column Online_Flag in the px_offering_details
	 * table.
	 */
	protected int onlineFlag;

	/**
	 * This attribute represents whether the primitive attribute onlineFlag is
	 * null.
	 */
	protected boolean onlineFlagNull = true;

	/**
	 * This attribute maps to the column Offer_OptIn_Fees in the
	 * px_offering_details table.
	 */

	protected float offerOptinFees;

	/**
	 * This attribute represents whether the primitive attribute offerOptinFees
	 * is null.
	 */
	protected boolean offerOptinFeesNull = true;

	/**
	 * This attribute maps to the column Promotion_plan_ID in the
	 * px_offering_details table.
	 */
	protected int promotionPlanId;

	/**
	 * This attribute represents whether the primitive attribute promotionPlanId
	 * is null.
	 */
	protected boolean promotionPlanIdNull = true;

	/**
	 * This attribute maps to the column Promotion_Plan_Start_dt in the
	 * px_offering_details table.
	 */
	protected Date promotionPlanStartDt;

	/**
	 * This attribute maps to the column Promotion_Plan_end_Dt in the
	 * px_offering_details table.
	 */
	protected Date promotionPlanEndDt;

	/**
	 * This attribute maps to the column Accumulation_Flag in the
	 * px_offering_details table.
	 */
	protected int accumulationFlag;

	/**
	 * This attribute represents whether the primitive attribute
	 * accumulationFlag is null.
	 */
	protected boolean accumulationFlagNull = true;

	/**
	 * This attribute maps to the column Bonus_Validity in the
	 * px_offering_details table.
	 */
	protected int bonusValidity;

	/**
	 * This attribute represents whether the primitive attribute bonusValidity
	 * is null.
	 */
	protected boolean bonusValidityNull = true;

	/**
	 * This attribute maps to the column Sub_Send_SMS_Flag in the
	 * px_offering_details table.
	 */
	protected int subSendSmsFlag;

	/**
	 * This attribute represents whether the primitive attribute subSendSmsFlag
	 * is null.
	 */
	protected boolean subSendSmsFlagNull = true;

	/**
	 * This attribute maps to the column DWH_Entry_Date in the
	 * px_offering_details table.
	 */
	protected Date dwhEntryDate;

	/**
	 * This attribute maps to the column promotion_plan_duration in the
	 * px_offering_details table.
	 */
	protected Integer promotionPlanDuration;

	/**
	 * This attribute represents whether the primitive attribute
	 * promotionPlanDuration is null.
	 */
	protected boolean promotionPlanDurationNull = true;

	/**
	 * This attribute maps to the column is_informative in the
	 * px_offering_details table.
	 */
	protected int isInformative;

	/**
	 * This attribute represents whether the primitive attribute isInformative
	 * is null.
	 */
	protected boolean isInformativeNull = true;

	/**
	 * This attribute maps to the column Granting_mechanism in the
	 * px_offering_details table.
	 */
	protected int grantingMechanism;

	/**
	 * This attribute represents whether the primitive attribute
	 * grantingMechanism is null.
	 */
	protected boolean grantingMechanismNull = true;

	/**
	 * This attribute maps to the column Multiple_Threshold_Flag in the
	 * px_offering_details table.
	 */
	protected int multipleThresholdFlag;

	/**
	 * This attribute represents whether the primitive attribute
	 * multipleThresholdFlag is null.
	 */
	protected boolean multipleThresholdFlagNull = true;

	/**
	 * This attribute maps to the column Commercial_service_EnDesc in the
	 * px_offering_details table.
	 */
	protected String commercialServiceEndesc;

	/**
	 * This attribute maps to the column Commercial_service_ArDesc in the
	 * px_offering_details table.
	 */
	protected String commercialServiceArdesc;

	/**
	 * This attribute maps to the column Resource_Type in the
	 * px_offering_details table.
	 */
	protected String resourceType;

	/**
	 * This attribute maps to the column OPTIN_SCRIPT_AR in the
	 * px_offering_details table.
	 */
	protected String optinScriptAr;

	/**
	 * This attribute maps to the column OPTIN_SCRIPT_EN in the
	 * px_offering_details table.
	 */
	protected String optinScriptEn;

	/**
	 * Method 'PxOfferingDetails'
	 * 
	 */

	protected int accumlationDuration;

	protected int bonusTypeFlag;

	private int ratePlan;
	
	private int salefny;
	private int settlmentOffer;
	
	
	
	private Integer validRenewalPeriod;
	
	
	public PxOfferingDetails() {
	}

	/**
	 * Method 'getOfferingId'
	 * 
	 * @return int
	 */
	public int getOfferingId() {
		return offeringId;
	}

	/**
	 * Method 'setOfferingId'
	 * 
	 * @param offeringId
	 */
	public void setOfferingId(int offeringId) {
		this.offeringId = offeringId;
		this.offeringIdNull = false;
	}

	/**
	 * Method 'setOfferingIdNull'
	 * 
	 * @param value
	 */
	public void setOfferingIdNull(boolean value) {
		this.offeringIdNull = value;
	}

	/**
	 * Method 'isOfferingIdNull'
	 * 
	 * @return boolean
	 */
	public boolean isOfferingIdNull() {
		return offeringIdNull;
	}

	/**
	 * Method 'getOfferingName'
	 * 
	 * @return String
	 */
	public String getOfferingName() {
		return offeringName;
	}

	/**
	 * Method 'setOfferingName'
	 * 
	 * @param offeringName
	 */
	public void setOfferingName(String offeringName) {
		this.offeringName = offeringName;
	}

	/**
	 * Method 'getOfferingStartDt'
	 * 
	 * @return Date
	 */
	public Date getOfferingStartDt() {
		return offeringStartDt;
	}

	/**
	 * Method 'setOfferingStartDt'
	 * 
	 * @param offeringStartDt
	 */
	public void setOfferingStartDt(Date offeringStartDt) {
		this.offeringStartDt = offeringStartDt;
	}

	/**
	 * Method 'getOfferingEndDt'
	 * 
	 * @return Date
	 */
	public Date getOfferingEndDt() {
		return offeringEndDt;
	}

	/**
	 * Method 'setOfferingEndDt'
	 * 
	 * @param offeringEndDt
	 */
	public void setOfferingEndDt(Date offeringEndDt) {
		this.offeringEndDt = offeringEndDt;
	}

	/**
	 * Method 'getOfferingDuration'
	 * 
	 * @return int
	 */
	public int getOfferingDuration() {
		return offeringDuration;
	}

	/**
	 * Method 'setOfferingDuration'
	 * 
	 * @param offeringDuration
	 */
	public void setOfferingDuration(int offeringDuration) {
		this.offeringDuration = offeringDuration;
		this.offeringDurationNull = false;
	}

	/**
	 * Method 'setOfferingDurationNull'
	 * 
	 * @param value
	 */
	public void setOfferingDurationNull(boolean value) {
		this.offeringDurationNull = value;
	}

	/**
	 * Method 'isOfferingDurationNull'
	 * 
	 * @return boolean
	 */
	public boolean isOfferingDurationNull() {
		return offeringDurationNull;
	}

	/**
	 * Method 'getOptInOfferingDuration'
	 * 
	 * @return int
	 */
	public int getOptInOfferingDuration() {
		return optInOfferingDuration;
	}

	/**
	 * Method 'setOptInOfferingDuration'
	 * 
	 * @param optInOfferingDuration
	 */
	public void setOptInOfferingDuration(int optInOfferingDuration) {
		this.optInOfferingDuration = optInOfferingDuration;
		this.optInOfferingDurationNull = false;
	}

	/**
	 * Method 'setOptInOfferingDurationNull'
	 * 
	 * @param value
	 */
	public void setOptInOfferingDurationNull(boolean value) {
		this.optInOfferingDurationNull = value;
	}

	/**
	 * Method 'isOptInOfferingDurationNull'
	 * 
	 * @return boolean
	 */
	public boolean isOptInOfferingDurationNull() {
		return optInOfferingDurationNull;
	}

	/**
	 * Method 'getSssId'
	 * 
	 * @return int
	 */
	public int getSssId() {
		return sssId;
	}

	/**
	 * Method 'setSssId'
	 * 
	 * @param sssId
	 */
	public void setSssId(int sssId) {
		this.sssId = sssId;
		this.sssIdNull = false;
	}

	/**
	 * Method 'setSssIdNull'
	 * 
	 * @param value
	 */
	public void setSssIdNull(boolean value) {
		this.sssIdNull = value;
	}

	/**
	 * Method 'isSssIdNull'
	 * 
	 * @return boolean
	 */
	public boolean isSssIdNull() {
		return sssIdNull;
	}

	/**
	 * Method 'getSssName'
	 * 
	 * @return String
	 */
	public String getSssName() {
		return sssName;
	}

	/**
	 * Method 'setSssName'
	 * 
	 * @param sssName
	 */
	public void setSssName(String sssName) {
		this.sssName = sssName;
	}

	/**
	 * Method 'getShortCodeNum'
	 * 
	 * @return String
	 */
	public String getShortCodeNum() {
		return shortCodeNum;
	}

	/**
	 * Method 'setShortCodeNum'
	 * 
	 * @param shortCodeNum
	 */
	public void setShortCodeNum(String shortCodeNum) {
		this.shortCodeNum = shortCodeNum;
	}

	/**
	 * Method 'getOfferingCategory'
	 * 
	 * @return String
	 */
	public String getOfferingCategory() {
		return offeringCategory;
	}

	/**
	 * Method 'setOfferingCategory'
	 * 
	 * @param offeringCategory
	 */
	public void setOfferingCategory(String offeringCategory) {
		this.offeringCategory = offeringCategory;
	}

	/**
	 * Method 'getOfferPriority'
	 * 
	 * @return int
	 */
	public int getOfferPriority() {
		return offerPriority;
	}

	/**
	 * Method 'setOfferPriority'
	 * 
	 * @param offerPriority
	 */
	public void setOfferPriority(int offerPriority) {
		this.offerPriority = offerPriority;
		this.offerPriorityNull = false;
	}

	/**
	 * Method 'setOfferPriorityNull'
	 * 
	 * @param value
	 */
	public void setOfferPriorityNull(boolean value) {
		this.offerPriorityNull = value;
	}

	/**
	 * Method 'isOfferPriorityNull'
	 * 
	 * @return boolean
	 */
	public boolean isOfferPriorityNull() {
		return offerPriorityNull;
	}

	/**
	 * Method 'getOfferingBits'
	 * 
	 * @return String
	 */
	public String getOfferingBits() {
		return offeringBits;
	}

	/**
	 * Method 'setOfferingBits'
	 * 
	 * @param offeringBits
	 */
	public void setOfferingBits(String offeringBits) {
		this.offeringBits = offeringBits;
	}

	/**
	 * Method 'getOfferingVal'
	 * 
	 * @return int
	 */
	public int getOfferingVal() {
		return offeringVal;
	}

	/**
	 * Method 'setOfferingVal'
	 * 
	 * @param offeringVal
	 */
	public void setOfferingVal(int offeringVal) {
		this.offeringVal = offeringVal;
		this.offeringValNull = false;
	}

	/**
	 * Method 'setOfferingValNull'
	 * 
	 * @param value
	 */
	public void setOfferingValNull(boolean value) {
		this.offeringValNull = value;
	}

	/**
	 * Method 'isOfferingValNull'
	 * 
	 * @return boolean
	 */
	public boolean isOfferingValNull() {
		return offeringValNull;
	}

	/**
	 * Method 'getOfferingMask'
	 * 
	 * @return int
	 */
	public int getOfferingMask() {
		return offeringMask;
	}

	/**
	 * Method 'setOfferingMask'
	 * 
	 * @param offeringMask
	 */
	public void setOfferingMask(int offeringMask) {
		this.offeringMask = offeringMask;
		this.offeringMaskNull = false;
	}

	/**
	 * Method 'setOfferingMaskNull'
	 * 
	 * @param value
	 */
	public void setOfferingMaskNull(boolean value) {
		this.offeringMaskNull = value;
	}

	/**
	 * Method 'isOfferingMaskNull'
	 * 
	 * @return boolean
	 */
	public boolean isOfferingMaskNull() {
		return offeringMaskNull;
	}

	/**
	 * Method 'getInOfferTypeId'
	 * 
	 * @return int
	 */
	public int getInOfferTypeId() {
		return inOfferTypeId;
	}

	/**
	 * Method 'setInOfferTypeId'
	 * 
	 * @param inOfferTypeId
	 */
	public void setInOfferTypeId(int inOfferTypeId) {
		this.inOfferTypeId = inOfferTypeId;
		this.inOfferTypeIdNull = false;
	}

	/**
	 * Method 'setInOfferTypeIdNull'
	 * 
	 * @param value
	 */
	public void setInOfferTypeIdNull(boolean value) {
		this.inOfferTypeIdNull = value;
	}

	/**
	 * Method 'isInOfferTypeIdNull'
	 * 
	 * @return boolean
	 */
	public boolean isInOfferTypeIdNull() {
		return inOfferTypeIdNull;
	}

	/**
	 * Method 'getOfferingEngDesc'
	 * 
	 * @return String
	 */
	public String getOfferingEngDesc() {
		return offeringEngDesc;
	}

	/**
	 * Method 'setOfferingEngDesc'
	 * 
	 * @param offeringEngDesc
	 */
	public void setOfferingEngDesc(String offeringEngDesc) {
		this.offeringEngDesc = offeringEngDesc;
	}

	/**
	 * Method 'getOfferingArDesc'
	 * 
	 * @return String
	 */
	public String getOfferingArDesc() {
		return offeringArDesc;
	}

	/**
	 * Method 'setOfferingArDesc'
	 * 
	 * @param offeringArDesc
	 */
	public void setOfferingArDesc(String offeringArDesc) {
		this.offeringArDesc = offeringArDesc;
	}

	/**
	 * Method 'getOfferingLineType'
	 * 
	 * @return String
	 */
	public String getOfferingLineType() {
		return offeringLineType;
	}

	/**
	 * Method 'setOfferingLineType'
	 * 
	 * @param offeringLineType
	 */
	public void setOfferingLineType(String offeringLineType) {
		this.offeringLineType = offeringLineType;
	}

	/**
	 * Method 'getOfferHiddenFlag'
	 * 
	 * @return String
	 */
	public String getOfferHiddenFlag() {
		return offerHiddenFlag;
	}

	/**
	 * Method 'setOfferHiddenFlag'
	 * 
	 * @param offerHiddenFlag
	 */
	public void setOfferHiddenFlag(String offerHiddenFlag) {
		this.offerHiddenFlag = offerHiddenFlag;
	}

	/**
	 * Method 'getOfferingShortDesc'
	 * 
	 * @return String
	 */
	public String getOfferingShortDesc() {
		return offeringShortDesc;
	}

	/**
	 * Method 'setOfferingShortDesc'
	 * 
	 * @param offeringShortDesc
	 */
	public void setOfferingShortDesc(String offeringShortDesc) {
		this.offeringShortDesc = offeringShortDesc;
	}

	/**
	 * Method 'getOfferingLongDesc'
	 * 
	 * @return String
	 */
	public String getOfferingLongDesc() {
		return offeringLongDesc;
	}

	/**
	 * Method 'setOfferingLongDesc'
	 * 
	 * @param offeringLongDesc
	 */
	public void setOfferingLongDesc(String offeringLongDesc) {
		this.offeringLongDesc = offeringLongDesc;
	}

	/**
	 * Method 'getOnlineFlag'
	 * 
	 * @return int
	 */
	public int getOnlineFlag() {
		return onlineFlag;
	}

	/**
	 * Method 'setOnlineFlag'
	 * 
	 * @param onlineFlag
	 */
	public void setOnlineFlag(int onlineFlag) {
		this.onlineFlag = onlineFlag;
		this.onlineFlagNull = false;
	}

	/**
	 * Method 'setOnlineFlagNull'
	 * 
	 * @param value
	 */
	public void setOnlineFlagNull(boolean value) {
		this.onlineFlagNull = value;
	}

	/**
	 * Method 'isOnlineFlagNull'
	 * 
	 * @return boolean
	 */
	public boolean isOnlineFlagNull() {
		return onlineFlagNull;
	}

	/**
	 * Method 'getOfferOptinFees'
	 * 
	 * @return float
	 */
	public float getOfferOptinFees() {
		return offerOptinFees;
	}

	/**
	 * Method 'setOfferOptinFees'
	 * 
	 * @param offerOptinFees
	 */
	public void setOfferOptinFees(float offerOptinFees) {
		this.offerOptinFees = offerOptinFees;
		this.offerOptinFeesNull = false;
	}

	/**
	 * Method 'setOfferOptinFeesNull'
	 * 
	 * @param value
	 */
	public void setOfferOptinFeesNull(boolean value) {
		this.offerOptinFeesNull = value;
	}

	/**
	 * Method 'isOfferOptinFeesNull'
	 * 
	 * @return boolean
	 */
	public boolean isOfferOptinFeesNull() {
		return offerOptinFeesNull;
	}

	/**
	 * Method 'getPromotionPlanId'
	 * 
	 * @return int
	 */
	public int getPromotionPlanId() {
		return promotionPlanId;
	}

	/**
	 * Method 'setPromotionPlanId'
	 * 
	 * @param promotionPlanId
	 */
	public void setPromotionPlanId(int promotionPlanId) {
		this.promotionPlanId = promotionPlanId;
		this.promotionPlanIdNull = false;
	}

	/**
	 * Method 'setPromotionPlanIdNull'
	 * 
	 * @param value
	 */
	public void setPromotionPlanIdNull(boolean value) {
		this.promotionPlanIdNull = value;
	}

	/**
	 * Method 'isPromotionPlanIdNull'
	 * 
	 * @return boolean
	 */
	public boolean isPromotionPlanIdNull() {
		return promotionPlanIdNull;
	}

	/**
	 * Method 'getPromotionPlanStartDt'
	 * 
	 * @return Date
	 */
	public Date getPromotionPlanStartDt() {
		return promotionPlanStartDt;
	}

	/**
	 * Method 'setPromotionPlanStartDt'
	 * 
	 * @param promotionPlanStartDt
	 */
	public void setPromotionPlanStartDt(Date promotionPlanStartDt) {
		this.promotionPlanStartDt = promotionPlanStartDt;
	}

	/**
	 * Method 'getPromotionPlanEndDt'
	 * 
	 * @return Date
	 */
	public Date getPromotionPlanEndDt() {
		return promotionPlanEndDt;
	}

	/**
	 * Method 'setPromotionPlanEndDt'
	 * 
	 * @param promotionPlanEndDt
	 */
	public void setPromotionPlanEndDt(Date promotionPlanEndDt) {
		this.promotionPlanEndDt = promotionPlanEndDt;
	}

	/**
	 * Method 'getAccumulationFlag'
	 * 
	 * @return int
	 */
	public int getAccumulationFlag() {
		return accumulationFlag;
	}

	/**
	 * Method 'setAccumulationFlag'
	 * 
	 * @param accumulationFlag
	 */
	public void setAccumulationFlag(int accumulationFlag) {
		this.accumulationFlag = accumulationFlag;
		this.accumulationFlagNull = false;
	}

	/**
	 * Method 'setAccumulationFlagNull'
	 * 
	 * @param value
	 */
	public void setAccumulationFlagNull(boolean value) {
		this.accumulationFlagNull = value;
	}

	/**
	 * Method 'isAccumulationFlagNull'
	 * 
	 * @return boolean
	 */
	public boolean isAccumulationFlagNull() {
		return accumulationFlagNull;
	}

	/**
	 * Method 'getBonusValidity'
	 * 
	 * @return int
	 */
	public int getBonusValidity() {
		return bonusValidity;
	}

	/**
	 * Method 'setBonusValidity'
	 * 
	 * @param bonusValidity
	 */
	public void setBonusValidity(int bonusValidity) {
		this.bonusValidity = bonusValidity;
		this.bonusValidityNull = false;
	}

	/**
	 * Method 'setBonusValidityNull'
	 * 
	 * @param value
	 */
	public void setBonusValidityNull(boolean value) {
		this.bonusValidityNull = value;
	}

	/**
	 * Method 'isBonusValidityNull'
	 * 
	 * @return boolean
	 */
	public boolean isBonusValidityNull() {
		return bonusValidityNull;
	}

	/**
	 * Method 'getSubSendSmsFlag'
	 * 
	 * @return int
	 */
	public int getSubSendSmsFlag() {
		return subSendSmsFlag;
	}

	/**
	 * Method 'setSubSendSmsFlag'
	 * 
	 * @param subSendSmsFlag
	 */
	public void setSubSendSmsFlag(int subSendSmsFlag) {
		this.subSendSmsFlag = subSendSmsFlag;
		this.subSendSmsFlagNull = false;
	}

	/**
	 * Method 'setSubSendSmsFlagNull'
	 * 
	 * @param value
	 */
	public void setSubSendSmsFlagNull(boolean value) {
		this.subSendSmsFlagNull = value;
	}

	/**
	 * Method 'isSubSendSmsFlagNull'
	 * 
	 * @return boolean
	 */
	public boolean isSubSendSmsFlagNull() {
		return subSendSmsFlagNull;
	}

	/**
	 * Method 'getDwhEntryDate'
	 * 
	 * @return Date
	 */
	public Date getDwhEntryDate() {
		return dwhEntryDate;
	}

	/**
	 * Method 'setDwhEntryDate'
	 * 
	 * @param dwhEntryDate
	 */
	public void setDwhEntryDate(Date dwhEntryDate) {
		this.dwhEntryDate = dwhEntryDate;
	}

	/**
	 * Method 'getPromotionPlanDuration'
	 * 
	 * @return int
	 */
	public Integer getPromotionPlanDuration() {
		return promotionPlanDuration;
	}

	/**
	 * Method 'setPromotionPlanDuration'
	 * 
	 * @param promotionPlanDuration
	 */
	public void setPromotionPlanDuration(Integer promotionPlanDuration) {
		this.promotionPlanDuration = promotionPlanDuration;
		this.promotionPlanDurationNull = false;
	}

	/**
	 * Method 'setPromotionPlanDurationNull'
	 * 
	 * @param value
	 */
	public void setPromotionPlanDurationNull(boolean value) {
		this.promotionPlanDurationNull = value;
	}

	/**
	 * Method 'isPromotionPlanDurationNull'
	 * 
	 * @return boolean
	 */
	public boolean isPromotionPlanDurationNull() {
		return promotionPlanDurationNull;
	}

	/**
	 * Method 'getIsInformative'
	 * 
	 * @return int
	 */
	public int getIsInformative() {
		return isInformative;
	}

	/**
	 * Method 'setIsInformative'
	 * 
	 * @param isInformative
	 */
	public void setIsInformative(int isInformative) {
		this.isInformative = isInformative;
		this.isInformativeNull = false;
	}

	/**
	 * Method 'setIsInformativeNull'
	 * 
	 * @param value
	 */
	public void setIsInformativeNull(boolean value) {
		this.isInformativeNull = value;
	}

	/**
	 * Method 'isIsInformativeNull'
	 * 
	 * @return boolean
	 */
	public boolean isIsInformativeNull() {
		return isInformativeNull;
	}

	/**
	 * Method 'getGrantingMechanism'
	 * 
	 * @return int
	 */
	public int getGrantingMechanism() {
		return grantingMechanism;
	}

	/**
	 * Method 'setGrantingMechanism'
	 * 
	 * @param grantingMechanism
	 */
	public void setGrantingMechanism(int grantingMechanism) {
		this.grantingMechanism = grantingMechanism;
		this.grantingMechanismNull = false;
	}

	/**
	 * Method 'setGrantingMechanismNull'
	 * 
	 * @param value
	 */
	public void setGrantingMechanismNull(boolean value) {
		this.grantingMechanismNull = value;
	}

	/**
	 * Method 'isGrantingMechanismNull'
	 * 
	 * @return boolean
	 */
	public boolean isGrantingMechanismNull() {
		return grantingMechanismNull;
	}

	/**
	 * Method 'getMultipleThresholdFlag'
	 * 
	 * @return int
	 */
	public int getMultipleThresholdFlag() {
		return multipleThresholdFlag;
	}

	/**
	 * Method 'setMultipleThresholdFlag'
	 * 
	 * @param multipleThresholdFlag
	 */
	public void setMultipleThresholdFlag(int multipleThresholdFlag) {
		this.multipleThresholdFlag = multipleThresholdFlag;
		this.multipleThresholdFlagNull = false;
	}

	/**
	 * Method 'setMultipleThresholdFlagNull'
	 * 
	 * @param value
	 */
	public void setMultipleThresholdFlagNull(boolean value) {
		this.multipleThresholdFlagNull = value;
	}

	/**
	 * Method 'isMultipleThresholdFlagNull'
	 * 
	 * @return boolean
	 */
	public boolean isMultipleThresholdFlagNull() {
		return multipleThresholdFlagNull;
	}

	/**
	 * Method 'getCommercialServiceEndesc'
	 * 
	 * @return String
	 */
	public String getCommercialServiceEndesc() {
		return commercialServiceEndesc;
	}

	/**
	 * Method 'setCommercialServiceEndesc'
	 * 
	 * @param commercialServiceEndesc
	 */
	public void setCommercialServiceEndesc(String commercialServiceEndesc) {
		this.commercialServiceEndesc = commercialServiceEndesc;
	}

	/**
	 * Method 'getCommercialServiceArdesc'
	 * 
	 * @return String
	 */
	public String getCommercialServiceArdesc() {
		return commercialServiceArdesc;
	}

	/**
	 * Method 'setCommercialServiceArdesc'
	 * 
	 * @param commercialServiceArdesc
	 */
	public void setCommercialServiceArdesc(String commercialServiceArdesc) {
		this.commercialServiceArdesc = commercialServiceArdesc;
	}

	/**
	 * Method 'getResourceType'
	 * 
	 * @return String
	 */
	public String getResourceType() {
		return resourceType;
	}

	/**
	 * Method 'setResourceType'
	 * 
	 * @param resourceType
	 */
	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	/**
	 * Method 'getOptinScriptAr'
	 * 
	 * @return String
	 */
	public String getOptinScriptAr() {
		return optinScriptAr;
	}

	/**
	 * Method 'setOptinScriptAr'
	 * 
	 * @param optinScriptAr
	 */
	public void setOptinScriptAr(String optinScriptAr) {
		this.optinScriptAr = optinScriptAr;
	}

	/**
	 * Method 'getOptinScriptEn'
	 * 
	 * @return String
	 */
	public String getOptinScriptEn() {
		return optinScriptEn;
	}

	/**
	 * Method 'setOptinScriptEn'
	 * 
	 * @param optinScriptEn
	 */
	public void setOptinScriptEn(String optinScriptEn) {
		this.optinScriptEn = optinScriptEn;
	}

	public int getAccumlationDuration() {
		return accumlationDuration;
	}

	public void setAccumlationDuration(int accumlationDuration) {
		this.accumlationDuration = accumlationDuration;
	}

	public int getBonusTypeFlag() {
		return bonusTypeFlag;
	}

	public void setBonusTypeFlag(int bonusTypeFlag) {
		this.bonusTypeFlag = bonusTypeFlag;
	}

	public Integer getRedemptionWindow() {
		return redemptionWindow;
	}

	public void setRedemptionWindow(Integer redemptionWindow) {
		this.redemptionWindow = redemptionWindow;
	}

	/**
	 * Method 'equals'
	 * 
	 * @param _other
	 * @return boolean
	 */
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public boolean equals(Object _other) {
		if (_other == null) {
			return false;
		}

		if (_other == this) {
			return true;
		}

		if (!(_other instanceof PxOfferingDetails)) {
			return false;
		}

		final PxOfferingDetails _cast = (PxOfferingDetails) _other;
		if (offeringId != _cast.offeringId) {
			return false;
		}

		/*
		 * if (offeringIdNull != _cast.offeringIdNull) { return false; }
		 * 
		 * if (offeringName == null ? _cast.offeringName != offeringName :
		 * !offeringName.equals(_cast.offeringName)) { return false; }
		 * 
		 * if (offeringStartDt == null ? _cast.offeringStartDt !=
		 * offeringStartDt : !offeringStartDt.equals(_cast.offeringStartDt)) {
		 * return false; }
		 * 
		 * if (offeringEndDt == null ? _cast.offeringEndDt != offeringEndDt :
		 * !offeringEndDt.equals(_cast.offeringEndDt)) { return false; }
		 * 
		 * if (offeringDuration != _cast.offeringDuration) { return false; }
		 * 
		 * if (offeringDurationNull != _cast.offeringDurationNull) { return
		 * false; }
		 * 
		 * if (optInOfferingDuration != _cast.optInOfferingDuration) { return
		 * false; }
		 * 
		 * if (optInOfferingDurationNull != _cast.optInOfferingDurationNull) {
		 * return false; }
		 * 
		 * if (sssId != _cast.sssId) { return false; }
		 * 
		 * if (sssIdNull != _cast.sssIdNull) { return false; }
		 * 
		 * if (sssName == null ? _cast.sssName != sssName :
		 * !sssName.equals(_cast.sssName)) { return false; }
		 * 
		 * if (shortCodeNum == null ? _cast.shortCodeNum != shortCodeNum :
		 * !shortCodeNum.equals(_cast.shortCodeNum)) { return false; }
		 * 
		 * if (offeringCategory == null ? _cast.offeringCategory !=
		 * offeringCategory : !offeringCategory.equals(_cast.offeringCategory))
		 * { return false; }
		 * 
		 * if (offerPriority != _cast.offerPriority) { return false; }
		 * 
		 * if (offerPriorityNull != _cast.offerPriorityNull) { return false; }
		 * 
		 * if (offeringBits == null ? _cast.offeringBits != offeringBits :
		 * !offeringBits.equals(_cast.offeringBits)) { return false; }
		 * 
		 * if (offeringVal != _cast.offeringVal) { return false; }
		 * 
		 * if (offeringValNull != _cast.offeringValNull) { return false; }
		 * 
		 * if (offeringMask != _cast.offeringMask) { return false; }
		 * 
		 * if (offeringMaskNull != _cast.offeringMaskNull) { return false; }
		 * 
		 * if (inOfferTypeId != _cast.inOfferTypeId) { return false; }
		 * 
		 * if (inOfferTypeIdNull != _cast.inOfferTypeIdNull) { return false; }
		 * 
		 * if (offeringEngDesc == null ? _cast.offeringEngDesc !=
		 * offeringEngDesc : !offeringEngDesc.equals(_cast.offeringEngDesc)) {
		 * return false; }
		 * 
		 * if (offeringArDesc == null ? _cast.offeringArDesc != offeringArDesc :
		 * !offeringArDesc.equals(_cast.offeringArDesc)) { return false; }
		 * 
		 * if (offeringLineType == null ? _cast.offeringLineType !=
		 * offeringLineType : !offeringLineType.equals(_cast.offeringLineType))
		 * { return false; }
		 * 
		 * if (offerHiddenFlag == null ? _cast.offerHiddenFlag !=
		 * offerHiddenFlag : !offerHiddenFlag.equals(_cast.offerHiddenFlag)) {
		 * return false; }
		 * 
		 * if (offeringShortDesc == null ? _cast.offeringShortDesc !=
		 * offeringShortDesc :
		 * !offeringShortDesc.equals(_cast.offeringShortDesc)) { return false; }
		 * 
		 * if (offeringLongDesc == null ? _cast.offeringLongDesc !=
		 * offeringLongDesc : !offeringLongDesc.equals(_cast.offeringLongDesc))
		 * { return false; }
		 * 
		 * if (onlineFlag != _cast.onlineFlag) { return false; }
		 * 
		 * if (onlineFlagNull != _cast.onlineFlagNull) { return false; }
		 * 
		 * if (offerOptinFees != _cast.offerOptinFees) { return false; }
		 * 
		 * if (offerOptinFeesNull != _cast.offerOptinFeesNull) { return false; }
		 * 
		 * if (promotionPlanId != _cast.promotionPlanId) { return false; }
		 * 
		 * if (promotionPlanIdNull != _cast.promotionPlanIdNull) { return false;
		 * }
		 * 
		 * if (promotionPlanStartDt == null ? _cast.promotionPlanStartDt !=
		 * promotionPlanStartDt :
		 * !promotionPlanStartDt.equals(_cast.promotionPlanStartDt)) { return
		 * false; }
		 * 
		 * if (promotionPlanEndDt == null ? _cast.promotionPlanEndDt !=
		 * promotionPlanEndDt :
		 * !promotionPlanEndDt.equals(_cast.promotionPlanEndDt)) { return false;
		 * }
		 * 
		 * if (accumulationFlag != _cast.accumulationFlag) { return false; }
		 * 
		 * if (accumulationFlagNull != _cast.accumulationFlagNull) { return
		 * false; }
		 * 
		 * if (bonusValidity != _cast.bonusValidity) { return false; }
		 * 
		 * if (bonusValidityNull != _cast.bonusValidityNull) { return false; }
		 * 
		 * if (subSendSmsFlag != _cast.subSendSmsFlag) { return false; }
		 * 
		 * if (subSendSmsFlagNull != _cast.subSendSmsFlagNull) { return false; }
		 * 
		 * if (dwhEntryDate == null ? _cast.dwhEntryDate != dwhEntryDate :
		 * !dwhEntryDate.equals(_cast.dwhEntryDate)) { return false; }
		 * 
		 * if (promotionPlanDuration != _cast.promotionPlanDuration) { return
		 * false; }
		 * 
		 * if (promotionPlanDurationNull != _cast.promotionPlanDurationNull) {
		 * return false; }
		 * 
		 * if (isInformative != _cast.isInformative) { return false; }
		 * 
		 * if (isInformativeNull != _cast.isInformativeNull) { return false; }
		 * 
		 * if (grantingMechanism != _cast.grantingMechanism) { return false; }
		 * 
		 * if (grantingMechanismNull != _cast.grantingMechanismNull) { return
		 * false; }
		 * 
		 * if (multipleThresholdFlag != _cast.multipleThresholdFlag) { return
		 * false; }
		 * 
		 * if (multipleThresholdFlagNull != _cast.multipleThresholdFlagNull) {
		 * return false; }
		 * 
		 * if (commercialServiceEndesc == null ? _cast.commercialServiceEndesc
		 * != commercialServiceEndesc :
		 * !commercialServiceEndesc.equals(_cast.commercialServiceEndesc)) {
		 * return false; }
		 * 
		 * if (commercialServiceArdesc == null ? _cast.commercialServiceArdesc
		 * != commercialServiceArdesc :
		 * !commercialServiceArdesc.equals(_cast.commercialServiceArdesc)) {
		 * return false; }
		 * 
		 * if (resourceType == null ? _cast.resourceType != resourceType :
		 * !resourceType.equals(_cast.resourceType)) { return false; }
		 * 
		 * if (optinScriptAr == null ? _cast.optinScriptAr != optinScriptAr :
		 * !optinScriptAr.equals(_cast.optinScriptAr)) { return false; }
		 * 
		 * if (optinScriptEn == null ? _cast.optinScriptEn != optinScriptEn :
		 * !optinScriptEn.equals(_cast.optinScriptEn)) { return false; }
		 */
		return true;
	}

	public int getRatePlan() {
		return ratePlan;
	}

	public void setRatePlan(int ratePlan) {
		this.ratePlan = ratePlan;
	}

	public int getSalefny() {
		return salefny;
	}

	public void setSalefny(int salefny) {
		this.salefny = salefny;
	}

	
	
	
	public Integer getValidRenewalPeriod() {
		return validRenewalPeriod;
	}

	public void setValidRenewalPeriod(Integer validRenewalPeriod) {
		this.validRenewalPeriod = validRenewalPeriod;
	}
	
	

	

	public int getSettlmentOffer() {
		return settlmentOffer;
	}

	public void setSettlmentOffer(int settlmentOffer) {
		this.settlmentOffer = settlmentOffer;
	}

	/**
	 * Method 'hashCode'
	 * 
	 * @return int
	 */
	public int hashCode() {
		int _hashCode = 0;
		_hashCode = 29 * _hashCode + offeringId;
		_hashCode = 29 * _hashCode + (offeringIdNull ? 1 : 0);
		if (offeringName != null) {
			_hashCode = 29 * _hashCode + offeringName.hashCode();
		}

		if (offeringStartDt != null) {
			_hashCode = 29 * _hashCode + offeringStartDt.hashCode();
		}

		if (offeringEndDt != null) {
			_hashCode = 29 * _hashCode + offeringEndDt.hashCode();
		}

		_hashCode = 29 * _hashCode + offeringDuration;
		_hashCode = 29 * _hashCode + (offeringDurationNull ? 1 : 0);
		_hashCode = 29 * _hashCode + optInOfferingDuration;
		_hashCode = 29 * _hashCode + (optInOfferingDurationNull ? 1 : 0);
		_hashCode = 29 * _hashCode + sssId;
		_hashCode = 29 * _hashCode + (sssIdNull ? 1 : 0);
		if (sssName != null) {
			_hashCode = 29 * _hashCode + sssName.hashCode();
		}

		if (shortCodeNum != null) {
			_hashCode = 29 * _hashCode + shortCodeNum.hashCode();
		}

		if (offeringCategory != null) {
			_hashCode = 29 * _hashCode + offeringCategory.hashCode();
		}

		_hashCode = 29 * _hashCode + offerPriority;
		_hashCode = 29 * _hashCode + (offerPriorityNull ? 1 : 0);
		if (offeringBits != null) {
			_hashCode = 29 * _hashCode + offeringBits.hashCode();
		}

		_hashCode = 29 * _hashCode + offeringVal;
		_hashCode = 29 * _hashCode + (offeringValNull ? 1 : 0);
		_hashCode = 29 * _hashCode + offeringMask;
		_hashCode = 29 * _hashCode + (offeringMaskNull ? 1 : 0);
		_hashCode = 29 * _hashCode + inOfferTypeId;
		_hashCode = 29 * _hashCode + (inOfferTypeIdNull ? 1 : 0);
		if (offeringEngDesc != null) {
			_hashCode = 29 * _hashCode + offeringEngDesc.hashCode();
		}

		if (offeringArDesc != null) {
			_hashCode = 29 * _hashCode + offeringArDesc.hashCode();
		}

		if (offeringLineType != null) {
			_hashCode = 29 * _hashCode + offeringLineType.hashCode();
		}

		if (offerHiddenFlag != null) {
			_hashCode = 29 * _hashCode + offerHiddenFlag.hashCode();
		}

		if (offeringShortDesc != null) {
			_hashCode = 29 * _hashCode + offeringShortDesc.hashCode();
		}

		if (offeringLongDesc != null) {
			_hashCode = 29 * _hashCode + offeringLongDesc.hashCode();
		}

		_hashCode = 29 * _hashCode + onlineFlag;
		_hashCode = 29 * _hashCode + (onlineFlagNull ? 1 : 0);
		_hashCode = 29 * _hashCode + Float.floatToIntBits(offerOptinFees);
		_hashCode = 29 * _hashCode + (offerOptinFeesNull ? 1 : 0);
		_hashCode = 29 * _hashCode + promotionPlanId;
		_hashCode = 29 * _hashCode + (promotionPlanIdNull ? 1 : 0);
		if (promotionPlanStartDt != null) {
			_hashCode = 29 * _hashCode + promotionPlanStartDt.hashCode();
		}

		if (promotionPlanEndDt != null) {
			_hashCode = 29 * _hashCode + promotionPlanEndDt.hashCode();
		}

		_hashCode = 29 * _hashCode + accumulationFlag;
		_hashCode = 29 * _hashCode + (accumulationFlagNull ? 1 : 0);
		_hashCode = 29 * _hashCode + bonusValidity;
		_hashCode = 29 * _hashCode + (bonusValidityNull ? 1 : 0);
		_hashCode = 29 * _hashCode + subSendSmsFlag;
		_hashCode = 29 * _hashCode + (subSendSmsFlagNull ? 1 : 0);
		if (dwhEntryDate != null) {
			_hashCode = 29 * _hashCode + dwhEntryDate.hashCode();
		}

		_hashCode = 29 * _hashCode + promotionPlanDuration;
		_hashCode = 29 * _hashCode + (promotionPlanDurationNull ? 1 : 0);
		_hashCode = 29 * _hashCode + isInformative;
		_hashCode = 29 * _hashCode + (isInformativeNull ? 1 : 0);
		_hashCode = 29 * _hashCode + grantingMechanism;
		_hashCode = 29 * _hashCode + (grantingMechanismNull ? 1 : 0);
		_hashCode = 29 * _hashCode + multipleThresholdFlag;
		_hashCode = 29 * _hashCode + (multipleThresholdFlagNull ? 1 : 0);
		if (commercialServiceEndesc != null) {
			_hashCode = 29 * _hashCode + commercialServiceEndesc.hashCode();
		}

		if (commercialServiceArdesc != null) {
			_hashCode = 29 * _hashCode + commercialServiceArdesc.hashCode();
		}

		if (resourceType != null) {
			_hashCode = 29 * _hashCode + resourceType.hashCode();
		}

		if (optinScriptAr != null) {
			_hashCode = 29 * _hashCode + optinScriptAr.hashCode();
		}

		if (optinScriptEn != null) {
			_hashCode = 29 * _hashCode + optinScriptEn.hashCode();
		}

		return _hashCode;
	}

	/**
	 * Method 'toString'
	 * 
	 * @return String
	 */
	public String toString() {
		StringBuffer ret = new StringBuffer();
		ret.append("com.mycompany.myapp.dto.PxOfferingDetails: ");
		ret.append("offeringId=" + offeringId);
		ret.append(", offeringName=" + offeringName);
		ret.append(", offeringStartDt=" + offeringStartDt);
		ret.append(", offeringEndDt=" + offeringEndDt);
		ret.append(", offeringDuration=" + offeringDuration);
		ret.append(", optInOfferingDuration=" + optInOfferingDuration);
		ret.append(", sssId=" + sssId);
		ret.append(", sssName=" + sssName);
		ret.append(", shortCodeNum=" + shortCodeNum);
		ret.append(", offeringCategory=" + offeringCategory);
		ret.append(", offerPriority=" + offerPriority);
		ret.append(", offeringBits=" + offeringBits);
		ret.append(", offeringVal=" + offeringVal);
		ret.append(", offeringMask=" + offeringMask);
		ret.append(", inOfferTypeId=" + inOfferTypeId);
		ret.append(", offeringEngDesc=" + offeringEngDesc);
		ret.append(", offeringArDesc=" + offeringArDesc);
		ret.append(", offeringLineType=" + offeringLineType);
		ret.append(", offerHiddenFlag=" + offerHiddenFlag);
		ret.append(", offeringShortDesc=" + offeringShortDesc);
		ret.append(", offeringLongDesc=" + offeringLongDesc);
		ret.append(", onlineFlag=" + onlineFlag);
		ret.append(", offerOptinFees=" + offerOptinFees);
		ret.append(", promotionPlanId=" + promotionPlanId);
		ret.append(", promotionPlanStartDt=" + promotionPlanStartDt);
		ret.append(", promotionPlanEndDt=" + promotionPlanEndDt);
		ret.append(", accumulationFlag=" + accumulationFlag);
		ret.append(", bonusValidity=" + bonusValidity);
		ret.append(", subSendSmsFlag=" + subSendSmsFlag);
		ret.append(", dwhEntryDate=" + dwhEntryDate);
		ret.append(", promotionPlanDuration=" + promotionPlanDuration);
		ret.append(", isInformative=" + isInformative);
		ret.append(", grantingMechanism=" + grantingMechanism);
		ret.append(", multipleThresholdFlag=" + multipleThresholdFlag);
		ret.append(", commercialServiceEndesc=" + commercialServiceEndesc);
		ret.append(", commercialServiceArdesc=" + commercialServiceArdesc);
		ret.append(", resourceType=" + resourceType);
		ret.append(", optinScriptAr=" + optinScriptAr);
		ret.append(", optinScriptEn=" + optinScriptEn);
		ret.append(", accumlationDuration=" + accumlationDuration);
		ret.append(", bonusTypeFlag=" + bonusTypeFlag);
		return ret.toString();
	}

	@Override
	public int compareTo(PxOfferingDetails o) {
		if (this.offerPriority < o.getOfferPriority())
			return -1;
		else if (this.offerPriority == o.getOfferPriority())
			return 0;
		else
			return 1;
	}

}
