package com.etisalat.dynamicOffering.models.old;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



import com.etisalat.dynamicOffering.database.trm.entity.OfferingDetails;
import com.etisalat.dynamicOffering.database.trm.entity.ServiceCategory;
import com.etisalat.dynamicOffering.enums.Type;

public class ContradictionBK implements Serializable {

	private TreeNode unSelectedTree;
	private TreeNode selectedTree;

	private TreeNode[] unSelectedNodes;
	private TreeNode[] selectedNodes;

	private List<ServiceCategory> pxServiceCategory;
	private List<OfferingDetails> pxOfferingDetails;

	public ContradictionBK() {
	}

	public ContradictionBK(List<ServiceCategory> pxServiceCategory, List<OfferingDetails> pxOfferingDetails) {
		this.pxServiceCategory = pxServiceCategory;
		this.pxOfferingDetails = pxOfferingDetails;
	}

	public void moveUnselectedToSelected() {

		TreeNode category = null;

		for (TreeNode selectedNode : selectedNodes) {

			
			// check if selected node is category
			if (((Node) selectedNode.getData()).getType() == Type.CAT) {
				// retrieve category from selected tree, returns null if not
				// exists
				category = getChildById(selectedTree, ((Node) selectedNode.getData()).getId());
				// add category with children if not exists
				if (category == null) {
					TreeNode n = new CheckboxTreeNode(new Node(((Node) selectedNode.getData()).getId(), ((Node) selectedNode.getData()).getName(), Type.CAT), selectedTree);
					n.getChildren().addAll(selectedNode.getChildren());
					n.setExpanded(true);
					n.setSelected(false);
					// remove category(including children) from unseleceted tree
					removeChildFromParent(unSelectedTree, selectedNode);

				} else {
					// copy children then remove category
					category.getChildren().addAll(selectedNode.getChildren());
					removeChildFromParent(unSelectedTree, selectedNode);
					if (selectedNode.getChildCount() <= 0) {
						// remove category from unseleceted tree
						removeChildFromParent(unSelectedTree, selectedNode);
					}

				}

				// check if node is offer
			} else if (((Node) selectedNode.getData()).getType() == Type.OFFER) {
				// check if offer category exists in selected tree
				category = getChildById(selectedTree, ((Node) selectedNode.getParent().getData()).getId());
				if (category == null) {
					// add category if not exists
					TreeNode n = new CheckboxTreeNode(
							new Node(((Node) selectedNode.getParent().getData()).getId(), ((Node) selectedNode.getParent().getData()).getName(), Type.CAT), selectedTree);
					// add offer to category
					n.getChildren().add(selectedNode);
					n.setExpanded(true);
					n.setSelected(false);

					// get offer category from unselected tree
					TreeNode offerCategory = getChildById(unSelectedTree, ((Node) selectedNode.getParent().getData()).getId());
					// remove offer from unselected tree
					removeChildFromParent(offerCategory, selectedNode);
					if (offerCategory.getChildCount() <= 0)
						removeChildFromParent(unSelectedTree, offerCategory);
				} else {
					selectedNode.setSelected(false);
					selectedNode.setExpanded(true);
					category.getChildren().add(selectedNode);
					// get offer category from unselected tree
					TreeNode offerCategory = getChildById(unSelectedTree, ((Node) selectedNode.getParent().getData()).getId());
					// remove offer from unselected tree
					if (offerCategory != null)
						removeChildFromParent(offerCategory, selectedNode);
				}
			}

		}
		selectedTree.setExpanded(true);
		selectedNodes = null;
		unSelectedNodes = null;

	}

	public void moveSelectedToUnselected() {

		TreeNode category = null;

		for (TreeNode selectedNode : unSelectedNodes) {

			// check if selected node is category
			if (((Node) selectedNode.getData()).getType() == Type.CAT) {
				// retrieve category, returns null if not exists
				category = getChildById(unSelectedTree, ((Node) selectedNode.getData()).getId());
				// add category with children if not exists
				if (category == null) {
					TreeNode n = new CheckboxTreeNode(new Node(((Node) selectedNode.getData()).getId(), ((Node) selectedNode.getData()).getName(), Type.CAT), unSelectedTree);
					n.getChildren().addAll(selectedNode.getChildren());
					n.setSelected(false);
					n.setExpanded(true);
					// remove category from seleceted tree
					removeChildFromParent(selectedTree, selectedNode);
				} else {
					// copy children then remove category
					category.getChildren().addAll(selectedNode.getChildren());
					removeChildFromParent(selectedTree, selectedNode);
					// remove category from selected tree if empty
					if (selectedNode.getChildCount() <= 0) { // remove
						// category from seleceted tree
						removeChildFromParent(selectedTree, selectedNode);
					}

				}
				// check if node is offer
			} else if (((Node) selectedNode.getData()).getType() == Type.OFFER) {
				// check if category exists
				category = getChildById(unSelectedTree, ((Node) selectedNode.getParent().getData()).getId());
				if (category == null) {
					// add category if not exists
					TreeNode n = new CheckboxTreeNode(
							new Node(((Node) selectedNode.getParent().getData()).getId(), ((Node) selectedNode.getParent().getData()).getName(), Type.CAT), unSelectedTree);
					// add offer to category
					n.getChildren().add(selectedNode);
					n.setSelected(false);
					n.setExpanded(true);

					// get offer category from selected tree
					TreeNode offerCategory = getChildById(selectedTree, ((Node) selectedNode.getParent().getData()).getId());
					// remove offer
					removeChildFromParent(offerCategory, selectedNode);
					if (offerCategory.getChildCount() <= 0)
						removeChildFromParent(selectedTree, offerCategory);

				} else {
					selectedNode.setSelected(false);
					selectedNode.setExpanded(true);
					category.getChildren().add(selectedNode);
					// get offer category from selected tree
					TreeNode offerCategory = getChildById(selectedTree, ((Node) selectedNode.getParent().getData()).getId());
					// remove offer from unselected tree
					if (offerCategory != null)
						removeChildFromParent(offerCategory, selectedNode);
				}
			}

		}
		selectedTree.setExpanded(true);
		selectedNodes = null;
		unSelectedNodes = null;

	}

	public TreeNode initUnSelectedCheckbox(List<ServiceCategory> pxServiceCategory, List<OfferingDetails> pxOfferingDetails) {

		TreeNode root = new CheckboxTreeNode(new Node(0, "root", Type.ROOT), null);
		Map<Integer, TreeNode> categoriesMap = new HashMap<Integer, TreeNode>();
		Map<Integer, TreeNode> offersMap = new HashMap<Integer, TreeNode>();

		for (ServiceCategory cat : pxServiceCategory) {
			categoriesMap.put(Integer.parseInt(cat.getCategoryId().trim()), new CheckboxTreeNode(new Node(Integer.parseInt(cat.getCategoryId().trim()), cat.getName(), Type.CAT),
					root));
		}

		for (OfferingDetails offer : pxOfferingDetails) {

			try {
				
			
				offersMap.put(
						offer.getOfferingId(),
						new CheckboxTreeNode(new Node(offer.getOfferingId(), offer.getOfferingName(), Type.OFFER), categoriesMap.get(Integer.parseInt(offer.getOfferingCategory()
								.trim()))));
			} catch (NullPointerException e) {
				System.out.println(offer.getOfferingName());
				e.printStackTrace();
			}

		}

		unSelectedTree = root;
		
		return unSelectedTree;

	}

	public void initSelectedCheckbox(List<ServiceCategory> pxServiceCategory, List<OfferingDetails> pxOfferingDetails) {
		/*
		 * TreeNode root = new CheckboxTreeNode(new Node(0, "root", Type.ROOT),
		 * null); selectedTree = root;
		 */
		TreeNode root = new CheckboxTreeNode(new Node(0, "root", Type.ROOT), null);
		Map<Integer, TreeNode> categoriesMap = new HashMap<Integer, TreeNode>();
		Map<Integer, TreeNode> offersMap = new HashMap<Integer, TreeNode>();

		for (ServiceCategory cat : pxServiceCategory) {

			try {
				categoriesMap.put(Integer.parseInt(cat.getCategoryId().trim()), new CheckboxTreeNode(
						new Node(Integer.parseInt(cat.getCategoryId().trim()), cat.getName(), Type.CAT), root));
			} catch (Exception e) {
				e.printStackTrace();
				System.out.println("Error : " + cat.getCategoryId());
			}
		}

		for (OfferingDetails offer : pxOfferingDetails) {

			try {
				offersMap.put(
						offer.getOfferingId(),
						new CheckboxTreeNode(new Node(offer.getOfferingId(), offer.getOfferingName(), Type.OFFER), categoriesMap.get(Integer.parseInt(offer.getOfferingCategory()
								.trim()))));
			} catch (NullPointerException e) {
				System.out.println(offer.getOfferingName());
				e.printStackTrace();
			}

		}
		selectedTree = root;
	}

	@Deprecated
	private boolean parentHasChild(TreeNode parent, TreeNode child) {

		for (TreeNode existingChildNode : parent.getChildren()) {
			//
			if (((Node) existingChildNode.getData()).getId().intValue() == ((Node) child.getData()).getId().intValue()) {
				return true;
			}
		}
		return false;
	}

	@Deprecated
	private TreeNode copyChildToParent(TreeNode parent, TreeNode child, Type type) {

		Node n = new Node(((Node) child.getData()).getId(), ((Node) child.getData()).getName(), type);
		TreeNode checkBoxTreeNode = new CheckboxTreeNode(n, parent);
		return checkBoxTreeNode;

	}

	private void removeChildFromParent(TreeNode parent, TreeNode child) {

		try {

			TreeNode c = null;
			// get matching category from unselected tree
			for (TreeNode childNode : parent.getChildren()) {
				// get cat offers
				if (((Node) childNode.getData()).getId().intValue() == ((Node) child.getData()).getId().intValue()) {
					c = childNode;
				}
			}
			if (c != null)
				parent.getChildren().remove(c);

		} catch (NullPointerException e) {
			e.printStackTrace();
		}
	}

	private TreeNode getChildById(TreeNode parent, int id) {
		for (TreeNode n : parent.getChildren()) {
			if (((Node) n.getData()).getId().intValue() == id)
				return n;
		}
		return null;
	}

	public TreeNode getUnSelectedTree() {
		return unSelectedTree;
	}

	public void setUnSelectedTree(TreeNode unSelectedTree) {
		this.unSelectedTree = unSelectedTree;
	}

	public TreeNode getSelectedTree() {
		return selectedTree;
	}

	public void setSelectedTree(TreeNode selectedTree) {
		this.selectedTree = selectedTree;
	}

	public TreeNode[] getUnSelectedNodes() {
		return unSelectedNodes;
	}

	public void setUnSelectedNodes(TreeNode[] unSelectedNodes) {
		this.unSelectedNodes = unSelectedNodes;
	}

	public TreeNode[] getSelectedNodes() {
		return selectedNodes;
	}

	public void setSelectedNodes(TreeNode[] selectedNodes) {
		this.selectedNodes = selectedNodes;
	}
}