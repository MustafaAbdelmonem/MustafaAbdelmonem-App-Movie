package com.etisalat.dynamicOffering.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.etisalat.common.configs.AppConfig;
import com.etisalat.dynamicOffering.controller.util.ResponseUtil;

/**
 * Setting up some stuff using for all API
 *
 */
public abstract class AbstractBaseController {
    
   
    @Autowired
    AppConfig appConfig;
    
    @Autowired
    protected ResponseUtil responseUtil;
    
    protected final Logger LOGGER = LoggerFactory.getLogger(this.getClass());
    
}
