package com.etisalat.dynamicOffering.database.trm.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingCappingTRM;

public interface OfferingCappingRepositoryTrm extends JpaRepository<OfferingCappingTRM, Integer> {

}