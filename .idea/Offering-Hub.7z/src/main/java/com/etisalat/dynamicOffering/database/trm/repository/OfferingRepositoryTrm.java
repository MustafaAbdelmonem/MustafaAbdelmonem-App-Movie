package com.etisalat.dynamicOffering.database.trm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.etisalat.dynamicOffering.database.trm.entity.Offering;

/**
 *
 * @author O-Mostafa.Teba
 */
public interface OfferingRepositoryTrm extends JpaRepository<Offering, Integer> {

	@Query("SELECT max(offering_id)+1 from Offering")
	Integer getNextOfferId();
}