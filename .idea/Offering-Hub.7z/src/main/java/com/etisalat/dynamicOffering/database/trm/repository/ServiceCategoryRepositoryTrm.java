package com.etisalat.dynamicOffering.database.trm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.trm.entity.ServiceCategory;

/**
*
* @author O-Mostafa.Teba
*/
public interface ServiceCategoryRepositoryTrm extends JpaRepository<ServiceCategory, Integer> {

	List<ServiceCategory> findByCategoryIdIn(List<String> CategoryIds);
	
}
