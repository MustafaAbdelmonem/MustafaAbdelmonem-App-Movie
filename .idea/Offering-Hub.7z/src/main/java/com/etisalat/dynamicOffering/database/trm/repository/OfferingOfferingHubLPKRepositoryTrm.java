package com.etisalat.dynamicOffering.database.trm.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.etisalat.dynamicOffering.database.trm.entity.OfferingHubLpkTRM;


public interface OfferingOfferingHubLPKRepositoryTrm extends JpaRepository<OfferingHubLpkTRM, Integer> {

	
	
	@Query(value = "SELECT distinct o,t,s " + 
			"FROM OfferingVal o , OfferingTemplates t , Shortcode s  " + 
			"where t.templateId = s.templateId and o.serviceId = s.serviceId ")
	List<Object[]> listOfferingHubLPK();
}
