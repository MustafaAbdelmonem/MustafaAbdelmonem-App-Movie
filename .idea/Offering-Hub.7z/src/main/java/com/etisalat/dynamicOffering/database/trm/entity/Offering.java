package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.etisalat.dynamicOffering.controller.api.request.OfferingDTO;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.dynamicOffering.mapper.EntityMapper;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


@Entity
@Table(name = "Offering")
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class Offering implements EntityMapper<Offering, OfferingDTO> , Serializable {

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_ID")
	
	private Integer offeringId;

	@Column(name = "OFFERING_NAME")
	private String offeringName;

	@Column(name = "OFFERING_DESC")
	private String offeringDesc;

	@Column(name = "OFFERING_START_DTTM")
	private Date offeringStartDttm;

	@Column(name = "OFFERING_END_DTTM")
	private Date offeringEndDttm;

	@Column(name = "OFFERING_MASK")
	private Integer offeringMask;

	@Column(name = "OFFERING_VAL")
	private String offeringVal;

	@Column(name = "OFFERING_BITS")
	private String offeringBits;

	@Column(name = "DWH_ENTRY_DATE")
	private Date dwhEntryDate;

	@Column(name = "SSS_ID")
	private Integer sssId;

	@Column(name = "SSS_NAME")
	private String sssName;

	@Column(name = "ACCOUNT_GROUP_FLAG")
	private String accountGroupFlag;

	@Column(name = "PROMOTION_PLAN_BEFORE_ID")
	private Integer promotionPlanBeforeId;

	@Column(name = "PROMOTION_PLAN_AFTER_ID")
	private Integer promotionPlanAfterId;

	@Column(name = "CAMPAIGN_NOTIFICATION_FLAG")
	private String campaignNotificationFlag;

	@Column(name = "NBA_FLAG")
	private String nbaFlag;

	@Column(name = "BULK_ACTION_FLAG")
	private String bulkActionFlag;

	@Column(name = "OFFERING_TYPE")
	private String offeringType;

	@Column(name = "OFFERING_CATEGORY")
	private String offeringCategory;

	@Column(name = "PROJECT_X_FLAG")
	private String projectXFlag;

	@Column(name = "ENGAGEMENT_FLAG")
	private String engagementFlag;

	@Column(name = "INTERACTIVE_FLAG")
	private String interactiveFlag;

	@Column(name = "SUBSCRIPTION_TEMPLATE_FLAG")
	private String subscriptionTemplateFlag;

	@Column(name = "OFFERING_TYPE_ID")
	private Integer offeringTypeId;

	@Column(name = "PROJECT")
	private String project;

	@Column(name = "COMMENTS")
	private String comments;
	
	
	@Override
	public OfferingDTO toDTO(DynamicOfferingMapper mapper, Offering entity) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public Offering toEntity(DynamicOfferingMapper mapper, OfferingDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}
}
