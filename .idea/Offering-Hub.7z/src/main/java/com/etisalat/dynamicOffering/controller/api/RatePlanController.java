package com.etisalat.dynamicOffering.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.dynamicOffering.controller.AbstractBaseController;
import com.etisalat.dynamicOffering.controller.util.APIResponse;
import com.etisalat.dynamicOffering.enums.EligibleRatePlanBTL;
import com.etisalat.dynamicOffering.service.RatePlanService;



@RestController
@RequestMapping(APIName.RATE_PLAN)
public class RatePlanController extends AbstractBaseController {

	@Autowired
	RatePlanService ratePlanService;

	@RequestMapping(value = APIName.RATE_PLAN_LIST, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findAllRatePlan(@PathVariable("campaignType") String campaignType) {
		if (campaignType.equals("BTL")) {
			return responseUtil.successResponse(EligibleRatePlanBTL.getData());
		} else if (campaignType.equals("ATL")) {
			return responseUtil.successResponse(ratePlanService.findAllRatePlan());
		}
		// TODO set error message describe more details to user ??
		return responseUtil.invalidRequestParam(campaignType);
	}

	@RequestMapping(value = APIName.RATE_PLAN_GROUPS, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findAllRatePlanGroups() {
		return responseUtil.successResponse(ratePlanService.findDistinctRatePlanGroup());
	}

	@RequestMapping(value = APIName.RATE_PLAN_BY_GROUP, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findRatePlanByGroup(@PathVariable("group") String group) {
		return responseUtil.successResponse(ratePlanService.findRatePlanByGroup(group));
	}
}
