package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "PX_DYN_OFFERING_PARAMETERS")
@IdClass(DynOfferingParameterId.class)
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class DynOfferingParameterTRM implements Serializable {

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_ID")
	private Integer offeringId;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "PARAMETER_TYPE_ID")
	private Integer parameterTypeId;

	@Column(name = "PARAMETER_1")
	private Integer parameter1;

	@Column(name = "PARAMETER_2")
	private Integer parameter2;

	@Column(name = "PARAMETER_3")
	private Integer parameter3;

	@Column(name = "PARAMETER_TXT")
	private String parameterTxt;


}
