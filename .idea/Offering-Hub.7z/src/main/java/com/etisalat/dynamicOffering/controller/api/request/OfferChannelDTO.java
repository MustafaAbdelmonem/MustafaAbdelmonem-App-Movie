package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class OfferChannelDTO {

	private Integer offeringId;
	private Integer channelId;
	private String channelTypeId;
}
