package com.etisalat.dynamicOffering.controller.api.request;

import java.util.Date;

import lombok.Data;

@Data
public class OfferingContradictionDTO {
	
	private Integer offeringId;
	private Integer contradictingId;
	private Integer contradictingTypeId;
	private Date startDate;
	private Date endDate;

}
