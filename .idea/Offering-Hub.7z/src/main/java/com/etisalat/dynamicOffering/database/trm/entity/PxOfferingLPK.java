package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "px_offering_lpk")
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class PxOfferingLPK implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "SERVICE_ID")
	Integer serviceId;

	@Column(name = "OPERATION_ID")
	String operationId;

	@Column(name = "PRODUCT_NAME")
	String productName;

	@Column(name = "PLATFORM_ID")
	String platformId;

	@Column(name = "OFFERING_VAL")
	Integer offeringVal;

	@Column(name = "PLATFORM_AR_DESC")
	String platformArDesc;
	@Column(name = "PLATFORM_EN_DESC")
	String platformEnDesc;

}
