package com.etisalat.dynamicOffering.database.ods.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingCapping;

/**
 *
 * @author O-Mostafa.Teba
 */
public interface OfferingCappingRepositoryOds extends JpaRepository<OfferingCapping, Integer> {

}