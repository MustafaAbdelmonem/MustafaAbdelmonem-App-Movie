package com.etisalat.dynamicOffering.enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public enum BonusTypeFlag {
	
	FIXED(false,"Fixed"),
	PERCENTAGE(true,"Percentage");
	
	private boolean value;
	private String label;
	
	 BonusTypeFlag(boolean value, String label) {
		this.value = value;
		this.label = label;
	}
	 
	 public static  List<Properties> getData(){
		List<Properties> data = new ArrayList<Properties>();
		for(BonusTypeFlag bt : BonusTypeFlag.values()) {
			Properties prop = new Properties();
			prop.put("label", bt.label);
			prop.put("value", bt.value);
			data.add(prop);
		}
		return data;
	}
}
