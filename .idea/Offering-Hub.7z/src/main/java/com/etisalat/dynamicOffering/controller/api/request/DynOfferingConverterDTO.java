package com.etisalat.dynamicOffering.controller.api.request;

import lombok.Data;

@Data
public class DynOfferingConverterDTO {
	
	private Integer offeringId;
	private long converterType;
	private long validity;
	private float rate;
	private float fees;
	private String paymentMethod;

}
