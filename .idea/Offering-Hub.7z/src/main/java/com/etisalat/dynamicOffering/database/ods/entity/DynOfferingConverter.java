package com.etisalat.dynamicOffering.database.ods.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.etisalat.dynamicOffering.controller.api.request.DynOfferingConverterDTO;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.dynamicOffering.mapper.EntityMapper;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "PX_DYN_OFFERING_CONVERTER",schema = "ods")
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class DynOfferingConverter implements EntityMapper<DynOfferingConverter, DynOfferingConverterDTO> , Serializable
{
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_ID")
	private Integer offeringId;
	
	@Column(name = "CONVERTER_TYPE")
	private Long converterType;

	@Column(name = "VALIDITY")
	private Long validity;

	@Column(name = "RATE")
	private Float rate;

	@Column(name = "FEES")
	private Float fees;

	@Column(name = "PAYMENT_METHOD")
	private String paymentMethod;

	@Override
	public DynOfferingConverterDTO toDTO(DynamicOfferingMapper mapper, DynOfferingConverter entity) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public DynOfferingConverter toEntity(DynamicOfferingMapper mapper, DynOfferingConverterDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}
}
