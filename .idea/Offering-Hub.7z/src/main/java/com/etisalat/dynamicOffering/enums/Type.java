package com.etisalat.dynamicOffering.enums;

public enum Type {
	CAT, OFFER,RATE_PLAN_GROUP,RATE_PLAN, ROOT
}
