
package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.PageImpl;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsAtl;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsBtl;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingDetailsAtlRepositoryOds;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingDetailsBtlRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingDetails;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingDetailsRepositoryTrm;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.rtim.integration.RTIMintegration;
import com.google.gson.Gson;


@Service
public class OfferingDetailsService extends AbstractBaseService {

	@Autowired
	OfferingDetailsAtlRepositoryOds atlRepositoryOds;

	@Autowired
	OfferingDetailsBtlRepositoryOds btlRepositoryOds;

	@Autowired
	OfferingDetailsRepositoryTrm offeringDetailsRepositoryTrm;
	@Autowired
	RTIMintegration rTIMintegration = new RTIMintegration();
	
	@Autowired
	Gson gson;

	@Transactional()
	public List<OfferingDetailsAtl> findAllATLs() {
		return atlRepositoryOds.findAll();
	}

	@Transactional()
	public List<OfferingDetailsBtl> findAllBTLs() {
		return btlRepositoryOds.findAll();
	}

	@Transactional()
	public List<OfferingDetails> findAllTRMOfferingDetails() {
		return offeringDetailsRepositoryTrm.findAll();
	}

	@Transactional()
	public List<OfferingDetails> findTRMOfferingDetailsByCategoryId(String categoryId) {
		return offeringDetailsRepositoryTrm.findByOfferingCategory(categoryId);
	}
	
	@Transactional()
	public List<OfferingDetails>  findTRMOfferingDetailsByOfferName(String offerName) {
		return offeringDetailsRepositoryTrm.findByOfferingName(offerName);
	}

	@Transactional()
	public OfferingDetailsAtl insertATL(OfferingDetailsAtl atlOffering) {
		return atlRepositoryOds.save(atlOffering);
	}
	
	
	@Transactional()
	public OfferingDetailsBtl insertBTL(OfferingDetailsBtl btlOffering) {
		return btlRepositoryOds.save(btlOffering);
	}
	
	
	@Transactional()
	public OfferingDetails insertOfferingDetailsTRM(OfferingDetails offeringDetails) {
		return offeringDetailsRepositoryTrm.save(offeringDetails);
	}
	
	@Transactional()
	public OfferingDetails insertOfferingDetails(OfferingDetails offeringDetails) throws Exception {
		if(offeringDetails.getOfferingLineType().equals("ATL")) {
			OfferingDetailsAtl offeringDetailsAtl = DynamicOfferingMapper.instance.mapOfferingDetailsToAtlEntity(offeringDetails);
			insertATL(offeringDetailsAtl);
		} else if (offeringDetails.getOfferingLineType().equals("BTL")) {
			OfferingDetailsBtl offeringDetailsBtl = DynamicOfferingMapper.instance.mapOfferingDetailsToBtlEntity(offeringDetails);
			insertBTL(offeringDetailsBtl);
		}
		OfferingDetails offerDetails = offeringDetailsRepositoryTrm.save(offeringDetails);
		rTIMintegration.insertRTIMDB(gson.toJson(offeringDetails), offeringDetails.getOfferingLineType().equalsIgnoreCase("ATL") ?  "px_offering_details_atl" :  "px_offering_details_btl");
		return offerDetails;
	}

	//m.samir
	@Transactional()
	public List<OfferingDetails> findTRMOfferingDetailsByOfferId(Integer offeringId) {
		return offeringDetailsRepositoryTrm.findByOfferingId(offeringId);
	}

	@Transactional()
	public Page<OfferingDetails> findTRMOfferingDetailsByOfferVal(Integer offeringVal,Pageable pageable) {

		List<OfferingDetails> offerdetalis = offeringDetailsRepositoryTrm.findByOfferingVal(offeringVal, pageable);

		int ListSize = 0;

		if (offerdetalis != null) {
			ListSize = counter(offeringVal);
		}

		return new PageImpl<OfferingDetails>(offerdetalis, pageable, ListSize);

	}

	public int counter(Integer offeringVal) {
		return offeringDetailsRepositoryTrm.countOfferingval(offeringVal);
	}

}
