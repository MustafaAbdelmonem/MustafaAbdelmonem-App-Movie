package com.etisalat.dynamicOffering.database.trm.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
@Entity
@Table(name = "PX_OFFERING_OFFVAL")
@IdClass(OfferingValId.class)
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class OfferingVal implements Serializable {

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "SERVICE_ID")
	private Integer serviceId;

	@Column(name = "PARAMETER_NAME")
	private String parameterName;
	
	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "PARAMETER_VALUE")
	private String parameterValue;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_VAL")
	private Integer offeringVal;

	@Column(name = "OFFER_TYPE")
	private String offerType;

}
