package com.etisalat.dynamicOffering.controller.api;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.dynamicOffering.controller.AbstractBaseController;
import com.etisalat.dynamicOffering.controller.util.APIResponse;
import com.etisalat.dynamicOffering.database.ods.entity.OfferingDetailsBtl;
import com.etisalat.dynamicOffering.service.OfferingDetailsService;

/**
 *
 * @author O-Mostafa.Teba
 */

@RestController
@RequestMapping(APIName.OFFERING_DETAILS)
public class OfferingDetailsController extends AbstractBaseController{

	@Autowired
	OfferingDetailsService offeringDetailsService;

	@RequestMapping(value = APIName.OFFERING_DETAILS_TRM_LIST, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findAllTRMOfferingDetails() {
		return responseUtil.successResponse(offeringDetailsService.findAllTRMOfferingDetails());
	}
	
	@RequestMapping(value = "/trm/{category-id}", method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findTRMOfferingDetailsByCategoryId(@PathVariable("category-id") String categoryId) {
		return responseUtil.successResponse(offeringDetailsService.findTRMOfferingDetailsByCategoryId(categoryId));
	}
	
	
	@RequestMapping(value = "/trm/offer", method = RequestMethod.POST)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findTRMOfferingDetailsByOfferName(@RequestBody String offerName) {
		return responseUtil.successResponse(offeringDetailsService.findTRMOfferingDetailsByOfferName(offerName));
	}
	
	@RequestMapping(value = APIName.OFFERING_DETAILS_ATL_LIST, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findAllATLs(Pageable page) {
		return responseUtil.successResponse(offeringDetailsService.findAllATLs());
	}

	@RequestMapping(value = APIName.OFFERING_DETAILS_ATL_ADD, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> insertBTL(Pageable page) {
		OfferingDetailsBtl  btlOffering = new OfferingDetailsBtl();
		return responseUtil.successResponse(offeringDetailsService.insertBTL(btlOffering));
	}
	
	@RequestMapping(value = APIName.OFFERING_DETAILS_BTL_ADD, method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findAllBTLs(Pageable page) {
		return responseUtil.successResponse(offeringDetailsService.findAllBTLs());
	}

	
	//m.samir
	
	@RequestMapping(value =APIName.OFFERING_DETAILS_OFFERID,  method = RequestMethod.GET)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findTRMOfferingDetailsByOfferId(@PathVariable("offeringId") Integer offeringId) {
		return responseUtil.successResponse(offeringDetailsService.findTRMOfferingDetailsByOfferId(offeringId));
	}

    @RequestMapping(value =APIName.OFFERING_DETAILS_OFFERVAL, method = RequestMethod.POST)
	@CrossOrigin(origins = APIName.UI_URL)
	public ResponseEntity<APIResponse> findTRMOfferingDetailsByOfferval(@RequestParam("offerval") Integer offeringVal,Pageable page) {
		return responseUtil.successResponse(offeringDetailsService.findTRMOfferingDetailsByOfferVal(offeringVal, page));
	}

//  @RequestMapping(path="/{offerName}" , method = RequestMethod.GET)
//	@CrossOrigin(origins = APIName.UI_URL)
//	public ResponseEntity<APIResponse> findTRMOfferingDetailsByOfferName(@PathVariable("offerName") String offerName) {
//		return responseUtil.successResponse(offeringDetailsService.findTRMOfferingDetailsByOfferName(offerName));
//	}

}
