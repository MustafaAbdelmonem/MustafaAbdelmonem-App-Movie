package com.etisalat.dynamicOffering.enums;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public enum PaymentMethod {

	UNITS("Units"),
	MB("MB");
	
	private String name;

	PaymentMethod(String name) {
		this.name = name;
	}
	
	public static  List<Properties> getAllData(){
		List<Properties> data = new ArrayList<Properties>();
		for(PaymentMethod tc : PaymentMethod.values()) {
			Properties prop = new Properties();
			prop.put("name", tc.name);
			data.add(prop);
		}
		return data;
	}
	
	public static  List<Properties> getData(List<PaymentMethod> list){
		List<Properties> data = new ArrayList<Properties>();
		for(PaymentMethod tc : list) {
			Properties prop = new Properties();
			prop.put("name", tc.name);
			data.add(prop);
		}
		return data;
	}
	
}
