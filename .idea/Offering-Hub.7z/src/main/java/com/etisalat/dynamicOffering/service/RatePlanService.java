package com.etisalat.dynamicOffering.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import com.etisalat.dynamicOffering.database.trm.entity.RatePlan;
import com.etisalat.dynamicOffering.database.trm.repository.RatePlanRepositoryTrm;


@Service
public class RatePlanService {
	
	@Autowired
	RatePlanRepositoryTrm ratePlanRepository;
	private static final String OTHER = "other";
	@Transactional()
	public Map<String,List<RatePlan>> findAllRatePlan() {
		
		Map<String,List<RatePlan> > result =new HashMap<>();	
		
		result.put(OTHER, new ArrayList<>());
		for (RatePlan ratePlan : ratePlanRepository.findAll() )
		{
			if(result.containsKey(ratePlan.getRatePlanGroup()))	
					result.get(ratePlan.getRatePlanGroup()).add(ratePlan);
			else if(ratePlan.getRatePlanGroup()==null)
				result.get(OTHER).add(ratePlan);
			else 
			{
				List<RatePlan> list = new ArrayList<>() ;
				list.add(ratePlan);
				result.put(ratePlan.getRatePlanGroup(), list);
			}
		}
		
		
		return result;
	}
	
	@Transactional()
	public List<RatePlan> findDistinctRatePlanGroup() {
		return ratePlanRepository.findDistinctRatePlanGroup();
	}
	
	@Transactional()
	public List<RatePlan> findRatePlanByGroup(@PathVariable("group") String group) {
		if (group.equals("null")) {
			return ratePlanRepository.findByRatePlanGroupIsNull();
		}
		return ratePlanRepository.findByRatePlanGroup(group);
	}
}
