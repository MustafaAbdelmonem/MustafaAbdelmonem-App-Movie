package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingCapping;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingCappingRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingCappingTRM;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingCappingRepositoryTrm;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.rtim.integration.RTIMintegration;
import com.google.gson.Gson;

@Service
public class OfferingCappingService extends AbstractBaseService {

	@Autowired
	OfferingCappingRepositoryTrm offeringCappingRepositoryTrm;

	
	@Autowired
	OfferingCappingRepositoryOds offeringCappingRepositoryOds;
	
	RTIMintegration rTIMintegration = new RTIMintegration();
	
	@Autowired
	Gson gson;
	
	@Transactional()
	public List<OfferingCappingTRM> findAllOfferingCapping() {
		return offeringCappingRepositoryTrm.findAll();
	}

	@Transactional()
	public void insertOfferingCapping(OfferingCapping offeringCapping) throws Exception {
		offeringCappingRepositoryOds.save(offeringCapping);
		offeringCappingRepositoryTrm.save(DynamicOfferingMapper.instance.mapDynOfferingCappingEntityTRM(offeringCapping));
		rTIMintegration.insertRTIMDB(gson.toJson(offeringCapping),"PX_OFFERING_CAPPING");
	}

}
