package com.etisalat.dynamicOffering.controller.api;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.common.utils.AuthUtils;
import com.etisalat.dynamicOffering.controller.AbstractBaseController;
import com.etisalat.dynamicOffering.controller.util.APIResponse;
import com.etisalat.dynamicOffering.enums.BonusOnRenewalTargetRatePlan;
import com.etisalat.dynamicOffering.enums.BonusType;
import com.etisalat.dynamicOffering.enums.BonusTypeFlag;
import com.etisalat.dynamicOffering.enums.TrafficCase;
import com.etisalat.dynamicOffering.models.old.Res;
import com.etisalat.dynamicOffering.service.OfferingLookupService;


@RestController
@RequestMapping(APIName.LOOKUP)
public class LookupController extends AbstractBaseController {

	
	@Autowired
	OfferingLookupService offeringLookupService;
	
	

	@CrossOrigin(origins = APIName.UI_URL)
	@RequestMapping(value = APIName.LOOKUP_PX_Offering, method = RequestMethod.GET)
	public ResponseEntity<APIResponse> getOfferingHubLPK(Pageable page, HttpServletRequest request) {
		LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
		return responseUtil.successResponse(offeringLookupService.findAll());
	}
	
	
	@CrossOrigin(origins = APIName.UI_URL)
	@RequestMapping(value = APIName.LOOKUP_BONUS_ON_RENEWAL_TARGET_RP, method = RequestMethod.GET)
	public ResponseEntity<APIResponse> getBonusOnRenewalTargetRatePlan(Pageable page, HttpServletRequest request) {
		LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
		return responseUtil.successResponse(BonusOnRenewalTargetRatePlan.getData());
	}
	    
	@CrossOrigin(origins = APIName.UI_URL)
	@RequestMapping(value = APIName.LOOKUP_TRAFFIC_CASE, method = RequestMethod.GET)
	public ResponseEntity<APIResponse> getTrafficCase(@PathVariable("template_id") Integer templateId, HttpServletRequest request) {
		LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
		return responseUtil.successResponse(offeringLookupService.getTrafficCases(templateId));
	}

	@CrossOrigin(origins = APIName.UI_URL)
	@RequestMapping(value = APIName.LOOKUP_BONUS_TYPE, method = RequestMethod.GET)
	public ResponseEntity<APIResponse> getBonusType(Pageable page, HttpServletRequest request) {
		LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
		return responseUtil.successResponse(BonusType.getData());
	}
	
	@CrossOrigin(origins = APIName.UI_URL)
	@RequestMapping(value = APIName.LOOKUP_BONUS_TYPE_FLAG, method = RequestMethod.GET)
	public ResponseEntity<APIResponse> getBonusTypeFlag(Pageable page, HttpServletRequest request) {
		LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
		return responseUtil.successResponse(BonusTypeFlag.getData());
	}
}