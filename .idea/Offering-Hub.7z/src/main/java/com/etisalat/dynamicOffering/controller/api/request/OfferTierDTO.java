package com.etisalat.dynamicOffering.controller.api.request;

import java.util.List;

import lombok.Data;

@Data
public class OfferTierDTO  {

	private Integer thesholdId;
	private Float thresholdValue;
	private Float poolBonusValue;
	private List<OfferBonusDTO> bonusList;
	private boolean completed;
}
