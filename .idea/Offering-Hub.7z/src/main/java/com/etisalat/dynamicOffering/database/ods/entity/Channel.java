package com.etisalat.dynamicOffering.database.ods.entity;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
*
* @author O-Mostafa.Teba
*/
@Entity
@Table(name = "PX_CHANNEL",schema = "ods")
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class Channel implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "CHAN_ID")
	private Long channelId;
	
	@Column(name = "CHANNEL_NAME")
	private String channelName;

}
