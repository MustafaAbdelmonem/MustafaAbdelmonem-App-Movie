package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.entity.DynOfferingConverter;
import com.etisalat.dynamicOffering.database.ods.repository.DynOfferingConverterRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.DynOfferingConverterTRM;
import com.etisalat.dynamicOffering.database.trm.repository.DynOfferingConverterRepositoryTrm;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.rtim.integration.RTIMintegration;
import com.google.gson.Gson;




@Service
public class DynOfferingConverterService extends AbstractBaseService {

	@Autowired
	DynOfferingConverterRepositoryOds dynOfferingConverterRepositoryOds;
	
	@Autowired
	DynOfferingConverterRepositoryTrm dynOfferingConverterRepositoryTrm;
	
	RTIMintegration rTIMintegration = new RTIMintegration();
	
	@Autowired
	Gson gson;

	@Transactional()
	public List<DynOfferingConverterTRM> findAllDynOfferingConverter() {
		return dynOfferingConverterRepositoryTrm.findAll();
	}

	public void insertDynOfferingConverter(DynOfferingConverter dynOfferingConverter) throws Exception {
		dynOfferingConverterRepositoryOds.save(dynOfferingConverter);
		dynOfferingConverterRepositoryTrm.save(DynamicOfferingMapper.instance.mapDynOfferingConverterTRM(dynOfferingConverter));
		rTIMintegration.insertRTIMDB(gson.toJson(dynOfferingConverter),"PX_DYN_OFFERING_CONVERTER");
	}

}
