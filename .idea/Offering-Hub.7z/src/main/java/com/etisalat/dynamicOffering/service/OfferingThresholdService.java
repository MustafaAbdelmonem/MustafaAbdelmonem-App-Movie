package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.entity.OfferingThreshold;
import com.etisalat.dynamicOffering.database.ods.repository.OfferingThresholdRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.OfferingThresholdTRM;
import com.etisalat.dynamicOffering.database.trm.repository.OfferingThresholdRepositoryTrm;
import com.etisalat.dynamicOffering.mapper.DynamicOfferingMapper;
import com.etisalat.rtim.integration.RTIMintegration;
import com.google.gson.Gson;


@Service
public class OfferingThresholdService extends AbstractBaseService {
	
	@Autowired
	OfferingThresholdRepositoryOds offeringThresholdRepositoryOds;
	
	@Autowired
	OfferingThresholdRepositoryTrm offeringThresholdRepositoryTrm;
	
	@Autowired
	Gson gson;
	
	@Transactional()
	public List<OfferingThresholdTRM> findAllThreshold() {
		return offeringThresholdRepositoryTrm.findAll();
	}
	
	@Transactional()
	public void insertOfferingThreshold(OfferingThreshold offeringThreshold) throws Exception {
		RTIMintegration rTIMintegration = new RTIMintegration();
		offeringThresholdRepositoryOds.save(offeringThreshold);
		offeringThresholdRepositoryTrm.save(DynamicOfferingMapper.instance.mapOfferingThresholdEntity(offeringThreshold));
		rTIMintegration.insertRTIMDB(gson.toJson(offeringThreshold),"px_offering_threshold");
	}
}
