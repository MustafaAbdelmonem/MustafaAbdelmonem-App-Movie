package com.etisalat.dynamicOffering.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.dynamicOffering.database.ods.repository.DynOfferingParameterLkpRepositoryOds;
import com.etisalat.dynamicOffering.database.trm.entity.DynOfferingParametersLkp;
import com.etisalat.dynamicOffering.database.trm.repository.DynOfferingParameterLkpRepositoryTrm;

/**
 *
 * @author O-Mostafa.Teba
 */

@Service
public class DynOfferingParameterLkpService extends AbstractBaseService {

	@Autowired
	DynOfferingParameterLkpRepositoryOds dynOfferingParameterLkpRepositoryOds;
	
	@Autowired
	DynOfferingParameterLkpRepositoryTrm dynOfferingParameterLkpRepositoryTrm;
	
	
	@Transactional()
	public List<DynOfferingParametersLkp> findAll() {
		return dynOfferingParameterLkpRepositoryTrm.findAll();
	}

}
