package com.etisalat.dynamicOffering.database.ods.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name = "PX_OFFERING_CONTRADICTION",schema = "ods")
@IdClass(OfferingContradictionId.class)
@Setter
@Getter
@EqualsAndHashCode
@ToString
@NoArgsConstructor
public class OfferingContradiction implements Serializable {

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "OFFERING_ID")
	private Integer offeringId;

	@Id
	@Basic(optional = false)
	@NotNull
	@Column(name = "CONTRADICTING_ID")
	private Integer contradictingId;

	@Column(name = "CONTRADICTING_TYPE_ID")
	private Integer contradictingTypeId;

	@Column(name = "START_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date startDate;

	@Column(name = "END_DATE")
	@Temporal(TemporalType.TIMESTAMP)
	private Date endDate;

}
