package com.etisalat.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
//@Component
public class SystemProperties {

	private String trmLeadSchema = "trm_lead";
	private String trmMetaSchema = "trm_meta";
	private String trmViewSchema = "trm_staging";
	private String odsSchema = "ods";
	private String tdbSchema = "tdb";
	private String vdbSchema = "vdb";

	private String ussdRefreshCacheServlet = "http://10.196.1.103:7070/USSDHandler/ProjectX/refreshCache";

	private String logsPath = "";

	private String cepPath = "";

	private String cepTempPath = "";

	private String cherriesShortCodes = "714,715,716,717,718,719,720";

	private String migrationTargetRP = "New Hekaya mix 35:2095,New Hekaya mix 70:2097,New Hekaya mix 25:2094,New Hekaya mix 50:2096,New Hekaya mix 100:2098,Hekaya bundle 200:2056,Hekaya bundle 150:2057,Hekaya bundle 75:2058,Hekaya bundle 40:2059,Hekaya Family 65:2100,Hekaya Family 100:2101,Hekaya Family 150:2102,Hekaya Family 200:2103,Control 35 promo:1533, Demagh Tanya (Harely):2093,Ahlan 15:1046";

	private int parameterTypeId_migrationFlag = 19;
	
	private int parameterTypeId_dynamicQuotaFlag = 20;
	
	private int parameterTypeId_renewalOnFlag = 21;
	
	private int parameterTypeId_bundleTypeId = 22;
	
	private int	parameterTypeId_offerType=23;
	
	
	
	//@Value("${RTIM_URL}")
	private String  rtimURL ="http://10.208.14.11:8080/RTIMIintegration-testing/";
	
	
	
	private String bundleTypes = "Music 1:1,Music 2:2,Music 3:3,Music 4:4,Video 1:5,Video 2:6,Video 3:7,Video 4:8,All Hourly Bundle 1:9,All Hourly Bundle 2:10,All Hourly Bundle 3:11,All Hourly Bundle 4:12,All Hourly Bundle 5:13,All Hourly Bundle 6:14,All Hourly Bundle 7:15,Social Bundle 1:16,Social Bundle 2:17,Social Bundle 3:18,Social Bundle 4:19,Gaming Bundle 1:20,Gaming Bundle 2:21,Gaming Bundle 3:22,Gaming Bundle 4:23";
	
	
	
	
	
}
