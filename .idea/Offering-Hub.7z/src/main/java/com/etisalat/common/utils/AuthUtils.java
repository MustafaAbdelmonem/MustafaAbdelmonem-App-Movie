package com.etisalat.common.utils;

import javax.servlet.http.HttpServletRequest;

public class AuthUtils {
	
	public static String getUserIpAddress(HttpServletRequest request) {
		String remoteAddress = "";
		if(request != null) {
			remoteAddress = request.getHeader("X-FORWARDED-FOR");
			if(remoteAddress == null || "".equals(remoteAddress))
				remoteAddress = request.getRemoteAddr();
		}
		return remoteAddress;
	}

}
