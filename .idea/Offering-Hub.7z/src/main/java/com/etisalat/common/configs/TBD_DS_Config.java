package com.etisalat.common.configs;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
*
* @author O-Mostafa.Teba
*/

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(entityManagerFactoryRef = "tdbEntityManagerFactory",
        transactionManagerRef = "tdbTransactionManager",
        basePackages = {"com.etisalat.ivroffer.repository","com.etisalat.subscriptionoffer.repository","com.etisalat.subscriptionparameterizedoffer.repository"})
public class TBD_DS_Config {

	@Autowired
	private Environment env;
	
    @Bean(name = "tdbDataSource")
    @ConfigurationProperties(prefix = "tdb.datasource")
    public DataSource dataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "tdbEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean entityManagerFactory(EntityManagerFactoryBuilder builder,   @Qualifier("tdbDataSource") DataSource dataSource) {
        return builder.dataSource(dataSource)
                .packages("com.etisalat.ivroffer.model","com.etisalat.subscriptionoffer.model","com.etisalat.subscriptionparameterizedoffer.model")
                .properties(jpaProperties())
                .persistenceUnit("tdb")
                .build();
    }

    @Bean(name = "tdbTransactionManager")
    public PlatformTransactionManager transactionManager(@Qualifier("tdbEntityManagerFactory") EntityManagerFactory  entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }


    private Map<String,Object> jpaProperties() {
        Map<String, Object> props = new HashMap<>();
        props.put("hibernate.physical_naming_strategy", env.getProperty("tdb.jpa.hibernate.naming.physical-strategy"));
        props.put("hibernate.implicit_naming_strategy", env.getProperty("tdb.jpa.hibernate.naming.implicit-strategy"));
        props.put("hibernate.hbm2ddl.auto", env.getProperty("tdb.jpa.hibernate.ddl-auto"));
        props.put("hibernate.show-sql", env.getProperty("tdb.jpa.show-sql"));
        return props;
    }
}
