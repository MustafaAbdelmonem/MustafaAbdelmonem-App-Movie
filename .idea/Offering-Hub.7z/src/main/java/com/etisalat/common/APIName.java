package com.etisalat.common;

public class APIName {

    // version
    public static final String VERSION = "api/v1";
    
    // version
    public static final String UI_URL = "http://localhost:4200";

    // Charset
    public static final String CHARSET = "application/json;charset=utf-8";

    // Channel
    public static final String CHANNEL = VERSION + "/channels";
    public static final String CHANNEL_BY_ID = "/detail/{channel_id}";
    public static final String CHANNEL_LIST = "/list";
    public static final String CHANNEL_ADD = "/add";
    
    // Offering
    public static final String OFFERING = VERSION + "/offering";
    public static final String OFFERING_LIST = "/list";
    public static final String OFFERING_ADD = "/add";
    public static final String OFFERING_UPDATE = "/update";
    public static final String OFFERING_SAVE = "/save";
    
    // Offering Bonus
    public static final String OFFERING_BONUS = VERSION + "/offering-bonus";
    public static final String OFFERING_BONUS_LIST = "/list";

    // Offering Details
    public static final String OFFERING_DETAILS = VERSION + "/offering-details";
    public static final String OFFERING_DETAILS_TRM_LIST = "/trm/list";
    public static final String OFFERING_DETAILS_BTL_LIST = "/btl/list";
    public static final String OFFERING_DETAILS_ATL_LIST = "/atl/list";
    public static final String OFFERING_DETAILS_ATL_ADD = "/btl/add";
    public static final String OFFERING_DETAILS_BTL_ADD = "/atl/add";
    
    public static final String OFFERING_DETAILS_OFFERID="/{offeringId}";
    public static final String OFFERING_DETAILS_OFFERVAL="/{search}";
    public static final String OFFERING_DETAILS_OFFERNAME="/{offerName}";
    
    // Offering Template
    public static final String OFFERING_TEMPLATE = VERSION + "/offering-template";
    public static final String OFFERING_TEMPLATE_LIST = "/list";
    
    // Rate Plan
    public static final String RATE_PLAN = VERSION + "/rate-plan";
    public static final String RATE_PLAN_LIST = "/list";
    public static final String RATE_PLAN_GROUPS = "/groups";
    public static final String RATE_PLAN_BY_GROUP = "/{group}";
    
    // Service Category
    public static final String SERVICE_CATEGORY = VERSION + "/service-category";
    public static final String SERVICE_CATEGORY_LIST = "/list";
    public static final String SERVICE_CATEGORY_BY_TEMPATE_ID = "/template/{template_id}";

    
    // Short Code
    public static final String SHORT_CODE = VERSION + "/shortcode";
    public static final String SHORT_CODE_LIST = "/list";
    public static final String SHORT_CODE_BY_TEMPATE_ID = "/template/{template_id}";
    public static final String SHORT_CODE_ATL = "/atl/{template_id}";
    public static final String SHORT_CODE_BTL = "/btl/{template_id}";
    
    // Offering Capping
    public static final String OFFERING_CAPPING = VERSION + "/offering-capping";
    public static final String OFFERING_CAPPING_LIST = "/list";
    
    // Offering Converter
    public static final String OFFERING_CONVERTER = VERSION + "/offering-converter";
    public static final String OFFERING_CONVERTER_LIST = "/list";

    // Offering Parameter
    public static final String OFFERING_PARAMETER = VERSION + "/offering-parameter";
    public static final String OFFERING_PARAMETER_LIST = "/list";
    
    // Offering Parameter LPK
    public static final String OFFERING_PARAMETER_LPK = VERSION + "/offering-parameter-lpk";
    public static final String OFFERING_PARAMETER_LPK_LIST = "/list";

    // Offering Contradiction
    public static final String OFFERING_CONTRADICTION = VERSION + "/offering-contradiction";
    public static final String OFFERING_CONTRADICTION_LIST = "/list";
    
    // Offering Rate Plan
    public static final String OFFERING_RATE_PLAN = VERSION + "/offering-rate-plan";
    public static final String OFFERING_RATE_PLAN_LIST = "/list";
    
    // Offering threshold
    public static final String OFFERING_THRESHOLD = VERSION + "/offering-threshold";
    public static final String OFFERING_THRESHOLD_LIST = "/list";

    // Run Details
    public static final String RUN_DETAILS = VERSION + "/run-details";
    public static final String RUN_DETAILS_LIST = "/list";
    
    // Lookups
    public static final String LOOKUP = VERSION + "/lookup";
    public static final String LOOKUP_BONUS_ON_RENEWAL_TARGET_RP = "/bonrp";
    public static final String LOOKUP_BONUS_TYPE   = "/bonus-type";
    public static final String LOOKUP_BONUS_TYPE_FLAG = "/bonus-type-flag";
    public static final String LOOKUP_TRAFFIC_CASE = "/traffic-case/{template_id}";
    
    public static final String LOOKUP_PX_Offering  = "/PX_Offering";
    
    /**** IVR ****/
    public static final String IVR_CONTROLLER = VERSION + "/ivrController";

	/**** Subscription ****/
    public static final String SUBSCRIPTION_CONTROLLER = VERSION + "/subscription";
    
    /**** Subscription Parameterized ****/
    public static final String SUBSCRIPTION_PARAMETERIZED_CONTROLLER = VERSION + "/subscriptionParameterized";
    
    /**** User Authentication ****/
    public static final String USER_CONTROLLER = VERSION + "/userAuthentication";
    
    /**** User Registration ****/
    public static final String USER_REGISTRATION = "/Registration";

	
}
