package com.etisalat;

import static springfox.documentation.builders.PathSelectors.regex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
/**
*
* @author O-Mostafa.Teba
*/
@SpringBootApplication
@EnableSwagger2
public class ApplicationStartup extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(ApplicationStartup.class, args);
	}
	
	@Bean
    public Docket newsApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("apis")
                .apiInfo(apiInfo())
                .select()
                .paths(regex("/api.*"))
                .build();
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("Etisalate Dynamic Offering")
                .description("Etisalate Dynamic Offering REST API Documents")
                //.termsOfServiceUrl("http://nit-software.com")
                .contact("")
                .license("")
                .licenseUrl("")
                .version("2.0")
                .build();
    }
}
