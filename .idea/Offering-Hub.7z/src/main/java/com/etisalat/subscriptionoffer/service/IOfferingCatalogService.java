package com.etisalat.subscriptionoffer.service;

import com.etisalat.subscriptionoffer.model.SubscriptionOfferingCatalog;

public interface IOfferingCatalogService {

	void delete(Integer offeringId);

	void saveOrUpdateOfferingCatalog(SubscriptionOfferingCatalog catalog);

	void deleteOfferingCatalog(Integer offeringId);

}
