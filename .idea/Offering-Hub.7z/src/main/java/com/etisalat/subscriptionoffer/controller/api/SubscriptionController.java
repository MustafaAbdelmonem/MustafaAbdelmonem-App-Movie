package com.etisalat.subscriptionoffer.controller.api;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.common.message.response.ResponseMessage;
import com.etisalat.common.utils.AuthUtils;
import com.etisalat.common.utils.Constant;
import com.etisalat.subscriptionoffer.attribute.SubscriptionOfferDtoList;
import com.etisalat.subscriptionoffer.dto.SubscriptionOfferDTO;
import com.etisalat.subscriptionoffer.mappers.SubscriptionMapper;
import com.etisalat.subscriptionoffer.model.SubscriptionOffer;
import com.etisalat.subscriptionoffer.model.SubscriptionOfferVDB;
import com.etisalat.subscriptionoffer.service.ISubscriptionService;

import io.swagger.annotations.Api;

@RestController
@RequestMapping(APIName.SUBSCRIPTION_CONTROLLER)
@CrossOrigin(origins="*", maxAge=3600)
@Api("subscription controller api")
public class SubscriptionController {
	

	
	private static final Log LOGGER = LogFactory.getLog(SubscriptionController.class);
	
	@Autowired
	ISubscriptionService subscriptionService;
	
	@GetMapping
	public ResponseEntity<SubscriptionOfferDtoList> listSubscriptionOffers(@RequestParam("start") int start, @RequestParam("pageSize") int pageSize
			, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			SubscriptionMapper mapper = SubscriptionMapper.instance;
			List<SubscriptionOfferDTO> dtos = new ArrayList<>();
			int totalCount = subscriptionService.getTotalCount();
			if(totalCount != 0) {
				List<SubscriptionOfferVDB> subscriptions = subscriptionService.listSubscriptionOffers(start,pageSize);
				subscriptions.stream().forEach(subscription -> dtos.add(mapper.subscriptionOfferToDtoVDB(subscription)));				
			}
			SubscriptionOfferDtoList subscriptionOffersList = new SubscriptionOfferDtoList();
			subscriptionOffersList.setRecordsTotal(dtos.size());
			subscriptionOffersList.setTotalCount(totalCount);
			subscriptionOffersList.setSubscriptionOffers(dtos);
			return new ResponseEntity<>(subscriptionOffersList, HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new SubscriptionOfferDtoList(), HttpStatus.BAD_REQUEST);
		}
	}
	
	@DeleteMapping(path="/{offeringId}")
	public ResponseEntity<ResponseMessage> deleteOffer(@PathVariable("offeringId") Integer offeringId, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			subscriptionService.delete(offeringId);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_DELETED_SUCCESS), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while deleting Subscription Offer with Id: " + offeringId);
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_DELETED_ERROR), HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping
	public ResponseEntity<ResponseMessage> editOffer(@RequestBody SubscriptionOfferDTO dto, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			SubscriptionOffer offer = SubscriptionMapper.instance.dtoToSubscriptionOffer(dto);
			subscriptionService.updateOffer(offer);
			LOGGER.debug("Subscription Offer updated successfully, Offer Id is: " + dto.getOfferingId());
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_UPDATED_SUCCESS), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while updating Subscription Offer with Id: " + dto.getOfferingId());
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_UPDATED_ERROR), HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping
	public ResponseEntity<ResponseMessage> saveOffer(@RequestBody SubscriptionOfferDTO dto, HttpServletRequest request){		
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			SubscriptionOffer offer = SubscriptionMapper.instance.dtoToSubscriptionOffer(dto);
			subscriptionService.saveOffer(offer);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_SAVED_SUCCESS), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while saving Subscription Offer with name: " + dto.getOfferingName());
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_SAVED_ERROR), HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(path="/{offeringId}")
	public ResponseEntity<SubscriptionOfferDTO> getOfferByOfferId(@PathVariable("offeringId") Integer offeringId, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			SubscriptionOfferVDB offer = subscriptionService.getOfferByOfferId(offeringId);
			return new ResponseEntity<>(SubscriptionMapper.instance.subscriptionOfferToDtoVDB(offer), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while getting Subscription Offer with Id: " + offeringId);
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new SubscriptionOfferDTO(), HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(path="/checkOfferingNameAndDesc")
	public ResponseEntity<Boolean> editOffer(@RequestBody String offeringName, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			return new ResponseEntity<>(subscriptionService.isOfferingNameOrDescDuplicated(offeringName), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while checking offer duplication with name: " + offeringName);
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);
		}
	}

}
