package com.etisalat.subscriptionoffer.mappers;

import com.etisalat.subscriptionoffer.dto.OfferingCatalogDTO;
import com.etisalat.subscriptionoffer.model.SubscriptionOfferingCatalog;

public interface OfferCatalogMapper {
	
	OfferingCatalogDTO catalogToDto(SubscriptionOfferingCatalog catalog);
	
	SubscriptionOfferingCatalog dtoToCatalog(OfferingCatalogDTO dto);

}
