package com.etisalat.subscriptionoffer.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;
import javax.xml.bind.ValidationException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.etisalat.common.constant.EtisalatConstant;
import com.etisalat.subscriptionoffer.model.SubscriptionOffer;
import com.etisalat.subscriptionoffer.model.SubscriptionOfferVDB;
import com.etisalat.subscriptionoffer.model.SubscriptionOfferingCatalogVDB;
import com.etisalat.subscriptionoffer.repository.ISubscriptionRepository;
import com.etisalat.subscriptionoffer.repository.VDBSubscriptionRepository;
import com.etisalat.subscriptionoffer.service.IOfferingCatalogService;
import com.etisalat.subscriptionoffer.service.ISubscriptionService;

@Transactional
@Service("subscriptionService")
public class SubscriptionServiceImpl implements ISubscriptionService {
	
	private static final Log LOGGER = LogFactory.getLog(SubscriptionServiceImpl.class);

	@Autowired
	ISubscriptionRepository subscriptionRepository;
	
	@Autowired
	VDBSubscriptionRepository vdbSubscriptionRepository;
	
	@Autowired
	IOfferingCatalogService catalogService;
	
	SubscriptionOfferVDB offer;
	
	@Override
	public SubscriptionOfferVDB getOfferByOfferId(Integer offeringId) {
		SubscriptionOfferVDB offer = new SubscriptionOfferVDB();
		Object object = vdbSubscriptionRepository.findByOfferingId(offeringId);
		if(object != null) {
			offer = (SubscriptionOfferVDB)(((Object[]) object)[EtisalatConstant.OFFERING_INDEX]);
			offer.setCatalog((SubscriptionOfferingCatalogVDB)(((Object[]) object)[EtisalatConstant.OFFERING_CATALOG_INDEX]));
		}
		return offer;
	}

	@Override
	public void saveOffer(SubscriptionOffer offer) throws ValidationException {
		Integer maxOfferingId = vdbSubscriptionRepository.findMaxOfferingId();
		offer.setOfferingId(maxOfferingId+1);
		offer.setStartDttm(new Date());
		offer.setDwhEntryDate(new Date());
		offer.setAccountGroupFlag("D");
		offer.setOfferingDesc(offer.getOfferingName());
		offer.setDeleteFlag('N');
		subscriptionRepository.save(offer);
		
		if(offer.getOfferingId() != null) {
			LOGGER.debug("subscription Offer Saved Successfully with Id: " + offer.getOfferingId());
			
			offer.getCatalog().setDeleteFlag('N');
			offer.getCatalog().setOfferingId(offer.getOfferingId());
			catalogService.saveOrUpdateOfferingCatalog(offer.getCatalog());
			LOGGER.debug("Offering_Catalog saved successfully for subscription Offer Id: " + offer.getOfferingId());
		} else {
			LOGGER.error("Saving subscription Offer Error:  Offering Id must not be null!");
			throw new ValidationException("Offering Id must not be null !");
		}
	}

	@Override
	public void updateOffer(SubscriptionOffer offer) {
		
		offer.getCatalog().setDeleteFlag('N');
		catalogService.saveOrUpdateOfferingCatalog(offer.getCatalog());
		LOGGER.debug("offering_catalog is updated for subscription offer Id: " + offer.getOfferingId());
		
		offer.setAccountGroupFlag("D");
		offer.setOfferingDesc(offer.getOfferingName());
		offer.setDeleteFlag('N');
		subscriptionRepository.save(offer);
		LOGGER.debug("offering is updated for subscription offer Id: " + offer.getOfferingId());
	}

	@Override
	public void delete(Integer offeringId) {
		
		catalogService.deleteOfferingCatalog(offeringId);
		LOGGER.debug("update offering_catalog delete_flag with 'Y' for subscription offer Id: " + offeringId);
		
		subscriptionRepository.deleteSubscriptionOffer(offeringId);
		LOGGER.debug("update Offering delete_flag with 'Y' for subscription offer Id: " + offeringId);
	}

	@Override
	public List<SubscriptionOfferVDB> listSubscriptionOffers(int start, int pageSize) {
		List<SubscriptionOfferVDB> subscriptionOfferings = new ArrayList<>();
		List<Object[]> paginatedList = vdbSubscriptionRepository.listSubscriptionOffersVDB(new PageRequest(start, pageSize));
		paginatedList.stream().forEach(item -> {
			offer = (SubscriptionOfferVDB)item[EtisalatConstant.OFFERING_INDEX];
			offer.setCatalog((SubscriptionOfferingCatalogVDB)item[EtisalatConstant.OFFERING_CATALOG_INDEX]);
			subscriptionOfferings.add(offer);
		});
		return subscriptionOfferings;
	}

	@Override
	public int getTotalCount() {
		return vdbSubscriptionRepository.getTotalCount();
	}

	@Override
	public boolean isOfferingNameOrDescDuplicated(String offeringName) {
		return vdbSubscriptionRepository.findByOfferingNameOrOfferingDesc(offeringName, offeringName).isEmpty() ? false : true;
	}

}
