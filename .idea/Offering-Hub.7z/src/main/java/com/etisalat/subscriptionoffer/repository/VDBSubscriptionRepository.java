package com.etisalat.subscriptionoffer.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.ivroffer.model.OfferingVDB;
import com.etisalat.subscriptionoffer.model.SubscriptionOfferVDB;

@Transactional
@Repository("VDBSubRepository")
public interface VDBSubscriptionRepository extends JpaRepository<SubscriptionOfferVDB, Long> {


	@Query("SELECT coalesce(max(subscriptionOffer.offeringId), 0) FROM SubscriptionOfferVDB subscriptionOffer")
	Integer findMaxOfferingId();
	
	@Query("SELECT subscriptionOffer , offeringCatalog "
			+ "FROM SubscriptionOfferVDB subscriptionOffer , SubscriptionOfferingCatalogVDB offeringCatalog "
			+ "WHERE subscriptionOffer.offeringId = offeringCatalog.offeringId "
			+ "AND subscriptionOffer.offeringId NOT IN (SELECT offeringConfig.offeringId FROM SubscriptionOfferingConfigVDB offeringConfig) "
			+ "AND subscriptionOffer.offeringId NOT IN (SELECT offeringParam.offeringId FROM OfferingSubRequestParamVDB offeringParam) "
			+ "AND subscriptionOffer.offeringId = :offeringId "
			+ "AND subscriptionOffer.deleteFlag <> 'Y' AND (subscriptionOffer.accountGroupFlag <> 'O' OR subscriptionOffer.accountGroupFlag IS NULL)")
	Object findByOfferingId(@Param("offeringId") Integer offeringId);

	@Query(value = "SELECT coalesce(COUNT(*), 0) "
			+ "FROM SubscriptionOfferVDB subscriptionOffer , SubscriptionOfferingCatalogVDB offeringCatalog " 
			+ "WHERE offeringCatalog.offeringId = subscriptionOffer.offeringId AND subscriptionOffer.deleteFlag <> 'Y' "
			+ "AND (subscriptionOffer.accountGroupFlag <> 'O' OR subscriptionOffer.accountGroupFlag IS NULL)"
			+ "AND subscriptionOffer.offeringId NOT IN (SELECT offeringConfig.offeringId FROM SubscriptionOfferingConfigVDB offeringConfig)")
	int getTotalCount();

	List<OfferingVDB> findByOfferingNameOrOfferingDesc(String offeringName, String offeringDesc);
	
	@Query(value = "SELECT DISTINCT subscriptionOffer , offeringCatalog "
			+ "FROM SubscriptionOfferVDB subscriptionOffer , SubscriptionOfferingCatalogVDB offeringCatalog " 
			+ "WHERE offeringCatalog.offeringId = subscriptionOffer.offeringId AND subscriptionOffer.deleteFlag <> 'Y' "
			+ "AND (subscriptionOffer.accountGroupFlag <> 'O' OR subscriptionOffer.accountGroupFlag IS NULL)"
			+ "AND subscriptionOffer.offeringId NOT IN (SELECT offeringConfig.offeringId FROM SubscriptionOfferingConfigVDB offeringConfig) "
			+ "AND subscriptionOffer.offeringId NOT IN (SELECT offeringParam.offeringId FROM OfferingSubRequestParamVDB offeringParam) "
			+ "ORDER BY subscriptionOffer.offeringId DESC")
	List<Object[]> listSubscriptionOffersVDB(Pageable pageable);

}
