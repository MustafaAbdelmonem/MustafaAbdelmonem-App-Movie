package com.etisalat.subscriptionoffer.dto;

import lombok.Data;

@Data
public class OfferingCatalogDTO {

	private Integer offeringId;
	private String shortCode;
	private Long offeringOptInTypeId;
	private char deleteFlag;
}
