package com.etisalat.subscriptionoffer.service;

import java.util.List;

import javax.xml.bind.ValidationException;

import com.etisalat.subscriptionoffer.model.SubscriptionOffer;
import com.etisalat.subscriptionoffer.model.SubscriptionOfferVDB;

public interface ISubscriptionService {

	SubscriptionOfferVDB getOfferByOfferId(Integer offeringId);

	void saveOffer(SubscriptionOffer offer) throws ValidationException;

	void updateOffer(SubscriptionOffer offer);

	void delete(Integer offeringId);

	List<SubscriptionOfferVDB> listSubscriptionOffers(int start, int pageSize);

	int getTotalCount();

	boolean isOfferingNameOrDescDuplicated(String offeringName);

}
