package com.etisalat.subscriptionoffer.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.subscriptionoffer.model.SubscriptionOffer;

@Transactional
@Repository("subscriptionRepository")
public interface ISubscriptionRepository extends JpaRepository<SubscriptionOffer, Integer> {

	@Query("SELECT subscriptionOffer , offeringCatalog "
			+ "FROM SubscriptionOffer subscriptionOffer , SubscriptionOfferingCatalog offeringCatalog "
			+ "WHERE subscriptionOffer.offeringId = offeringCatalog.offeringId "
			+ "AND subscriptionOffer.offeringId NOT IN (SELECT offeringConfig.offeringId FROM SubscriptionOfferingConfig offeringConfig) "
			+ "AND subscriptionOffer.offeringId = :offeringId")
	Object findByOfferingId(@Param("offeringId") Integer offeringId);

	@Query("SELECT coalesce(max(subscriptionOffer.offeringId), 0) FROM SubscriptionOffer subscriptionOffer")
	Integer findMaxOfferingId();

	@Transactional
	@Modifying
	@Query("UPDATE SubscriptionOffer SET deleteFlag = 'Y' WHERE offering_id =:offeringId")
	void deleteSubscriptionOffer(@Param("offeringId") Integer offeringId);

	@Query(value = "SELECT DISTINCT subscriptionOffer , offeringCatalog "
			+ "FROM SubscriptionOffer subscriptionOffer , SubscriptionOfferingCatalog offeringCatalog " 
			+ "WHERE offeringCatalog.offeringId = subscriptionOffer.offeringId "
			+ "AND subscriptionOffer.offeringId NOT IN (SELECT offeringConfig.offeringId FROM SubscriptionOfferingConfig offeringConfig) "
			+ "ORDER BY subscriptionOffer.offeringId DESC")
	List<Object[]> listSubscriptionOffers(Pageable pageable);

	@Query(value = "SELECT coalesce(COUNT(*), 0) "
			+ "FROM SubscriptionOffer subscriptionOffer , SubscriptionOfferingCatalog offeringCatalog " 
			+ "WHERE offeringCatalog.offeringId = subscriptionOffer.offeringId "
			+ "AND subscriptionOffer.offeringId NOT IN (SELECT offeringConfig.offeringId FROM SubscriptionOfferingConfig offeringConfig)")
	int getTotalCount();

	List<SubscriptionOffer> findByOfferingNameOrOfferingDesc(String offeringName, String offeringDesc);
	
	@Transactional
	@Modifying
	@Query("UPDATE SubscriptionOffer SET Delete_Flag = 'Y' WHERE offering_id =:offeringId")
	void deleteIvrOffering(@Param("offeringId") Integer offeringId);

}
