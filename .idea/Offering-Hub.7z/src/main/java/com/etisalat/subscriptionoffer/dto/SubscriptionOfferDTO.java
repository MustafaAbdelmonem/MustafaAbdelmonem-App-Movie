package com.etisalat.subscriptionoffer.dto;

import java.util.Date;

import lombok.Data;

@Data
public class SubscriptionOfferDTO {
	
	private Integer offeringId;
	private String offeringName;
	private String offeringDesc;
	private Date startDttm;
	private Date endDttm;
	private String offeringVal;
	private Date dwhEntryDate;
	private Long serviceId;
	private String accountGroupFlag;
	private String serviceName;
	private OfferingCatalogDTO catalog;
	private char deleteFlag;
}
