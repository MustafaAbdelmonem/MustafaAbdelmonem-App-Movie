package com.etisalat.subscriptionoffer.model;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.etisalat.common.model.CustomOfferEntity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Data
@EqualsAndHashCode(callSuper = false)
@Table(name = "OFFERING_EMAN", schema = "TRM_STAGING_T")
@Inheritance(strategy = InheritanceType.JOINED)
public class SubscriptionOffer extends CustomOfferEntity {

	private static final long serialVersionUID = 6580000530752046248L;
	
	@Transient
	private SubscriptionOfferingCatalog catalog;

}
