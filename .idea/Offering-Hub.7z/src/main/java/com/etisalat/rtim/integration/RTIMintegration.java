package com.etisalat.rtim.integration;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.etisalat.common.SystemProperties;
import com.etisalat.dynamicOffering.models.old.Offer;
@Component
public class RTIMintegration {

	private static final String RTIM_URL= "http://localhost:4000/";
	private SystemProperties systemProperties = new SystemProperties();
	
	public void apiNewSys(Offer request) throws Exception	
	{
		RestTemplate restTemplate = new RestTemplate();
		
		  restTemplate.getMessageConverters().add(new MappingJackson2HttpMessageConverter());
	
		HttpHeaders httpHeaders = new HttpHeaders();
//		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.setContentType(MediaType.valueOf(MediaType.APPLICATION_JSON_VALUE + ";charset=UTF-8"));
		
		try {
			HttpEntity<Offer> httpEntity = new HttpEntity<Offer>(request, httpHeaders);
					
			
			
			//restTemplate.postForEntity(url, entity, String.class);
			restTemplate.postForEntity(systemProperties.getRtimURL() ,  httpEntity, String.class);
			//restTemplate.postForEntity("http://localhost:8080/RTIMIintegration/"+tableName, httpEntity, String.class);
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("Failed while inserting in RTIM DB");
		}
	}

	
	
	
	public void insertRTIMDB(String requestJson, String tableName) throws Exception	
	{
		RestTemplate restTemplate = new RestTemplate();
	
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.add("tableName", tableName);
//		httpHeaders.setContentType(MediaType.APPLICATION_JSON);
		httpHeaders.setContentType(MediaType.valueOf(MediaType.APPLICATION_JSON_VALUE + ";charset=UTF-8"));
	
		try {
			HttpEntity<String> httpEntity = new HttpEntity<String>(requestJson, httpHeaders);
					
			//restTemplate.postForEntity(url, entity, String.class);
			restTemplate.postForEntity(systemProperties.getRtimURL() +tableName,  httpEntity, String.class);
			//restTemplate.postForEntity("http://localhost:8080/RTIMIintegration/"+tableName, httpEntity, String.class);
		} catch (Exception e) {
			e.getStackTrace();
			throw new Exception("Failed while inserting in RTIM DB");
		}
	}
	
}
