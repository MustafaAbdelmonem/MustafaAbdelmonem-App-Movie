package com.etisalat.ivroffer.dto;

import java.util.Date;

import lombok.Data;

@Data
public class IvrOfferDTO {

	private Integer offeringId;
	private String offeringName;
	private String offeringDesc;
    private String serviceName;
    private Long serviceId;
    private Date startDttm;
    private Date dwhEntryDate;
	private OfferingCatalogDTO catalog;
	private OfferingConfigDTO config;
	private char deleteFlag;
}
