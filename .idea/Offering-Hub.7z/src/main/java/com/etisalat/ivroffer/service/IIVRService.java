package com.etisalat.ivroffer.service;

import java.util.List;

import javax.xml.bind.ValidationException;

import com.etisalat.ivroffer.model.IvrOffering;
import com.etisalat.ivroffer.model.OfferingVDB;

public interface IIVRService {

	List<OfferingVDB> listIVROffersUsingVDB(int start, int pageSize);

	List<IvrOffering> listAll();

	void delete(Integer offeringId);

	void updateOffer(IvrOffering offer);

	void saveOffer(IvrOffering offer) throws ValidationException;

	OfferingVDB getOfferByOfferId(Integer offeringId);

	int getTotalCount();

	boolean isOfferingNameOrDescDuplicated(String offeringName);
}
