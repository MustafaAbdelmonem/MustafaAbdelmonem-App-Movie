package com.etisalat.ivroffer.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.ivroffer.model.OfferingVDB;

@Transactional
@Repository("VDBIvrRepository")
public interface VDBIvrRepository extends JpaRepository<OfferingVDB, Long> {


	@Query("SELECT COALESCE(max(offer.offeringId), 0) FROM OfferingVDB offer")
	Integer findMaxOfferingId();
	
	@Query(value = "SELECT o,ocat,ocon " + 
			"FROM OfferingVDB o , OfferingCatalogVDB ocat , OfferingConfigVDB ocon " + 
			"WHERE ocat.offeringId = o.offeringId AND ocon.offeringId = o.offeringId "
			+ "AND o.offeringId = :offeringId AND o.deleteFlag <> 'Y' AND (o.accountGroupFlag <> 'O' OR o.accountGroupFlag IS NULL)")
	Object findByOfferingId(@Param("offeringId") Integer offeringId);

	@Query(value = "SELECT COALESCE(COUNT(*), 0) " + 
			"FROM OfferingVDB o , OfferingCatalogVDB ocat , OfferingConfigVDB ocon " + 
			"WHERE ocat.offeringId = o.offeringId and ocon.offeringId = o.offeringId " +
			"AND o.deleteFlag <> 'Y' AND (o.accountGroupFlag <> 'O' OR o.accountGroupFlag IS NULL)")
	int getTotalCount();

	List<OfferingVDB> findByOfferingNameOrOfferingDesc(String offeringName, String offeringDesc);
	
	@Query(value = "SELECT o,ocat,ocon " + 
			"FROM OfferingVDB o , OfferingCatalogVDB ocat , OfferingConfigVDB ocon " + 
			"WHERE ocat.offeringId = o.offeringId and ocon.offeringId = o.offeringId " +
			"AND o.deleteFlag <> 'Y' AND (o.accountGroupFlag <> 'O' OR o.accountGroupFlag IS NULL)" + 
			"ORDER BY o.offeringId DESC")
	List<Object[]> listIVROffersUsingVDB(Pageable pageable);

}
