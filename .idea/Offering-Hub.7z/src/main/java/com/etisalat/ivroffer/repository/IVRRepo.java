package com.etisalat.ivroffer.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.etisalat.ivroffer.model.IvrOffering;

@Transactional
@Repository("ivrRepo")
public interface IVRRepo extends JpaRepository<IvrOffering, Long> {

	@Query(value = "SELECT o.offeringId, o.offeringName, ocat.shortCode, ocat.offeringOptInTypeId,ocon.channelName, ocon.treeId , ocon.interactiveFlag, ocon.promptName " + 
			"FROM IvrOffering o , OfferingCatalog ocat , OfferingConfig ocon " + 
			"WHERE ocat.offeringId = o.offeringId and ocon.offeringId = o.offeringId " + 
			"ORDER BY o.offeringId DESC")
	List<Object> list();
	
	@Query(value = "SELECT o,ocat,ocon " + 
			"FROM IvrOffering o , OfferingCatalog ocat , OfferingConfig ocon " + 
			"where ocat.offeringId = o.offeringId and ocon.offeringId = o.offeringId " + 
			"ORDER BY o.offeringId DESC")
	List<Object[]> listIVROffers(Pageable pageable);

	@Query("SELECT coalesce(max(o.offeringId), 0) FROM IvrOffering o")
	Integer findMaxOfferingId();

	@Query(value = "SELECT o,ocat,ocon " + 
			"FROM IvrOffering o , OfferingCatalog ocat , OfferingConfig ocon " + 
			"WHERE ocat.offeringId = o.offeringId AND ocon.offeringId = o.offeringId "
			+ "AND o.offeringId = :offeringId")
	Object findByOfferingId(@Param("offeringId") Integer offeringId);

	void deleteByOfferingId(Integer offeringId);

	@Query(value = "SELECT coalesce(COUNT(*), 0) " + 
			"FROM IvrOffering o , OfferingCatalog ocat , OfferingConfig ocon " + 
			"where ocat.offeringId = o.offeringId and ocon.offeringId = o.offeringId")
	int getTotalCount();

	List<IvrOffering> findByOfferingNameOrOfferingDesc(String offeringName, String offeringDesc);

	@Transactional
	@Modifying
	@Query("UPDATE IvrOffering SET deleteFlag = 'Y' WHERE offering_id =:offeringId")
	void deleteIvrOffering(@Param("offeringId") Integer offeringId);

}
