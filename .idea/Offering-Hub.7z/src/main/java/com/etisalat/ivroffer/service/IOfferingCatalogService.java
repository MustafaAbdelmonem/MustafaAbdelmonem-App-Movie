package com.etisalat.ivroffer.service;

import com.etisalat.ivroffer.model.OfferingCatalog;

public interface IOfferingCatalogService {

	void delete(Integer offeringId);

	void saveOrUpdateOfferingCatalog(OfferingCatalog catalog);

	void deleteOfferingCatalog(Integer offeringId);

}
