package com.etisalat.ivroffer.controller.api;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.etisalat.common.APIName;
import com.etisalat.common.message.response.ResponseMessage;
import com.etisalat.common.utils.AuthUtils;
import com.etisalat.common.utils.Constant;
import com.etisalat.ivroffer.attribute.IvrOfferDtoList;
import com.etisalat.ivroffer.dto.IvrOfferDTO;
import com.etisalat.ivroffer.mappers.IvrMapper;
import com.etisalat.ivroffer.model.IvrOffering;
import com.etisalat.ivroffer.model.OfferingVDB;
import com.etisalat.ivroffer.service.IIVRService;

import io.swagger.annotations.Api;

@RestController
@RequestMapping(APIName.IVR_CONTROLLER)
@CrossOrigin(origins="*", maxAge=3600)
@Api("ivr controller api")
public class IVRController {
	
	private static final Log LOGGER = LogFactory.getLog(IVRController.class);
	
	@Autowired
	IIVRService ivrService;
	
	@GetMapping
	public ResponseEntity<IvrOfferDtoList> listIvrOffers(@RequestParam("start") int start, @RequestParam("pageSize") int pageSize
			, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			IvrMapper mapper = IvrMapper.instance;
			List<IvrOfferDTO> dtos = new ArrayList<>();
			int totalCount = ivrService.getTotalCount();
			if(totalCount != 0) {
				List<OfferingVDB> ivrs = ivrService.listIVROffersUsingVDB(start,pageSize);
				ivrs.stream().forEach(ivr -> dtos.add(mapper.ivrOfferToDtoUsingVDB(ivr)));
			}
			IvrOfferDtoList ivrOffersList = new IvrOfferDtoList();
			ivrOffersList.setRecordsTotal(dtos.size());
			ivrOffersList.setTotalCount(totalCount);
			ivrOffersList.setIvrOffers(dtos);
			return new ResponseEntity<>(ivrOffersList, HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new IvrOfferDtoList(), HttpStatus.BAD_REQUEST);
		}
	}
	
	@DeleteMapping(path="/{offeringId}")
	public ResponseEntity<ResponseMessage> deleteOffer(@PathVariable("offeringId") Integer offeringId, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			ivrService.delete(offeringId);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_DELETED_SUCCESS), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while deleting Ivr Offer with Id: " + offeringId);
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_DELETED_ERROR), HttpStatus.BAD_REQUEST);
		}
	}
	
	@PutMapping
	public ResponseEntity<ResponseMessage> editOffer(@RequestBody IvrOfferDTO dto, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			IvrOffering offer = IvrMapper.instance.dtoToIvrOffer(dto);
			ivrService.updateOffer(offer);
			LOGGER.debug("Ivr Offer updated successfully, Offer Id is: " + dto.getOfferingId());
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_UPDATED_SUCCESS), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while updating Ivr Offer with Id: " + dto.getOfferingId());
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_UPDATED_ERROR), HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping
	public ResponseEntity<ResponseMessage> saveOffer(@RequestBody IvrOfferDTO dto, HttpServletRequest request){		
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			IvrOffering offer = IvrMapper.instance.dtoToIvrOffer(dto);
			ivrService.saveOffer(offer);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_SAVED_SUCCESS), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while saving Ivr Offer with name: " + dto.getOfferingName());
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new ResponseMessage(Constant.COMMON_SAVED_ERROR), HttpStatus.BAD_REQUEST);
		}
	}
	
	@GetMapping(path="/{offeringId}")
	public ResponseEntity<IvrOfferDTO> getOfferByOfferId(@PathVariable("offeringId") Integer offeringId, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			OfferingVDB offer = ivrService.getOfferByOfferId(offeringId);
			return new ResponseEntity<>(IvrMapper.instance.ivrOfferToDtoUsingVDB(offer), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while getting Ivr Offer with Id: " + offeringId);
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(new IvrOfferDTO(), HttpStatus.BAD_REQUEST);
		}
	}
	
	@PostMapping(path="/checkOfferingNameAndDesc")
	public ResponseEntity<Boolean> editOffer(@RequestBody String offeringName, HttpServletRequest request){
		try {
			LOGGER.info("User IP Address is : " + AuthUtils.getUserIpAddress(request));
			return new ResponseEntity<>(ivrService.isOfferingNameOrDescDuplicated(offeringName), HttpStatus.OK);
		} catch (Exception e) {
			LOGGER.error("Error while checking offer duplication with name: " + offeringName);
			LOGGER.error(e.getMessage(), e);
			return new ResponseEntity<>(false, HttpStatus.BAD_REQUEST);
		}
	}

}
