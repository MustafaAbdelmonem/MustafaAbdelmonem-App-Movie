package com.etisalat.ivroffer.mappers;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.etisalat.ivroffer.dto.IvrOfferDTO;
import com.etisalat.ivroffer.dto.OfferingCatalogDTO;
import com.etisalat.ivroffer.dto.OfferingConfigDTO;
import com.etisalat.ivroffer.model.IvrOffering;
import com.etisalat.ivroffer.model.OfferingCatalog;
import com.etisalat.ivroffer.model.OfferingConfig;
import com.etisalat.ivroffer.model.OfferingVDB;

@Mapper
public interface IvrMapper {

	IvrMapper instance = Mappers.getMapper(IvrMapper.class);
	
	IvrOfferDTO ivrOfferToDto(IvrOffering offer);
	
	IvrOfferDTO ivrOfferToDtoUsingVDB(OfferingVDB offer);
	
	IvrOffering dtoToIvrOffer(IvrOfferDTO dto);
	
	OfferingCatalogDTO catalogToDto(OfferingCatalog catalog);
	
	OfferingCatalog dtoToCatalog(OfferingCatalogDTO dto);
	
	OfferingConfigDTO configToDto(OfferingConfig config);
	
	OfferingConfig dtoToConfig(OfferingConfigDTO dto);
}
