package com.etisalat.ivroffer.model;

import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.etisalat.common.model.CustomOfferEntity;

import lombok.Data;

@Entity
@Data
@Table(name = "OFFERING_EMAN", schema = "TRM_STAGING_T")
public class IvrOffering extends CustomOfferEntity {

	private static final long serialVersionUID = -7278290828250885934L;

//	@OneToOne(fetch = FetchType.EAGER)
//	@JoinColumn(name = "offering_id", referencedColumnName = "offering_id", insertable = false, updatable = false, nullable = false)
	@Transient
	private OfferingCatalog catalog;
	
	@Transient
	private OfferingConfig config;

}
